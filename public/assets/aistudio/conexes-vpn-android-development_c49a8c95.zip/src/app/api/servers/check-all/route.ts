import { db } from "@/db";
import { servers } from "@/db/schema";
import { eq } from "drizzle-orm";
import { measureLatency } from "@/lib/network";
import { writeLog, touchDaily } from "@/lib/server-log";

export const dynamic = "force-dynamic";
export const maxDuration = 180;

export async function POST() {
  try {
    const rows = await db.select().from(servers);
    const enabled = rows.filter((r) => r.enabled);
    await writeLog("servidor", "info", `Verificação global iniciada: ${enabled.length} servidor(es)`);
    const results = [];
    for (const srv of enabled.slice(0, 40)) {
      const r = await measureLatency(srv.address, srv.port, 3, 3500);
      const online = r.ok;
      await db
        .update(servers)
        .set({ online, lastPingMs: r.avg, lastCheck: new Date(), updatedAt: new Date() })
        .where(eq(servers.id, srv.id))
        .catch(() => {});
      results.push({ id: srv.id, name: srv.name, online, avg: r.avg, loss: r.loss });
    }
    await touchDaily({ tests: results.length });
    const on = results.filter((r) => r.online).length;
    await writeLog("servidor", "success", `Verificação global concluída: ${on}/${results.length} online`);
    return Response.json({ ok: true, checked: results.length, online: on, results, measuredAt: new Date().toISOString() });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}
