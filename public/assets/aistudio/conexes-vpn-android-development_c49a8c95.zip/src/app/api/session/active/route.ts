import { db } from "@/db";
import { connectionSessions } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const active = await db.select().from(connectionSessions).where(eq(connectionSessions.active, true)).orderBy(desc(connectionSessions.startedAt)).limit(1);
    const recent = await db.select().from(connectionSessions).orderBy(desc(connectionSessions.startedAt)).limit(20);
    const now = Date.now();
    const withLive = active.map((s) => ({
      ...s,
      liveDurationSec: Math.floor((now - new Date(s.startedAt).getTime()) / 1000),
    }));
    return Response.json({ ok: true, active: withLive[0] ?? null, recent });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}
