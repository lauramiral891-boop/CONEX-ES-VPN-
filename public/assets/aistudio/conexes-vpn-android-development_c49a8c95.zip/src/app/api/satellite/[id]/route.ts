import { db } from "@/db";
import { satProfiles } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireAdmin } from "@/lib/admin-auth";
import { encryptSecret } from "@/lib/crypto";
import { writeLog } from "@/lib/server-log";

export const dynamic = "force-dynamic";

export async function PUT(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return Response.json({ ok: false, error: auth.error }, { status: 401 });
  const { id } = await ctx.params;
  const sid = Number(id);
  if (!Number.isInteger(sid)) return Response.json({ ok: false, error: "ID inválido" }, { status: 400 });
  try {
    const body = (await req.json()) as Record<string, string>;
    const patch: Record<string, unknown> = {};
    for (const k of ["name", "endpointIp", "gateway", "dnsPrimary", "dnsSecondary", "username", "notes"]) {
      if (body[k] !== undefined) patch[k] = String(body[k]).slice(0, 500) || null;
    }
    if (body["password"] !== undefined) {
      patch["passwordEnc"] = body["password"] ? encryptSecret(String(body["password"]).slice(0, 500)) : null;
    }
    const updated = await db.update(satProfiles).set(patch).where(eq(satProfiles.id, sid)).returning({ id: satProfiles.id });
    if (updated.length === 0) return Response.json({ ok: false, error: "Perfil não encontrado" }, { status: 404 });
    await writeLog("admin", "info", `Perfil ANGOSAT-2 #${sid} atualizado por ${auth.username}`);
    return Response.json({ ok: true, id: sid });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}

export async function DELETE(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return Response.json({ ok: false, error: auth.error }, { status: 401 });
  const { id } = await ctx.params;
  const sid = Number(id);
  if (!Number.isInteger(sid)) return Response.json({ ok: false, error: "ID inválido" }, { status: 400 });
  try {
    const deleted = await db.delete(satProfiles).where(eq(satProfiles.id, sid)).returning({ id: satProfiles.id });
    if (deleted.length === 0) return Response.json({ ok: false, error: "Perfil não encontrado" }, { status: 404 });
    await writeLog("admin", "warn", `Perfil ANGOSAT-2 #${sid} removido por ${auth.username}`);
    return Response.json({ ok: true, deleted: sid });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}
