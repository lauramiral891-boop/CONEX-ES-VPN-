"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Home, Building2, Radar, Server, KeyRound, Satellite, BarChart3,
  ScrollText, ShieldAlert, Sun, Moon, Crown, Wifi, CheckCircle2, XCircle, Info,
} from "lucide-react";
import { api } from "@/lib/client";
import { HomePanel } from "@/components/home";
import { OperatorsPanel, SatellitePanel } from "@/components/operators";
import { ScannerPanel } from "@/components/scanner";
import { ServersPanel, type ServerRow } from "@/components/servers";
import { TunnelsPanel, type Profile } from "@/components/tunnels";
import { StatsPanel, LogsPanel, AdminPanel } from "@/components/stats-logs-admin";

type Session = {
  id: number; profileName: string | null; operator: string; serverName: string | null;
  startedAt: string; bytesUp: number; bytesDown: number; publicIp: string | null; active: boolean;
};

type TabKey = "inicio" | "operadoras" | "scanner" | "servidores" | "tuneis" | "satelite" | "stats" | "logs" | "admin";

const TABS: { key: TabKey; label: string; icon: React.ReactNode }[] = [
  { key: "inicio", label: "Início", icon: <Home className="w-5 h-5" /> },
  { key: "scanner", label: "Scanner", icon: <Radar className="w-5 h-5" /> },
  { key: "servidores", label: "Servidores", icon: <Server className="w-5 h-5" /> },
  { key: "operadoras", label: "Operadoras", icon: <Building2 className="w-5 h-5" /> },
  { key: "tuneis", label: "Túneis", icon: <KeyRound className="w-5 h-5" /> },
  { key: "satelite", label: "ANGOSAT-2", icon: <Satellite className="w-5 h-5" /> },
  { key: "stats", label: "Estatísticas", icon: <BarChart3 className="w-5 h-5" /> },
  { key: "logs", label: "Logs", icon: <ScrollText className="w-5 h-5" /> },
  { key: "admin", label: "Admin", icon: <ShieldAlert className="w-5 h-5" /> },
];

export default function ConexoesVPNApp() {
  const [tab, setTab] = useState<TabKey>("inicio");
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const [operator, setOperator] = useState("UNITEL");
  const [servers, setServers] = useState<ServerRow[]>([]);
  const [activeServer, setActiveServer] = useState<ServerRow | null>(null);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [activeProfile, setActiveProfile] = useState<number | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [adminUser, setAdminUser] = useState<string | null>(null);
  const [toasts, setToasts] = useState<{ id: number; msg: string; kind: "ok" | "err" | "info" }[]>([]);
  const [booted, setBooted] = useState(false);

  const notify = useCallback((msg: string, kind: "ok" | "err" | "info" = "info") => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t.slice(-3), { id, msg, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4200);
  }, []);

  const reloadServers = useCallback(async () => {
    try {
      const d = (await api("/api/servers?sort=ping")) as { servers: ServerRow[] };
      setServers(d.servers);
      setActiveServer((cur) => {
        if (cur) {
          const found = d.servers.find((s) => s.id === cur.id);
          if (found) return found;
        }
        const best = d.servers.find((s) => s.online) ?? d.servers[0] ?? null;
        return best;
      });
    } catch {}
  }, []);

  const reloadProfiles = useCallback(async () => {
    try {
      const d = (await api("/api/profiles")) as { profiles: Profile[] };
      setProfiles(d.profiles);
    } catch {}
  }, []);

  const refreshSession = useCallback(async () => {
    try {
      const d = (await api("/api/session/active")) as { active: Session | null };
      setSession(d.active);
    } catch {}
  }, []);

  // Boot: seed + carregar tudo + restaurar admin
  useEffect(() => {
    (async () => {
      try {
        const s = (await api("/api/admin/seed")) as { needsSeed: boolean };
        if (s.needsSeed) {
          await api("/api/admin/seed", { method: "POST" });
        }
      } catch {}
      await Promise.all([reloadServers(), reloadProfiles(), refreshSession()]);
      try {
        const token = localStorage.getItem("cvpn_admin_token");
        if (token) {
          const u = Buffer.from(token, "base64").toString("utf8").split(":")[0];
          if (u) setAdminUser(u);
        }
      } catch {}
      const savedTheme = localStorage.getItem("cvpn_theme");
      if (savedTheme === "light") {
        setTheme("light");
        document.body.classList.add("light");
      }
      setBooted(true);
    })();
  }, [reloadServers, reloadProfiles, refreshSession]);

  const toggleTheme = () => {
    const next = theme === "dark" ? "light" : "dark";
    setTheme(next);
    document.body.classList.toggle("light", next === "light");
    localStorage.setItem("cvpn_theme", next);
  };

  return (
    <div className="min-h-screen pb-28 md:pb-10">
      {/* Header */}
      <header className="sticky top-0 z-40 backdrop-blur-xl border-b" style={{ background: "rgba(5,8,26,0.75)", borderColor: "rgba(99,140,255,0.2)" }}>
        <div className="max-w-6xl mx-auto px-3 sm:px-4 py-2.5 flex items-center gap-2.5">
          <CrownLogo />
          <div className="min-w-0 flex-1">
            <h1 className="font-black text-base sm:text-xl leading-none tracking-tight">
              Conexões <span className="text-amber-400">VPN</span>
            </h1>
            <p className="text-[10px] sm:text-[11px] opacity-70 italic">Conecte-se sem limites! · Unitel • Africell • ANGOSAT-2</p>
          </div>
          <div className="hidden sm:flex items-center gap-1.5 text-[11px] font-bold">
            <span className={`px-2.5 py-1 rounded-full border ${operator === "UNITEL" ? "border-orange-400/60 bg-orange-500/20 text-orange-200" : "border-white/10 opacity-50"}`}>UNITEL</span>
            <span className={`px-2.5 py-1 rounded-full border ${operator === "AFRICELL" ? "border-purple-400/60 bg-purple-500/20 text-purple-200" : "border-white/10 opacity-50"}`}>AFRICELL</span>
          </div>
          {session?.active && (
            <span className="hidden sm:flex badge bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 items-center gap-1">
              <Wifi className="w-3 h-3" /> SESSÃO ACTIVA
            </span>
          )}
          <button onClick={toggleTheme} className="btn-ghost rounded-xl p-2 cursor-pointer" title={theme === "dark" ? "Tema claro" : "Tema escuro"}>
            {theme === "dark" ? <Sun className="w-5 h-5 text-amber-300" /> : <Moon className="w-5 h-5 text-indigo-600" />}
          </button>
        </div>
        {/* Nav desktop */}
        <nav className="hidden md:block border-t border-white/10">
          <div className="max-w-6xl mx-auto px-4 flex gap-1.5 py-2 overflow-x-auto">
            {TABS.map((t) => (
              <button
                key={t.key}
                onClick={() => setTab(t.key)}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl border text-[13px] font-bold whitespace-nowrap cursor-pointer transition ${tab === t.key ? "tab-active" : "border-transparent opacity-70 hover:opacity-100 hover:bg-white/5"}`}
              >
                {t.icon} {t.label}
              </button>
            ))}
          </div>
        </nav>
      </header>

      {/* Conteúdo */}
      <main className="max-w-6xl mx-auto px-3 sm:px-4 pt-4">
        {!booted ? (
          <div className="cv-card p-10 text-center">
            <Crown className="w-12 h-12 mx-auto text-amber-400 floaty" />
            <p className="font-extrabold mt-3">A iniciar Conexões VPN…</p>
            <p className="text-xs opacity-60 mt-1">A preparar base de dados e verificações iniciais.</p>
          </div>
        ) : (
          <>
            {tab === "inicio" && (
              <HomePanel
                operator={operator} setOperator={setOperator}
                servers={servers} activeServer={activeServer} setActiveServer={setActiveServer}
                profiles={profiles} activeProfile={activeProfile} setActiveProfile={setActiveProfile}
                session={session} refreshSession={refreshSession} notify={notify}
              />
            )}
            {tab === "operadoras" && <OperatorsPanel notify={notify} />}
            {tab === "scanner" && <ScannerPanel operator={operator} notify={notify} />}
            {tab === "servidores" && (
              <ServersPanel servers={servers} reloadServers={reloadServers} activeServer={activeServer} setActiveServer={setActiveServer} notify={notify} />
            )}
            {tab === "tuneis" && (
              <TunnelsPanel profiles={profiles} reloadProfiles={reloadProfiles} servers={servers} activeProfile={activeProfile} setActiveProfile={setActiveProfile} notify={notify} />
            )}
            {tab === "satelite" && <SatellitePanel notify={notify} />}
            {tab === "stats" && <StatsPanel notify={notify} />}
            {tab === "logs" && <LogsPanel notify={notify} />}
            {tab === "admin" && <AdminPanel notify={notify} adminUser={adminUser} setAdminUser={setAdminUser} />}
          </>
        )}

        <footer className="mt-8 text-center text-[11px] opacity-60 pb-4">
          <p className="font-bold">Conexões VPN v1.0 · Unitel • Africell • ANGOSAT-2</p>
          <p className="mt-1 max-w-2xl mx-auto leading-relaxed">
            Transparência total: sem servidores inventados, sem SNI falsos, sem velocidades simuladas, sem promessas de
            internet grátis. SNI compatível ≠ tráfego gratuito. Túnel real ao nível do sistema requer a app Android (VPNService).
            Documentação e relatório de testes no painel Admin.
          </p>
        </footer>
      </main>

      {/* Nav mobile */}
      <nav className="md:hidden fixed bottom-0 inset-x-0 z-40 border-t backdrop-blur-xl" style={{ background: "rgba(5,8,26,0.92)", borderColor: "rgba(99,140,255,0.25)" }}>
        <div className="grid grid-cols-5 gap-0.5 px-1 py-1.5">
          {TABS.slice(0, 4).map((t) => (
            <MobileTab key={t.key} active={tab === t.key} onClick={() => setTab(t.key)} icon={t.icon} label={t.label} />
          ))}
          <MobileTab active={tab === "admin" || tab === "stats" || tab === "logs" || tab === "tuneis" || tab === "satelite"} onClick={() => setTab(tab === "admin" ? "inicio" : nextMoreTab(tab))} icon={<MoreIcon tab={tab} />} label={moreLabel(tab)} />
        </div>
        {(tab === "tuneis" || tab === "satelite" || tab === "stats" || tab === "logs" || tab === "admin") && (
          <div className="flex justify-center gap-1 px-2 pb-2 overflow-x-auto">
            {(["tuneis", "satelite", "stats", "logs", "admin"] as TabKey[]).map((k) => {
              const t = TABS.find((x) => x.key === k)!;
              return (
                <button key={k} onClick={() => setTab(k)} className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold border cursor-pointer ${tab === k ? "border-amber-400/60 bg-amber-500/15 text-amber-200" : "border-white/10 opacity-70"}`}>
                  {t.icon} {t.label}
                </button>
              );
            })}
          </div>
        )}
      </nav>

      {/* Toasts */}
      <div className="fixed top-16 right-3 z-50 space-y-2 w-[calc(100%-1.5rem)] max-w-sm">
        {toasts.map((t) => (
          <div key={t.id} className={`cv-card p-3 flex gap-2 items-start text-xs font-semibold ${t.kind === "ok" ? "border-l-4" : t.kind === "err" ? "border-l-4" : ""}`} style={{ borderLeftColor: t.kind === "ok" ? "#22c55e" : t.kind === "err" ? "#ef4444" : "#00c2ff" }}>
            {t.kind === "ok" ? <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" /> : t.kind === "err" ? <XCircle className="w-4 h-4 text-red-400 shrink-0" /> : <Info className="w-4 h-4 text-cyan-300 shrink-0" />}
            <span>{t.msg}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function nextMoreTab(tab: TabKey): TabKey {
  const order: TabKey[] = ["tuneis", "satelite", "stats", "logs", "admin"];
  const i = order.indexOf(tab);
  return i >= 0 ? order[(i + 1) % order.length] : "tuneis";
}

function moreLabel(tab: TabKey): string {
  const t = TABS.find((x) => x.key === tab);
  if (["tuneis", "satelite", "stats", "logs", "admin"].includes(tab)) return t?.label ?? "Mais";
  return "Mais";
}

function MoreIcon({ tab }: { tab: TabKey }) {
  const t = TABS.find((x) => x.key === tab);
  if (["tuneis", "satelite", "stats", "logs", "admin"].includes(tab)) return <>{t?.icon}</>;
  return <KeyRound className="w-5 h-5" />;
}

function MobileTab({ active, onClick, icon, label }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string }) {
  return (
    <button onClick={onClick} className={`flex flex-col items-center gap-0.5 py-1.5 rounded-xl cursor-pointer ${active ? "text-amber-300" : "opacity-60"}`}>
      {icon}
      <span className="text-[9px] font-bold">{label}</span>
      {active && <span className="w-6 h-0.5 rounded-full bg-amber-400" />}
    </button>
  );
}

export function CrownLogo() {
  return (
    <span className="relative shrink-0 w-10 h-10 rounded-2xl flex items-center justify-center" style={{ background: "linear-gradient(135deg,#1b2560,#4c1d95)", border: "1px solid rgba(245,197,24,0.5)", boxShadow: "0 0 20px rgba(245,197,24,0.25)" }}>
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
        <path d="M3 7l3.5 3L12 4l5.5 6L21 7l-1.8 9.5H4.8L3 7z" fill="#f5c518" stroke="#b8860b" strokeWidth="1" />
        <circle cx="12" cy="13.4" r="2.2" fill="#1b2560" stroke="#00c2ff" strokeWidth="1.2" />
        <circle cx="12" cy="13.4" r="0.8" fill="#00c2ff" />
        <path d="M7 13.4h2.6M14.4 13.4H17" stroke="#00c2ff" strokeWidth="1.2" strokeLinecap="round" />
      </svg>
    </span>
  );
}
