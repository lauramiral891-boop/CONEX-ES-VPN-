import { db } from "@/db";
import { vpnProfiles } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const pid = Number(id);
  if (!Number.isInteger(pid)) return Response.json({ ok: false, error: "ID inválido" }, { status: 400 });
  const rows = await db.select().from(vpnProfiles).where(eq(vpnProfiles.id, pid)).limit(1);
  if (rows.length === 0) return Response.json({ ok: false, error: "Perfil não encontrado" }, { status: 404 });
  const p = rows[0];
  // Exportação SEM credenciais sensíveis (palavra-passe nunca exportada em claro)
  const payload = {
    app: "Conexões VPN",
    version: 1,
    exportedAt: new Date().toISOString(),
    profile: {
      name: p.name,
      protocol: p.protocol,
      host: p.host,
      port: p.port,
      sni: p.sni,
      method: p.method,
      payload: p.payload,
      username: p.username,
      hasPassword: !!p.passwordEnc,
      autoReconnect: p.autoReconnect,
      dnsProtection: p.dnsProtection,
      dnsChoice: p.dnsChoice,
      extraConfig: p.extraConfig,
    },
    note: "Credenciais sensíveis não são exportadas. Reintroduza a palavra-passe após importar.",
  };
  return new Response(JSON.stringify(payload, null, 2), {
    status: 200,
    headers: {
      "Content-Type": "application/json",
      "Content-Disposition": `attachment; filename="conexoes-vpn-${p.name.replace(/[^a-z0-9-_]+/gi, "-")}.cvpn.json"`,
    },
  });
}
