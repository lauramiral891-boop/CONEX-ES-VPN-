import { db } from "@/db";
import { adminUsers } from "@/db/schema";
import { eq } from "drizzle-orm";
import { verifyPassword } from "./crypto";

export function parseBasicAuth(req: Request): {
  user: string;
  pass: string;
} | null {
  const h =
    req.headers.get("authorization") || req.headers.get("x-admin-auth") || "";
  let token = "";
  if (h.toLowerCase().startsWith("basic ")) token = h.slice(6).trim();
  else if (h) token = h.trim();
  if (!token) return null;
  try {
    const decoded = Buffer.from(token, "base64").toString("utf8");
    const idx = decoded.indexOf(":");
    if (idx <= 0) return null;
    return {
      user: decoded.slice(0, idx),
      pass: decoded.slice(idx + 1),
    };
  } catch {
    return null;
  }
}

export async function requireAdmin(req: Request): Promise<{
  ok: boolean;
  username?: string;
  error?: string;
}> {
  const creds = parseBasicAuth(req);
  if (!creds) return { ok: false, error: "Autenticação necessária" };
  try {
    const rows = await db
      .select()
      .from(adminUsers)
      .where(eq(adminUsers.username, creds.user))
      .limit(1);
    if (rows.length === 0) return { ok: false, error: "Credenciais inválidas" };
    const valid = verifyPassword(creds.pass, rows[0].passwordHash);
    if (!valid) return { ok: false, error: "Credenciais inválidas" };
    return { ok: true, username: rows[0].username };
  } catch (e) {
    return {
      ok: false,
      error: e instanceof Error ? e.message : "Falha de autenticação",
    };
  }
}
