import { db } from "@/db";
import { featureStatus } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { requireAdmin } from "@/lib/admin-auth";
import { writeLog } from "@/lib/server-log";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db.select().from(featureStatus).orderBy(asc(featureStatus.id));
    return Response.json({ ok: true, features: rows });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return Response.json({ ok: false, error: auth.error }, { status: 401 });
  try {
    const body = (await req.json()) as { feature?: string; status?: string; description?: string };
    const feature = String(body.feature || "").trim();
    const status = String(body.status || "").toUpperCase();
    if (!feature) return Response.json({ ok: false, error: "Funcionalidade obrigatória" }, { status: 400 });
    if (!["IMPLEMENTADO", "EM_TESTE", "INDISPONIVEL"].includes(status)) {
      return Response.json({ ok: false, error: "Estado inválido" }, { status: 400 });
    }
    const updated = await db.update(featureStatus).set({
      status,
      description: body.description ? String(body.description).slice(0, 1000) : null,
      updatedAt: new Date(),
    }).where(eq(featureStatus.feature, feature)).returning();
    if (updated.length === 0) return Response.json({ ok: false, error: "Funcionalidade não encontrada" }, { status: 404 });
    await writeLog("admin", "info", `${auth.username} marcou "${feature}" como ${status}`);
    return Response.json({ ok: true, feature: updated[0] });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}
