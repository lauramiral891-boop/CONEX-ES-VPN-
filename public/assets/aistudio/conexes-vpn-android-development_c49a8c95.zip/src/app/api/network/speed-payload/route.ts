export const dynamic = "force-dynamic";

// Payload real para medição de velocidade de download.
// O cliente mede bytes recebidos / tempo decorrido — sem números fictícios.
export async function GET(req: Request) {
  const url = new URL(req.url);
  const kb = Math.min(Math.max(Number(url.searchParams.get("size") || 512), 16), 8192);
  const bytes = kb * 1024;
  const buf = Buffer.alloc(bytes, "x");
  const u8 = new Uint8Array(buf);
  return new Response(u8, {
    status: 200,
    headers: {
      "Content-Type": "application/octet-stream",
      "Content-Length": String(bytes),
      "Cache-Control": "no-store",
      "X-Payload-Bytes": String(bytes),
    },
  });
}

// Upload real: o cliente envia bytes, o servidor conta e devolve o total.
export async function POST(req: Request) {
  const started = Date.now();
  try {
    const blob = await req.arrayBuffer();
    const ms = Math.max(Date.now() - started, 1);
    const bytes = blob.byteLength;
    const mbps = (bytes * 8) / (ms / 1000) / 1_000_000;
    return Response.json({
      ok: true,
      bytesReceived: bytes,
      ms,
      mbps: Math.round(mbps * 100) / 100,
      measuredAt: new Date().toISOString(),
    });
  } catch (e) {
    return Response.json(
      { ok: false, error: e instanceof Error ? e.message : "Falha no upload" },
      { status: 500 }
    );
  }
}
