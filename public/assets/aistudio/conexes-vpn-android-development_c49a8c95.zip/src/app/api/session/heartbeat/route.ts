import { db } from "@/db";
import { connectionSessions } from "@/db/schema";
import { eq } from "drizzle-orm";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

// Contabiliza APENAS tráfego medido de forma real (ex.: testes de velocidade).
// Nunca inventa bytes.
export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { id?: number; bytesUp?: number; bytesDown?: number };
    const id = Number(body.id);
    if (!Number.isInteger(id) || id <= 0) return Response.json({ ok: false, error: "ID inválido" }, { status: 400 });
    const up = Math.max(0, Math.floor(Number(body.bytesUp) || 0));
    const down = Math.max(0, Math.floor(Number(body.bytesDown) || 0));
    if (up === 0 && down === 0) return Response.json({ ok: true, counted: false });
    if (up > 500_000_000 || down > 500_000_000) {
      return Response.json({ ok: false, error: "Valor excessivo — só tráfego medido é aceite" }, { status: 400 });
    }
    const updated = await db.update(connectionSessions).set({
      bytesUp: sql`${connectionSessions.bytesUp} + ${up}`,
      bytesDown: sql`${connectionSessions.bytesDown} + ${down}`,
    }).where(eq(connectionSessions.id, id)).returning();
    if (updated.length === 0) return Response.json({ ok: false, error: "Sessão não encontrada" }, { status: 404 });
    return Response.json({ ok: true, session: updated[0] });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}
