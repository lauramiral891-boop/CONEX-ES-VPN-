import { db } from "@/db";
import { servers } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireAdmin } from "@/lib/admin-auth";
import { writeLog } from "@/lib/server-log";
import { sanitizeDomain, isValidDomainOrIp } from "@/lib/network";

export const dynamic = "force-dynamic";

export async function PUT(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return Response.json({ ok: false, error: auth.error }, { status: 401 });
  const { id } = await ctx.params;
  const sid = Number(id);
  if (!Number.isInteger(sid)) return Response.json({ ok: false, error: "ID inválido" }, { status: 400 });
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const patch: Record<string, unknown> = { updatedAt: new Date() };
    if (body["name"] !== undefined) patch["name"] = String(body["name"]).slice(0, 120);
    if (body["address"] !== undefined) {
      const a = sanitizeDomain(String(body["address"]));
      if (!isValidDomainOrIp(a)) return Response.json({ ok: false, error: "Endereço inválido" }, { status: 400 });
      patch["address"] = a;
    }
    if (body["port"] !== undefined) {
      const p = Number(body["port"]);
      if (!Number.isInteger(p) || p <= 0 || p > 65535) return Response.json({ ok: false, error: "Porta inválida" }, { status: 400 });
      patch["port"] = p;
    }
    for (const k of ["country", "region", "protocol", "operator", "kind", "notes"]) {
      if (body[k] !== undefined) patch[k] = String(body[k]).slice(0, 200);
    }
    if (body["enabled"] !== undefined) patch["enabled"] = body["enabled"] === true;
    if (body["loadPercent"] !== undefined) {
      const l = body["loadPercent"] === null ? null : Number(body["loadPercent"]);
      patch["loadPercent"] = l;
    }
    const updated = await db.update(servers).set(patch).where(eq(servers.id, sid)).returning();
    if (updated.length === 0) return Response.json({ ok: false, error: "Servidor não encontrado" }, { status: 404 });
    await writeLog("admin", "info", `Servidor #${sid} atualizado por ${auth.username}`);
    return Response.json({ ok: true, server: updated[0] });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}

export async function DELETE(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return Response.json({ ok: false, error: auth.error }, { status: 401 });
  const { id } = await ctx.params;
  const sid = Number(id);
  if (!Number.isInteger(sid)) return Response.json({ ok: false, error: "ID inválido" }, { status: 400 });
  try {
    const deleted = await db.delete(servers).where(eq(servers.id, sid)).returning({ id: servers.id });
    if (deleted.length === 0) return Response.json({ ok: false, error: "Servidor não encontrado" }, { status: 404 });
    await writeLog("admin", "warn", `Servidor #${sid} removido por ${auth.username}`);
    return Response.json({ ok: true, deleted: sid });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}
