import { db } from "@/db";
import { satProfiles, networkTests } from "@/db/schema";
import { eq } from "drizzle-orm";
import { testTcp, measureLatency, resolveDns } from "@/lib/network";
import { writeLog, touchDaily, jsonDetails } from "@/lib/server-log";

export const dynamic = "force-dynamic";
export const maxDuration = 90;

// Testa disponibilidade do terminal/gateway ANGOSAT-2 configurado.
// NÃO simula acesso ao satélite: só testa o equipamento/rede configurado.
export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { id?: number };
    const id = Number(body.id);
    if (!Number.isInteger(id)) return Response.json({ ok: false, error: "ID inválido" }, { status: 400 });
    const rows = await db.select().from(satProfiles).where(eq(satProfiles.id, id)).limit(1);
    if (rows.length === 0) return Response.json({ ok: false, error: "Perfil não encontrado" }, { status: 404 });
    const prof = rows[0];
    await writeLog("satelite", "info", `Teste ANGOSAT-2: ${prof.name} (${prof.endpointIp})`);

    const checks: Record<string, unknown> = {};
    // 1) DNS de referência
    checks["dns"] = await resolveDns("google.com");
    // 2) TCP ao terminal em portas comuns de gestão
    const tcpPorts = [443, 80, 22, 8080];
    const tcpResults: Record<string, unknown> = {};
    for (const p of tcpPorts) {
      tcpResults[String(p)] = await testTcp(prof.endpointIp, p, 4000);
    }
    checks["tcp"] = tcpResults;
    // 3) Latência ao endpoint (porta 443; fallback 80)
    let lat = await measureLatency(prof.endpointIp, 443, 3, 5000);
    if (!lat.ok) lat = await measureLatency(prof.endpointIp, 80, 3, 5000);
    checks["latencia"] = lat;

    const anyTcp = Object.values(tcpResults).some((v) => (v as { ok: boolean }).ok);
    const status = anyTcp || lat.ok ? "ALCANCAVEL" : "INALCANCAVEL";

    await db.update(satProfiles).set({
      lastStatus: status,
      lastLatencyMs: lat.avg,
      lastCheck: new Date(),
    }).where(eq(satProfiles.id, id)).catch(() => {});
    await db.insert(networkTests).values({
      operator: "ANGOSAT-2",
      testType: "gateway",
      target: prof.endpointIp,
      success: status === "ALCANCAVEL",
      latencyMs: lat.avg,
      details: jsonDetails(checks),
    }).catch(() => {});
    await touchDaily({ tests: 1 });
    await writeLog(
      "satelite",
      status === "ALCANCAVEL" ? "success" : "error",
      `ANGOSAT-2 ${prof.name}: ${status}${lat.avg !== null ? ` — ${lat.avg}ms` : ""}`,
      jsonDetails({ tcp: tcpResults, lat })
    );

    return Response.json({
      ok: true,
      profile: { id: prof.id, name: prof.name, endpointIp: prof.endpointIp },
      status,
      checks,
      measuredAt: new Date().toISOString(),
      honesty: "Teste ao terminal/gateway configurado. Sem equipamento e serviço autorizado, o estado é INALCANCAVEL — nunca simulado.",
    });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}
