import { db } from "@/db";
import { vpnProfiles } from "@/db/schema";
import { eq } from "drizzle-orm";
import { encryptSecret } from "@/lib/crypto";
import { writeLog } from "@/lib/server-log";
import { sanitizeDomain, isValidDomainOrIp } from "@/lib/network";

export const dynamic = "force-dynamic";

export async function PUT(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const pid = Number(id);
  if (!Number.isInteger(pid)) return Response.json({ ok: false, error: "ID inválido" }, { status: 400 });
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const patch: Record<string, unknown> = { updatedAt: new Date() };
    if (body["name"] !== undefined) patch["name"] = String(body["name"]).slice(0, 120);
    if (body["host"] !== undefined) {
      const h = sanitizeDomain(String(body["host"]));
      if (!isValidDomainOrIp(h)) return Response.json({ ok: false, error: "Anfitrião inválido" }, { status: 400 });
      patch["host"] = h;
    }
    if (body["port"] !== undefined) {
      const p = Number(body["port"]);
      if (!Number.isInteger(p) || p <= 0 || p > 65535) return Response.json({ ok: false, error: "Porta inválida" }, { status: 400 });
      patch["port"] = p;
    }
    for (const k of ["protocol", "method", "payload", "username", "dnsChoice", "extraConfig"]) {
      if (body[k] !== undefined) patch[k] = body[k] ? String(body[k]).slice(0, 8000) : null;
    }
    if (body["sni"] !== undefined) patch["sni"] = body["sni"] ? sanitizeDomain(String(body["sni"])) : null;
    if (body["serverId"] !== undefined) patch["serverId"] = body["serverId"] ? Number(body["serverId"]) : null;
    if (body["autoReconnect"] !== undefined) patch["autoReconnect"] = body["autoReconnect"] === true;
    if (body["dnsProtection"] !== undefined) patch["dnsProtection"] = body["dnsProtection"] === true;
    if (body["password"] !== undefined) {
      patch["passwordEnc"] = body["password"] ? encryptSecret(String(body["password"]).slice(0, 500)) : null;
    }
    const updated = await db.update(vpnProfiles).set(patch).where(eq(vpnProfiles.id, pid)).returning({ id: vpnProfiles.id });
    if (updated.length === 0) return Response.json({ ok: false, error: "Perfil não encontrado" }, { status: 404 });
    await writeLog("perfil", "info", `Perfil #${pid} atualizado`);
    return Response.json({ ok: true, id: pid });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}

export async function DELETE(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const pid = Number(id);
  if (!Number.isInteger(pid)) return Response.json({ ok: false, error: "ID inválido" }, { status: 400 });
  try {
    const deleted = await db.delete(vpnProfiles).where(eq(vpnProfiles.id, pid)).returning({ id: vpnProfiles.id });
    if (deleted.length === 0) return Response.json({ ok: false, error: "Perfil não encontrado" }, { status: 404 });
    await writeLog("perfil", "warn", `Perfil #${pid} removido`);
    return Response.json({ ok: true, deleted: pid });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}
