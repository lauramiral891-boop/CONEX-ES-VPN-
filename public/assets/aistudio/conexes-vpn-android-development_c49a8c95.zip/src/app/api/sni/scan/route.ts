import { db } from "@/db";
import { sniResults } from "@/db/schema";
import {
  resolveDns,
  testTcp,
  testTls,
  sanitizeDomain,
  isValidDomainOrIp,
} from "@/lib/network";
import { writeLog, touchDaily, jsonDetails } from "@/lib/server-log";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

type ScanMode = "manual" | "auto" | "deep" | "live";

const PORTS_BY_MODE: Record<ScanMode, number[]> = {
  manual: [443, 8443],
  auto: [443, 8443],
  deep: [443, 8443, 80, 2083, 2087, 9443],
  live: [443, 8443],
};

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as {
      domains?: string[];
      operator?: string;
      mode?: ScanMode;
      ports?: number[];
    };
    const operator = (body.operator || "GERAL").toUpperCase();
    const mode: ScanMode =
      body.mode === "auto" || body.mode === "deep" || body.mode === "live" || body.mode === "manual"
        ? body.mode
        : "manual";
    const rawDomains = Array.isArray(body.domains) ? body.domains : [];
    if (rawDomains.length === 0) {
      return Response.json({ ok: false, error: "Sem domínios para testar" }, { status: 400 });
    }
    if (rawDomains.length > 20) {
      return Response.json({ ok: false, error: "Máximo 20 domínios por pedido" }, { status: 400 });
    }
    let ports = Array.isArray(body.ports) && body.ports.length > 0
      ? [...new Set(body.ports.map(Number).filter((p) => Number.isInteger(p) && p > 0 && p <= 65535))].slice(0, 8)
      : PORTS_BY_MODE[mode];

    const domains = rawDomains.map(sanitizeDomain).filter((d) => d.length > 0);
    const invalid = domains.filter((d) => !isValidDomainOrIp(d));
    if (invalid.length > 0) {
      return Response.json(
        { ok: false, error: `Domínios inválidos: ${invalid.join(", ")}` },
        { status: 400 }
      );
    }

    await writeLog(
      "sni",
      "info",
      `SNI scan (${mode}) iniciado [${operator}]: ${domains.length} domínio(s), portas ${ports.join(", ")}`
    );

    const results = [];
    for (const domain of domains) {
      const started = Date.now();
      await writeLog("sni", "info", `A testar ${domain}… (DNS → TCP → TLS/SNI → medição)`);

      // Etapa 1: DNS
      const dnsR = await resolveDns(domain);
      // Etapa 2: TCP em cada porta
      const tcpHits: { port: number; ms: number }[] = [];
      const tcpErrors: string[] = [];
      if (dnsR.ok) {
        for (const port of ports) {
          const t = await testTcp(domain, port, mode === "deep" ? 6000 : 4500);
          if (t.ok && t.ms !== null) tcpHits.push({ port, ms: t.ms });
          else if (t.error) tcpErrors.push(`${port}: ${t.error}`);
        }
      }
      const portAccessible = tcpHits.length > 0;
      // Etapa 3: TLS/SNI na primeira porta acessível (preferir 443)
      let tlsR = {
        ok: false,
        ms: null as number | null,
        certValid: false,
        issuer: null as string | null,
        expiry: null as string | null,
        protocol: null as string | null,
        error: "sem porta acessível" as string | null,
      };
      if (portAccessible) {
        const ordered = [...tcpHits].sort((a, b) =>
          a.port === 443 ? -1 : b.port === 443 ? 1 : a.ms - b.ms
        );
        const best = ordered[0];
        tlsR = await testTls(domain, best.port, domain, 8000);
      }
      // Etapa 4: latência = melhor TCP medido
      const latencyMs =
        tcpHits.length > 0 ? Math.min(...tcpHits.map((t) => t.ms)) : null;

      // Classificação rigorosa
      let status = "FALHOU";
      let errorText: string | null = null;
      if (!dnsR.ok) {
        status = "FALHOU";
        errorText = `DNS: ${dnsR.error ?? "não resolveu"}`;
      } else if (!portAccessible) {
        status = "FALHOU";
        errorText = `TCP: nenhuma porta acessível (${tcpErrors.slice(0, 2).join(" | ") || "sem resposta"})`;
      } else if (tlsR.ok && tlsR.certValid) {
        status = "COMPATIVEL";
      } else if (tlsR.ok && !tlsR.certValid) {
        status = "PARCIAL";
        errorText = `TLS ok mas certificado não-validado: ${tlsR.error ?? ""}`.trim();
      } else if (tlsR.ok) {
        status = "PARCIAL";
      } else {
        status = "PARCIAL";
        errorText = `TLS: ${tlsR.error ?? "falhou"}`;
      }

      const elapsed = Date.now() - started;
      const row = {
        domain,
        operator,
        mode,
        dnsResolved: dnsR.ok,
        dnsIps: dnsR.ips.join(", ").slice(0, 500),
        portsTested: ports.join(","),
        portAccessible,
        accessiblePorts: tcpHits.map((t) => `${t.port}(${t.ms}ms)`).join(", ").slice(0, 500),
        tlsOk: tlsR.ok,
        certValid: tlsR.certValid,
        certIssuer: (tlsR.issuer ?? "").slice(0, 300),
        certExpiry: tlsR.expiry ?? "",
        tlsProtocol: tlsR.protocol ?? "",
        latencyMs,
        status,
        errorText: (errorText ?? "").slice(0, 1000),
      };
      try {
        const inserted = await db.insert(sniResults).values(row).returning({ id: sniResults.id });
        results.push({ id: inserted[0]?.id ?? null, ...row, elapsedMs: elapsed });
      } catch (e) {
        results.push({ id: null, ...row, elapsedMs: elapsed, saveError: e instanceof Error ? e.message : "falha ao guardar" });
      }

      await writeLog(
        "sni",
        status === "COMPATIVEL" ? "success" : status === "PARCIAL" ? "warn" : "error",
        `SNI ${domain}: ${status} — DNS ${dnsR.ok ? "ok" : "falhou"} · TCP ${portAccessible ? "ok" : "falhou"} · TLS ${tlsR.ok ? "ok" : "falhou"} · ${latencyMs ?? "—"}ms`,
        jsonDetails({ dns: dnsR, tcpHits, tls: tlsR })
      );
    }

    await touchDaily({ tests: domains.length });
    const counts = {
      COMPATIVEL: results.filter((r) => r.status === "COMPATIVEL").length,
      PARCIAL: results.filter((r) => r.status === "PARCIAL").length,
      FALHOU: results.filter((r) => r.status === "FALHOU").length,
    };
    await writeLog(
      "sni",
      "success",
      `SNI scan (${mode}) concluído [${operator}]: ${counts.COMPATIVEL} compatível, ${counts.PARCIAL} parcial, ${counts.FALHOU} falhou`
    );

    return Response.json({
      ok: true,
      operator,
      mode,
      counts,
      results,
      measuredAt: new Date().toISOString(),
      honesty:
        "COMPATÍVEL = DNS + TCP + TLS/SNI com certificado válido. Isto NÃO prova isenção de tarifação nem 'internet grátis'. A tarifação exige teste autorizado da operadora.",
    });
  } catch (e) {
    await writeLog("sni", "error", `SNI scan falhou: ${e instanceof Error ? e.message : "erro"}`);
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}
