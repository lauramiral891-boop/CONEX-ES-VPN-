import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
  bigint,
  index,
} from "drizzle-orm/pg-core";

// Servidores reais geridos pelo administrador.
// Nenhum servidor é inventado: a semente inicial contém apenas
// endpoints públicos de diagnóstico + portais das operadoras.
export const servers = pgTable("servers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  country: text("country").notNull().default("Angola"),
  region: text("region").notNull().default("Angola"), // Angola | Africa | Europa | America | Asia | Global
  address: text("address").notNull(),
  port: integer("port").notNull().default(443),
  protocol: text("protocol").notNull().default("SSL/TLS"),
  operator: text("operator").notNull().default("GERAL"), // UNITEL | AFRICELL | ANGOSAT-2 | GERAL
  kind: text("kind").notNull().default("diagnostico"), // diagnostico | vpn | portal
  online: boolean("online").notNull().default(false),
  lastPingMs: integer("last_ping_ms"),
  lastCheck: timestamp("last_check"),
  loadPercent: integer("load_percent"),
  enabled: boolean("enabled").notNull().default(true),
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Resultados do SNI Scanner / SNI Auto Finder
export const sniResults = pgTable(
  "sni_results",
  {
    id: serial("id").primaryKey(),
    domain: text("domain").notNull(),
    operator: text("operator").notNull().default("GERAL"),
    mode: text("mode").notNull().default("manual"), // manual | auto | deep | live
    dnsResolved: boolean("dns_resolved").notNull().default(false),
    dnsIps: text("dns_ips"),
    portsTested: text("ports_tested"),
    portAccessible: boolean("port_accessible").notNull().default(false),
    accessiblePorts: text("accessible_ports"),
    tlsOk: boolean("tls_ok").notNull().default(false),
    certValid: boolean("cert_valid").notNull().default(false),
    certIssuer: text("cert_issuer"),
    certExpiry: text("cert_expiry"),
    tlsProtocol: text("tls_protocol"),
    latencyMs: integer("latency_ms"),
    status: text("status").notNull().default("PENDENTE"), // COMPATIVEL | PARCIAL | FALHOU | PENDENTE
    errorText: text("error_text"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("sni_domain_idx").on(t.domain), index("sni_created_idx").on(t.createdAt)]
);

// Testes de rede por operadora
export const networkTests = pgTable("network_tests", {
  id: serial("id").primaryKey(),
  operator: text("operator").notNull(),
  testType: text("test_type").notNull(), // dns | tcp | tls | latencia | diagnostico | gateway
  target: text("target").notNull(),
  success: boolean("success").notNull().default(false),
  latencyMs: integer("latency_ms"),
  details: text("details"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Perfis de túnel VPN (configurações guardadas pelo utilizador)
export const vpnProfiles = pgTable("vpn_profiles", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  serverId: integer("server_id"),
  protocol: text("protocol").notNull().default("SSL/TLS"),
  host: text("host").notNull(),
  port: integer("port").notNull().default(443),
  sni: text("sni"),
  method: text("method").default("AES-256-GCM"),
  payload: text("payload").default("auto"),
  username: text("username"),
  passwordEnc: text("password_enc"),
  autoReconnect: boolean("auto_reconnect").notNull().default(true),
  dnsProtection: boolean("dns_protection").notNull().default(true),
  dnsChoice: text("dns_choice").default("1.1.1.1, 8.8.8.8"),
  extraConfig: text("extra_config"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Sessões de monitorização (na Web não existe túnel kernel;
// o túnel real requer a app Android com VPNService — indicado na UI)
export const connectionSessions = pgTable("connection_sessions", {
  id: serial("id").primaryKey(),
  profileId: integer("profile_id"),
  profileName: text("profile_name"),
  operator: text("operator").default("GERAL"),
  serverName: text("server_name"),
  startedAt: timestamp("started_at").notNull().defaultNow(),
  endedAt: timestamp("ended_at"),
  durationSec: integer("duration_sec").notNull().default(0),
  bytesUp: bigint("bytes_up", { mode: "number" }).notNull().default(0),
  bytesDown: bigint("bytes_down", { mode: "number" }).notNull().default(0),
  publicIp: text("public_ip"),
  active: boolean("active").notNull().default(true),
});

// Logs da aplicação
export const appLogs = pgTable(
  "app_logs",
  {
    id: serial("id").primaryKey(),
    level: text("level").notNull().default("info"), // info | success | warn | error
    category: text("category").notNull().default("sistema"),
    message: text("message").notNull(),
    details: text("details"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("logs_created_idx").on(t.createdAt)]
);

// Utilizadores administrativos (password com hash, nunca texto simples)
export const adminUsers = pgTable("admin_users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  role: text("role").notNull().default("admin"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Perfis de satélite ANGOSAT-2 (gateway/modem/terminal)
export const satProfiles = pgTable("sat_profiles", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  endpointIp: text("endpoint_ip").notNull(),
  gateway: text("gateway"),
  dnsPrimary: text("dns_primary").default("1.1.1.1"),
  dnsSecondary: text("dns_secondary").default("8.8.8.8"),
  username: text("username"),
  passwordEnc: text("password_enc"),
  notes: text("notes"),
  lastStatus: text("last_status").default("NUNCA_TESTADO"),
  lastLatencyMs: integer("last_latency_ms"),
  lastCheck: timestamp("last_check"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Estado das funcionalidades: IMPLEMENTADO | EM_TESTE | INDISPONIVEL
export const featureStatus = pgTable("feature_status", {
  id: serial("id").primaryKey(),
  feature: text("feature").notNull().unique(),
  status: text("status").notNull().default("EM_TESTE"),
  description: text("description"),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Estatística diária agregada
export const dailyStats = pgTable("daily_stats", {
  id: serial("id").primaryKey(),
  day: text("day").notNull().unique(), // YYYY-MM-DD
  bytesUp: bigint("bytes_up", { mode: "number" }).notNull().default(0),
  bytesDown: bigint("bytes_down", { mode: "number" }).notNull().default(0),
  sessions: integer("sessions").notNull().default(0),
  totalDurationSec: integer("total_duration_sec").notNull().default(0),
  testsRun: integer("tests_run").notNull().default(0),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});
