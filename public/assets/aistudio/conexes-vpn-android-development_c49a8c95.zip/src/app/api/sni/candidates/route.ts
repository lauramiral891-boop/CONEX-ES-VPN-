export const dynamic = "force-dynamic";

// Candidatos de fontes públicas e autorizadas.
// ATENÇÃO: estar nesta lista NÃO significa SNI funcional nem tráfego gratuito.
// Cada domínio tem de passar pelo pipeline real: DNS → TCP → TLS/SNI → medição.
const CANDIDATES: Record<string, { domain: string; source: string; note: string }[]> = {
  UNITEL: [
    { domain: "unitel.ao", source: "portal-operadora", note: "Portal oficial Unitel" },
    { domain: "www.unitel.ao", source: "portal-operadora", note: "Portal oficial Unitel (www)" },
    { domain: "net.unitel.ao", source: "subdominio-publico", note: "Subdomínio público — verificar DNS" },
    { domain: "api.unitel.ao", source: "subdominio-publico", note: "Subdomínio público — verificar DNS" },
    { domain: "myunitel.unitel.ao", source: "subdominio-publico", note: "App/portal cliente — verificar DNS" },
    { domain: "cdn.unitel.ao", source: "subdominio-publico", note: "CDN — verificar DNS" },
    { domain: "www.gov.ao", source: "governo-ao", note: "Portal do Governo de Angola" },
    { domain: "sepe.gov.ao", source: "governo-ao", note: "SEPE — serviços públicos" },
    { domain: "bna.ao", source: "instituicao-ao", note: "Banco Nacional de Angola" },
    { domain: "inacom.ao", source: "instituicao-ao", note: "INACOM — regulador" },
  ],
  AFRICELL: [
    { domain: "africell.ao", source: "portal-operadora", note: "Portal oficial Africell" },
    { domain: "www.africell.ao", source: "portal-operadora", note: "Portal oficial Africell (www)" },
    { domain: "api.africell.ao", source: "subdominio-publico", note: "Subdomínio público — verificar DNS" },
    { domain: "my.africell.ao", source: "subdominio-publico", note: "Área cliente — verificar DNS" },
    { domain: "cdn.africell.ao", source: "subdominio-publico", note: "CDN — verificar DNS" },
    { domain: "www.gov.ao", source: "governo-ao", note: "Portal do Governo de Angola" },
    { domain: "sepe.gov.ao", source: "governo-ao", note: "SEPE — serviços públicos" },
    { domain: "bna.ao", source: "instituicao-ao", note: "Banco Nacional de Angola" },
    { domain: "inacom.ao", source: "instituicao-ao", note: "INACOM — regulador" },
  ],
  GLOBAL: [
    { domain: "www.cloudflare.com", source: "global-cdn", note: "Referência global CDN" },
    { domain: "www.google.com", source: "global", note: "Referência global" },
    { domain: "www.microsoft.com", source: "global", note: "Referência global" },
    { domain: "www.amazon.com", source: "global", note: "Referência global" },
    { domain: "www.facebook.com", source: "global", note: "Referência global" },
  ],
};

export async function GET(req: Request) {
  const url = new URL(req.url);
  const operator = (url.searchParams.get("operator") || "UNITEL").toUpperCase();
  const list = CANDIDATES[operator] ?? [];
  const global = CANDIDATES["GLOBAL"];
  return Response.json({
    ok: true,
    operator,
    candidates: [...list, ...global],
    total: list.length + global.length,
    honesty:
      "Lista de candidatos autorizados para teste técnico. Um SNI só é COMPATÍVEL após DNS + TCP + TLS reais. Compatibilidade técnica ≠ isenção de tarifação.",
  });
}
