import { db } from "@/db";
import { connectionSessions, vpnProfiles } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { writeLog, touchDaily } from "@/lib/server-log";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as {
      profileId?: number;
      operator?: string;
      serverName?: string;
      publicIp?: string;
    };
    // Encerrar sessões activas anteriores
    const active = await db.select().from(connectionSessions).where(eq(connectionSessions.active, true));
    for (const s of active) {
      const dur = Math.floor((Date.now() - new Date(s.startedAt).getTime()) / 1000);
      await db.update(connectionSessions).set({ active: false, endedAt: new Date(), durationSec: dur }).where(eq(connectionSessions.id, s.id)).catch(() => {});
    }
    let profileName: string | null = null;
    if (body.profileId) {
      const p = await db.select().from(vpnProfiles).where(eq(vpnProfiles.id, Number(body.profileId))).limit(1);
      if (p.length > 0) profileName = p[0].name;
    }
    const operator = (body.operator || "GERAL").toUpperCase();
    const inserted = await db.insert(connectionSessions).values({
      profileId: body.profileId ? Number(body.profileId) : null,
      profileName,
      operator,
      serverName: body.serverName ? String(body.serverName).slice(0, 200) : null,
      publicIp: body.publicIp ? String(body.publicIp).slice(0, 80) : null,
      active: true,
    }).returning();

    await touchDaily({ sessions: 1 });
    await writeLog(
      "sessao",
      "success",
      `Sessão iniciada: ${profileName ?? "Monitorização"} via ${body.serverName ?? "—"} [${operator}]`,
      "Na versão Web a sessão é de MONITORIZAÇÃO (temporizador + medições reais). O túnel cifrado real requer a app Android com VPNService."
    );
    return Response.json({
      ok: true,
      session: inserted[0],
      honesty: "Sessão de monitorização Web. O túnel VPN ao nível do sistema só existe na app Android (VPNService). Nenhum tráfego é encaminhado sem o túnel real.",
    });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}
