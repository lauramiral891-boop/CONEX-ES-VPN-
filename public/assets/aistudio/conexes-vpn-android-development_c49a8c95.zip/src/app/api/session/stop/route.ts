import { db } from "@/db";
import { connectionSessions } from "@/db/schema";
import { eq } from "drizzle-orm";
import { writeLog, touchDaily } from "@/lib/server-log";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { id?: number };
    const id = Number(body.id);
    const target = Number.isInteger(id) && id > 0 ? id : null;
    let rows;
    if (target) {
      rows = await db.select().from(connectionSessions).where(eq(connectionSessions.id, target)).limit(1);
    } else {
      rows = await db.select().from(connectionSessions).where(eq(connectionSessions.active, true));
    }
    if (rows.length === 0) return Response.json({ ok: false, error: "Sem sessão activa" }, { status: 404 });
    const results = [];
    for (const s of rows) {
      const dur = Math.floor((Date.now() - new Date(s.startedAt).getTime()) / 1000);
      const up = Number(s.bytesUp) || 0;
      const down = Number(s.bytesDown) || 0;
      await db.update(connectionSessions).set({ active: false, endedAt: new Date(), durationSec: dur }).where(eq(connectionSessions.id, s.id)).catch(() => {});
      await touchDaily({ durationSec: dur, bytesUp: up, bytesDown: down });
      results.push({ id: s.id, durationSec: dur, bytesUp: up, bytesDown: down });
    }
    await writeLog("sessao", "warn", `Sessão terminada (${results.map((r) => `#${r.id} ${r.durationSec}s`).join(", ")})`);
    return Response.json({ ok: true, stopped: results });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}
