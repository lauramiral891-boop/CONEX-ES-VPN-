import { db } from "@/db";
import { servers } from "@/db/schema";
import { asc, desc, eq } from "drizzle-orm";
import { requireAdmin } from "@/lib/admin-auth";
import { writeLog } from "@/lib/server-log";
import { sanitizeDomain, isValidDomainOrIp } from "@/lib/network";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const region = url.searchParams.get("region") || "";
  const operator = url.searchParams.get("operator") || "";
  const sort = url.searchParams.get("sort") || "ping"; // ping | name | recent
  try {
    let rows = await db.select().from(servers).orderBy(asc(servers.name));
    if (region && region !== "TODOS") rows = rows.filter((r) => r.region === region);
    if (operator && operator !== "TODOS") rows = rows.filter((r) => r.operator === operator || r.operator === "GERAL");
    if (sort === "ping") {
      rows = [...rows].sort((a, b) => {
        const pa = a.lastPingMs ?? 999999;
        const pb = b.lastPingMs ?? 999999;
        if (a.online !== b.online) return a.online ? -1 : 1;
        return pa - pb;
      });
    } else if (sort === "recent") {
      rows = [...rows].sort((a, b) => {
        const ta = a.lastCheck ? new Date(a.lastCheck).getTime() : 0;
        const tb = b.lastCheck ? new Date(b.lastCheck).getTime() : 0;
        return tb - ta;
      });
    }
    return Response.json({ ok: true, total: rows.length, servers: rows });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return Response.json({ ok: false, error: auth.error }, { status: 401 });
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const name = String(body["name"] || "").trim();
    const address = sanitizeDomain(String(body["address"] || ""));
    const port = Number(body["port"]) || 443;
    if (!name || !address || !isValidDomainOrIp(address)) {
      return Response.json({ ok: false, error: "Nome e endereço real são obrigatórios" }, { status: 400 });
    }
    if (!Number.isInteger(port) || port <= 0 || port > 65535) {
      return Response.json({ ok: false, error: "Porta inválida" }, { status: 400 });
    }
    const inserted = await db
      .insert(servers)
      .values({
        name: name.slice(0, 120),
        country: String(body["country"] || "Angola").slice(0, 80),
        region: String(body["region"] || "Angola").slice(0, 40),
        address,
        port,
        protocol: String(body["protocol"] || "SSL/TLS").slice(0, 40),
        operator: String(body["operator"] || "GERAL").slice(0, 20).toUpperCase(),
        kind: String(body["kind"] || "vpn").slice(0, 20),
        notes: String(body["notes"] || "").slice(0, 500) || null,
        enabled: body["enabled"] !== false,
      })
      .returning();
    await writeLog("admin", "success", `Servidor adicionado por ${auth.username}: ${name} (${address}:${port})`);
    return Response.json({ ok: true, server: inserted[0] });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}
