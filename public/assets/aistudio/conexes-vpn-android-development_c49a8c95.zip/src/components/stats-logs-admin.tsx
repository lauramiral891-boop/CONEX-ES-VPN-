"use client";

import { useCallback, useEffect, useState } from "react";
import {
  BarChart3, ScrollText, ShieldAlert, Trash2, RefreshCw, Download, Lock,
  ArrowDown, ArrowUp, Timer, FlaskConical, Server, Users, FileWarning,
  CheckCircle2, AlertTriangle, LogOut, BookOpen,
} from "lucide-react";
import { api, apiAdmin, fmtBytes, fmtDuration, fmtDateTime, statusBadge } from "@/lib/client";

// ---------------- ESTATÍSTICAS ----------------

export function StatsPanel(props: { notify: (m: string, k?: "ok" | "err" | "info") => void }) {
  const { notify } = props;
  const [data, setData] = useState<{
    totals: Record<string, number>;
    daily: { day: string; bytesUp: number; bytesDown: number; sessions: number; totalDurationSec: number; testsRun: number }[];
    recentSessions: { id: number; profileName: string | null; operator: string; startedAt: string; durationSec: number; bytesUp: number; bytesDown: number; active: boolean }[];
  } | null>(null);
  const [range, setRange] = useState<"7" | "30" | "all">("30");

  const load = useCallback(async () => {
    try {
      const d = (await api("/api/stats/overview")) as typeof data;
      setData(d as typeof data);
    } catch (e) {
      notify(e instanceof Error ? e.message : "Falha", "err");
    }
  }, [notify]);

  useEffect(() => {
    load();
  }, [load]);

  const days = (data?.daily ?? []).filter((d) => {
    if (range === "all") return true;
    const cutoff = new Date();
    cutoff.setDate(cutoff.getDate() - Number(range));
    return new Date(d.day) >= cutoff;
  });
  const maxTraffic = Math.max(1, ...days.map((d) => d.bytesUp + d.bytesDown));

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2 items-center justify-between">
        <h3 className="font-extrabold text-sm flex items-center gap-2"><BarChart3 className="w-4 h-4 text-cyan-300" /> ESTATÍSTICAS REAIS</h3>
        <div className="flex gap-2">
          {(["7", "30", "all"] as const).map((r) => (
            <button key={r} onClick={() => setRange(r)} className={`text-[11px] font-bold px-3 py-1.5 rounded-full border cursor-pointer ${range === r ? "border-cyan-400/60 bg-cyan-500/15" : "border-white/10 opacity-70"}`}>
              {r === "all" ? "Tudo" : `${r} dias`}
            </button>
          ))}
          <button onClick={load} className="btn-ghost rounded-lg px-3 py-1.5 text-xs cursor-pointer"><RefreshCw className="w-3.5 h-3.5" /></button>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">
        <StatCard icon={<ArrowDown className="w-5 h-5 text-emerald-400" />} label="Recebidos" value={fmtBytes(data?.totals.bytesDown ?? 0)} sub="tráfego medido" />
        <StatCard icon={<ArrowUp className="w-5 h-5 text-sky-400" />} label="Enviados" value={fmtBytes(data?.totals.bytesUp ?? 0)} sub="tráfego medido" />
        <StatCard icon={<Timer className="w-5 h-5 text-amber-300" />} label="Tempo total" value={fmtDuration(data?.totals.durationSec ?? 0)} sub={`${data?.totals.sessions ?? 0} sessões`} />
        <StatCard icon={<FlaskConical className="w-5 h-5 text-purple-300" />} label="Testes" value={String((data?.totals.networkTests ?? 0) + (data?.totals.sniTests ?? 0))} sub={`${data?.totals.sniTests ?? 0} SNI · ${data?.totals.serversOnline ?? 0}/${data?.totals.servers ?? 0} srv online`} />
      </div>

      <div className="cv-card p-4">
        <h4 className="font-extrabold text-xs mb-3 opacity-80">TRÁFEGO DIÁRIO (MEDIDO)</h4>
        {days.length === 0 ? (
          <p className="text-xs opacity-60 text-center py-6">Sem actividade registada. Os valores aparecem após sessões e testes reais — nunca simulamos.</p>
        ) : (
          <div className="space-y-1.5">
            {days.map((d) => {
              const total = d.bytesUp + d.bytesDown;
              const w = Math.max((total / maxTraffic) * 100, total > 0 ? 3 : 0);
              return (
                <div key={d.day} className="flex items-center gap-2 text-[11px]">
                  <span className="w-20 shrink-0 font-mono opacity-70">{d.day.slice(5)}</span>
                  <div className="flex-1 h-5 rounded bg-white/5 overflow-hidden flex">
                    <div className="h-full bg-gradient-to-r from-emerald-500 to-emerald-300" style={{ width: `${w}%` }} title={`↓ ${fmtBytes(d.bytesDown)} ↑ ${fmtBytes(d.bytesUp)}`} />
                  </div>
                  <span className="w-32 shrink-0 text-right font-semibold opacity-80">{fmtBytes(total)}</span>
                  <span className="w-24 shrink-0 text-right opacity-60 hidden sm:block">{d.sessions} sess · {d.testsRun} testes</span>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="cv-card p-4">
        <h4 className="font-extrabold text-xs mb-3 opacity-80">SESSÕES RECENTES</h4>
        {(data?.recentSessions ?? []).length === 0 ? (
          <p className="text-xs opacity-60 text-center py-4">Sem sessões.</p>
        ) : (
          <div className="space-y-1.5 text-xs">
            {(data?.recentSessions ?? []).map((s) => (
              <div key={s.id} className="rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 flex flex-wrap gap-x-4 gap-y-1 items-center">
                <span className={`badge ${s.active ? "bg-emerald-500/20 text-emerald-300 border border-emerald-400/40" : "bg-white/10 border border-white/15"}`}>#{s.id} {s.active ? "ACTIVA" : "TERMINADA"}</span>
                <span className="font-bold">{s.profileName ?? "Monitorização"} · {s.operator}</span>
                <span className="opacity-70">{fmtDateTime(s.startedAt)} · {fmtDuration(s.durationSec)}</span>
                <span className="opacity-70">↓ {fmtBytes(s.bytesDown)} · ↑ {fmtBytes(s.bytesUp)}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, sub }: { icon: React.ReactNode; label: string; value: string; sub: string }) {
  return (
    <div className="cv-card p-3.5 text-center">
      <div className="flex justify-center">{icon}</div>
      <p className="text-lg font-extrabold mt-1.5 leading-tight">{value}</p>
      <p className="text-[11px] font-bold opacity-80">{label}</p>
      <p className="text-[10px] opacity-60">{sub}</p>
    </div>
  );
}

// ---------------- LOGS ----------------

type LogRow = { id: number; level: string; category: string; message: string; details: string | null; createdAt: string };

export function LogsPanel(props: { notify: (m: string, k?: "ok" | "err" | "info") => void }) {
  const { notify } = props;
  const [logs, setLogs] = useState<LogRow[]>([]);
  const [level, setLevel] = useState("TODOS");
  const [category, setCategory] = useState("TODOS");
  const [auto, setAuto] = useState(true);

  const load = useCallback(async () => {
    try {
      const d = (await api(`/api/logs?level=${level}&category=${category}&limit=250`)) as { logs: LogRow[] };
      setLogs(d.logs);
    } catch {}
  }, [level, category]);

  useEffect(() => {
    load();
    if (!auto) return;
    const t = setInterval(load, 5000);
    return () => clearInterval(t);
  }, [load, auto]);

  const clear = async () => {
    if (!confirm("Apagar todos os logs?")) return;
    try {
      await api("/api/logs", { method: "DELETE" });
      setLogs([]);
      notify("Logs apagados", "info");
    } catch (e) {
      notify(e instanceof Error ? e.message : "Falha", "err");
    }
  };

  const exportLogs = () => {
    const blob = new Blob([logs.map((l) => `[${l.createdAt}] [${l.level}] [${l.category}] ${l.message}${l.details ? `\n  ${l.details}` : ""}`).join("\n")], { type: "text/plain" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `conexoes-vpn-logs-${new Date().toISOString().slice(0, 10)}.txt`;
    a.click();
  };

  const cats = ["TODOS", "sistema", "rede", "dns", "tcp", "tls", "latencia", "sni", "operadora", "servidor", "satelite", "sessao", "perfil", "velocidade", "admin", "cliente"];

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2 items-center justify-between">
        <h3 className="font-extrabold text-sm flex items-center gap-2"><ScrollText className="w-4 h-4 text-amber-300" /> LOGS DE CONEXÃO ({logs.length})</h3>
        <div className="flex flex-wrap gap-2 items-center">
          <select className="cv-input !w-auto !py-1.5 text-xs" value={level} onChange={(e) => setLevel(e.target.value)}>
            {["TODOS", "info", "success", "warn", "error"].map((l) => <option key={l} value={l}>{l}</option>)}
          </select>
          <select className="cv-input !w-auto !py-1.5 text-xs" value={category} onChange={(e) => setCategory(e.target.value)}>
            {cats.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
          <label className="text-[11px] font-bold flex items-center gap-1.5 cursor-pointer opacity-80">
            <input type="checkbox" checked={auto} onChange={(e) => setAuto(e.target.checked)} className="accent-cyan-500" /> auto
          </label>
          <button onClick={exportLogs} className="btn-ghost rounded-lg px-2.5 py-1.5 text-xs cursor-pointer"><Download className="w-3.5 h-3.5" /></button>
          <button onClick={clear} className="btn-ghost rounded-lg px-2.5 py-1.5 text-xs text-red-300 cursor-pointer"><Trash2 className="w-3.5 h-3.5" /></button>
        </div>
      </div>
      <div className="cv-card p-3">
        <div className="space-y-1 max-h-[560px] overflow-y-auto scroll-thin pr-1">
          {logs.length === 0 && <p className="text-xs opacity-60 text-center py-6">Sem registos.</p>}
          {logs.map((l) => (
            <div key={l.id} className="log-line rounded-lg border border-white/[0.07] bg-black/25 px-2.5 py-1.5 flex gap-2 items-start">
              <LevelDot level={l.level} />
              <span className="opacity-50 shrink-0">{fmtDateTime(l.createdAt)}</span>
              <span className="opacity-60 shrink-0">[{l.category}]</span>
              <span className="break-words">{l.message}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function LevelDot({ level }: { level: string }) {
  const c = level === "success" ? "bg-emerald-400" : level === "error" ? "bg-red-400" : level === "warn" ? "bg-amber-400" : "bg-sky-400";
  return <span className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${c}`} />;
}

// ---------------- ADMIN ----------------

export function AdminPanel(props: {
  notify: (m: string, k?: "ok" | "err" | "info") => void;
  adminUser: string | null;
  setAdminUser: (u: string | null) => void;
}) {
  const { notify, adminUser, setAdminUser } = props;
  const [user, setUser] = useState("");
  const [pass, setPass] = useState("");
  const [stats, setStats] = useState<{
    users: { id: number; username: string; role: string; createdAt: string }[];
    errorReports: LogRow[];
    totals: Record<string, number>;
    sniByStatus: { status: string; total: string }[];
  } | null>(null);
  const [features, setFeatures] = useState<{ feature: string; status: string; description: string | null }[]>([]);

  const loadAdmin = useCallback(async () => {
    if (!adminUser) return;
    try {
      const d = (await apiAdmin("/api/admin/stats")) as typeof stats;
      setStats(d as typeof stats);
    } catch (e) {
      notify(e instanceof Error ? e.message : "Falha", "err");
    }
    try {
      const f = (await api("/api/features")) as { features: typeof features };
      setFeatures(f.features);
    } catch {}
  }, [adminUser, notify]);

  useEffect(() => {
    loadAdmin();
  }, [loadAdmin]);

  useEffect(() => {
    api("/api/features").then((f) => {
      const d = f as { features: typeof features };
      setFeatures(d.features);
    }).catch(() => {});
  }, []);

  const login = async () => {
    try {
      const d = (await api("/api/admin/login", { method: "POST", body: JSON.stringify({ username: user, password: pass }) })) as { username: string; token: string };
      localStorage.setItem("cvpn_admin_token", d.token);
      setAdminUser(d.username);
      setPass("");
      notify(`Bem-vindo, ${d.username}`, "ok");
    } catch (e) {
      notify(e instanceof Error ? e.message : "Falha", "err");
    }
  };

  const logout = () => {
    localStorage.removeItem("cvpn_admin_token");
    setAdminUser(null);
    setStats(null);
    notify("Sessão admin terminada", "info");
  };

  const setFeature = async (feature: string, status: string) => {
    try {
      await apiAdmin("/api/features", { method: "PUT", body: JSON.stringify({ feature, status }) });
      notify(`${feature} → ${status}`, "ok");
      loadAdmin();
    } catch (e) {
      notify(e instanceof Error ? e.message : "Falha", "err");
    }
  };

  if (!adminUser) {
    return (
      <div className="max-w-md mx-auto space-y-4">
        <div className="cv-card p-6 text-center">
          <Lock className="w-10 h-10 mx-auto text-amber-300 mb-2" />
          <h3 className="font-extrabold">ADMINISTRAÇÃO</h3>
          <p className="text-xs opacity-60 mt-1">Acesso protegido. Palavras-passe guardadas com hash (scrypt), nunca em claro.</p>
          <input className="cv-input mt-4" placeholder="Utilizador" value={user} onChange={(e) => setUser(e.target.value)} />
          <input className="cv-input mt-2" type="password" placeholder="Palavra-passe" value={pass} onChange={(e) => setPass(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") login(); }} />
          <button onClick={login} className="btn-gold w-full mt-3 rounded-xl py-2.5 text-sm cursor-pointer">Entrar</button>
          <p className="text-[10px] opacity-50 mt-2">Primeiro acesso? Utilizador inicial: <strong>admin</strong> / <strong>admin123</strong> (criado pelo seed — altere de seguida).</p>
        </div>
        <FeaturesTable features={features} readonly />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="cv-card p-4 flex flex-wrap items-center justify-between gap-2">
        <div>
          <h3 className="font-extrabold flex items-center gap-2"><ShieldAlert className="w-5 h-5 text-amber-300" /> PAINEL ADMINISTRATIVO</h3>
          <p className="text-xs opacity-60">Autenticado como <strong>{adminUser}</strong> · credenciais e chaves protegidas · sem exposição de segredos</p>
        </div>
        <div className="flex gap-2">
          <button onClick={loadAdmin} className="btn-ghost rounded-xl px-3 py-2 text-xs cursor-pointer flex items-center gap-1.5"><RefreshCw className="w-3.5 h-3.5" /> Actualizar</button>
          <button onClick={logout} className="btn-ghost rounded-xl px-3 py-2 text-xs text-red-300 cursor-pointer flex items-center gap-1.5"><LogOut className="w-3.5 h-3.5" /> Sair</button>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">
        <AdminStat icon={<Server className="w-5 h-5 text-cyan-300" />} label="Servidores" value={String(stats?.totals.servers ?? "—")} />
        <AdminStat icon={<FlaskConical className="w-5 h-5 text-purple-300" />} label="Testes SNI" value={String(stats?.totals.sniTotal ?? "—")} />
        <AdminStat icon={<FileWarning className="w-5 h-5 text-red-300" />} label="Erros" value={String(stats?.totals.errors ?? "—")} />
        <AdminStat icon={<Users className="w-5 h-5 text-amber-300" />} label="Admins" value={String(stats?.users.length ?? "—")} />
      </div>

      {stats?.sniByStatus && stats.sniByStatus.length > 0 && (
        <div className="cv-card p-3 flex flex-wrap gap-2 items-center text-xs">
          <span className="font-extrabold opacity-70">SNI por estado:</span>
          {stats.sniByStatus.map((s) => (
            <span key={s.status} className={`badge ${statusBadge(s.status)}`}>{s.status}: {s.total}</span>
          ))}
        </div>
      )}

      <div className="grid lg:grid-cols-2 gap-4">
        <div className="cv-card p-4">
          <h4 className="font-extrabold text-xs mb-2 flex items-center gap-2"><Users className="w-4 h-4" /> UTILIZADORES</h4>
          {(stats?.users ?? []).map((u) => (
            <div key={u.id} className="rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 text-xs mb-1.5 flex justify-between">
              <span className="font-bold">{u.username} <span className="opacity-60">· {u.role}</span></span>
              <span className="opacity-60">{fmtDateTime(u.createdAt)}</span>
            </div>
          ))}
          <p className="text-[10px] opacity-50 mt-2">Gestão de utilizadores adicional disponível via API autenticada. Palavras-passe nunca apresentadas.</p>
        </div>
        <div className="cv-card p-4">
          <h4 className="font-extrabold text-xs mb-2 flex items-center gap-2"><FileWarning className="w-4 h-4 text-red-300" /> RELATÓRIOS DE ERRO (50 recentes)</h4>
          <div className="space-y-1 max-h-64 overflow-y-auto scroll-thin pr-1">
            {(stats?.errorReports ?? []).length === 0 && <p className="text-xs opacity-60 text-center py-4">Sem erros registados. ✓</p>}
            {(stats?.errorReports ?? []).map((l) => (
              <div key={l.id} className="log-line rounded-lg border border-red-400/20 bg-red-500/5 px-2.5 py-1.5 text-[11px]">
                <span className="opacity-50">{fmtDateTime(l.createdAt)}</span> <span className="opacity-60">[{l.category}]</span> {l.message}
              </div>
            ))}
          </div>
        </div>
      </div>

      <FeaturesTable features={features} onChange={setFeature} />
    </div>
  );
}

function AdminStat({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="cv-card p-3.5 text-center">
      <div className="flex justify-center">{icon}</div>
      <p className="text-xl font-extrabold mt-1">{value}</p>
      <p className="text-[11px] opacity-70 font-bold">{label}</p>
    </div>
  );
}

export function FeaturesTable({ features, onChange, readonly }: {
  features: { feature: string; status: string; description: string | null }[];
  onChange?: (f: string, s: string) => void;
  readonly?: boolean;
}) {
  return (
    <div className="cv-card p-4">
      <h4 className="font-extrabold text-xs mb-1 flex items-center gap-2"><BookOpen className="w-4 h-4 text-cyan-300" /> ESTADO DAS FUNCIONALIDADES — RELATÓRIO DE TESTES REAIS</h4>
      <p className="text-[11px] opacity-60 mb-3">IMPLEMENTADO = código funcional + teste real · EM TESTE = parcial · INDISPONÍVEL = claramente assinalado, sem simulação.</p>
      <div className="space-y-1.5">
        {features.length === 0 && <p className="text-xs opacity-60">A carregar…</p>}
        {features.map((f) => (
          <div key={f.feature} className="rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2 flex flex-wrap items-center gap-2">
            {f.status === "IMPLEMENTADO" ? <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" /> : f.status === "EM_TESTE" ? <AlertTriangle className="w-4 h-4 text-amber-300 shrink-0" /> : <ShieldAlert className="w-4 h-4 text-slate-400 shrink-0" />}
            <div className="flex-1 min-w-[180px]">
              <p className="text-xs font-bold">{f.feature}</p>
              {f.description && <p className="text-[11px] opacity-60">{f.description}</p>}
            </div>
            {readonly || !onChange ? (
              <span className={`badge ${statusBadge(f.status)}`}>{f.status.replaceAll("_", " ")}</span>
            ) : (
              <select className="cv-input !w-auto !py-1 text-[11px]" value={f.status} onChange={(e) => onChange(f.feature, e.target.value)}>
                <option value="IMPLEMENTADO">IMPLEMENTADO</option>
                <option value="EM_TESTE">EM TESTE</option>
                <option value="INDISPONIVEL">INDISPONÍVEL</option>
              </select>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
