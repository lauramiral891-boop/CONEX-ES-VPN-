import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Conexões VPN — Unitel • Africell • ANGOSAT-2",
  description:
    "Plataforma profissional de gestão VPN, diagnóstico de rede e SNI Scanner para Angola. Medições reais, sem simulações.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="pt">
      <body className="antialiased">{children}</body>
    </html>
  );
}
