import { db } from "@/db";
import { appLogs } from "@/db/schema";
import { desc, and, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const level = url.searchParams.get("level") || "";
  const category = url.searchParams.get("category") || "";
  const limit = Math.min(Number(url.searchParams.get("limit") || 200), 500);
  try {
    const conds = [];
    if (level && level !== "TODOS") conds.push(eq(appLogs.level, level));
    if (category && category !== "TODOS") conds.push(eq(appLogs.category, category));
    const rows =
      conds.length > 0
        ? await db.select().from(appLogs).where(and(...conds)).orderBy(desc(appLogs.id)).limit(limit)
        : await db.select().from(appLogs).orderBy(desc(appLogs.id)).limit(limit);
    return Response.json({ ok: true, total: rows.length, logs: rows });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { level?: string; category?: string; message?: string; details?: string };
    const message = String(body.message || "").trim().slice(0, 500);
    if (!message) return Response.json({ ok: false, error: "Mensagem obrigatória" }, { status: 400 });
    const level = ["info", "success", "warn", "error"].includes(String(body.level)) ? String(body.level) : "info";
    await db.insert(appLogs).values({
      level,
      category: String(body.category || "cliente").slice(0, 60),
      message,
      details: body.details ? String(body.details).slice(0, 4000) : null,
    });
    return Response.json({ ok: true });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}

export async function DELETE() {
  try {
    const deleted = await db.delete(appLogs).returning({ id: appLogs.id });
    return Response.json({ ok: true, deleted: deleted.length });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}
