import { db } from "@/db";
import { vpnProfiles } from "@/db/schema";
import { writeLog } from "@/lib/server-log";
import { sanitizeDomain, isValidDomainOrIp } from "@/lib/network";

export const dynamic = "force-dynamic";

const PROTOCOLS = ["WireGuard", "OpenVPN", "SSH Tunnel", "SSL/TLS", "V2Ray"];

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { profile?: Record<string, unknown> };
    const p = body.profile;
    if (!p) return Response.json({ ok: false, error: "Ficheiro sem perfil" }, { status: 400 });
    const name = String(p["name"] || "Perfil importado").slice(0, 120);
    const host = sanitizeDomain(String(p["host"] || ""));
    const port = Number(p["port"]) || 443;
    const protocol = String(p["protocol"] || "SSL/TLS");
    if (!host || !isValidDomainOrIp(host)) return Response.json({ ok: false, error: "Anfitrião inválido no ficheiro" }, { status: 400 });
    if (!PROTOCOLS.includes(protocol)) return Response.json({ ok: false, error: "Protocolo inválido no ficheiro" }, { status: 400 });
    const inserted = await db.insert(vpnProfiles).values({
      name,
      protocol,
      host,
      port,
      sni: p["sni"] ? sanitizeDomain(String(p["sni"])) : null,
      method: String(p["method"] || "AES-256-GCM").slice(0, 60),
      payload: String(p["payload"] || "auto").slice(0, 200),
      username: p["username"] ? String(p["username"]).slice(0, 200) : null,
      autoReconnect: p["autoReconnect"] !== false,
      dnsProtection: p["dnsProtection"] !== false,
      dnsChoice: String(p["dnsChoice"] || "1.1.1.1, 8.8.8.8").slice(0, 200),
      extraConfig: p["extraConfig"] ? String(p["extraConfig"]).slice(0, 8000) : null,
    }).returning({ id: vpnProfiles.id });
    await writeLog("perfil", "success", `Perfil importado: ${name} (${protocol} ${host}:${port})`);
    return Response.json({ ok: true, id: inserted[0].id });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Ficheiro inválido" }, { status: 400 });
  }
}
