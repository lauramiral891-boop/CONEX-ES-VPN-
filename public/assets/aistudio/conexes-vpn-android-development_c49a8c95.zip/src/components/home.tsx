"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  Power, Wifi, WifiOff, Globe, Server, Activity, ArrowDown, ArrowUp,
  ShieldCheck, ShieldAlert, Timer, Zap, RefreshCw, AlertTriangle, Gauge,
} from "lucide-react";
import { api, fmtBytes, fmtDuration, fmtDateTime } from "@/lib/client";
import type { ServerRow } from "./servers";

type Session = {
  id: number; profileName: string | null; operator: string; serverName: string | null;
  startedAt: string; bytesUp: number; bytesDown: number; publicIp: string | null;
  active: boolean; liveDurationSec?: number;
};

export function HomePanel(props: {
  operator: string;
  setOperator: (o: string) => void;
  servers: ServerRow[];
  activeServer: ServerRow | null;
  setActiveServer: (s: ServerRow | null) => void;
  profiles: { id: number; name: string; protocol: string; dnsProtection: boolean }[];
  activeProfile: number | null;
  setActiveProfile: (id: number | null) => void;
  session: Session | null;
  refreshSession: () => void;
  notify: (msg: string, kind?: "ok" | "err" | "info") => void;
}) {
  const { operator, setOperator, servers, activeServer, setActiveServer, profiles, activeProfile, setActiveProfile, session, refreshSession, notify } = props;
  const [ipInfo, setIpInfo] = useState<{ publicIp: string | null; geo: Record<string, unknown> | null; loading: boolean }>({
    publicIp: null, geo: null, loading: true,
  });
  const [ping, setPing] = useState<{ ms: number | null; loading: boolean }>({ ms: null, loading: false });
  const [speed, setSpeed] = useState<{ down: number | null; up: number | null; testing: boolean; progress: string }>({
    down: null, up: null, testing: false, progress: "",
  });
  const [elapsed, setElapsed] = useState(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const loadIp = useCallback(async () => {
    setIpInfo((s) => ({ ...s, loading: true }));
    try {
      const d = (await api("/api/network/public-ip")) as { publicIp: string | null; geo: Record<string, unknown> | null };
      setIpInfo({ publicIp: d.publicIp, geo: d.geo, loading: false });
    } catch {
      setIpInfo({ publicIp: null, geo: null, loading: false });
    }
  }, []);

  useEffect(() => {
    loadIp();
    refreshSession();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (session?.active) {
      const base = new Date(session.startedAt).getTime();
      const tick = () => setElapsed(Math.floor((Date.now() - base) / 1000));
      tick();
      timerRef.current = setInterval(tick, 1000);
      return () => {
        if (timerRef.current) clearInterval(timerRef.current);
      };
    } else {
      setElapsed(0);
    }
  }, [session]);

  const measurePing = useCallback(async () => {
    const target = activeServer ?? servers.find((s) => s.online) ?? servers[0];
    if (!target) {
      notify("Sem servidores para medir ping", "err");
      return;
    }
    setPing({ ms: null, loading: true });
    try {
      const d = (await api("/api/network/latency", {
        method: "POST",
        body: JSON.stringify({ host: target.address, port: target.port, samples: 4, operator }),
      })) as { avg: number | null; ok: boolean };
      setPing({ ms: d.avg, loading: false });
    } catch (e) {
      setPing({ ms: null, loading: false });
      notify(e instanceof Error ? e.message : "Falha no ping", "err");
    }
  }, [activeServer, servers, operator, notify]);

  const runSpeedTest = useCallback(async () => {
    if (speed.testing) return;
    setSpeed({ down: null, up: null, testing: true, progress: "A medir download…" });
    try {
      // DOWNLOAD real: 2 MB
      const sizeKB = 2048;
      const t0 = performance.now();
      const res = await fetch(`/api/network/speed-payload?size=${sizeKB}`, { cache: "no-store" });
      if (!res.ok || !res.body) throw new Error("Falha no download de teste");
      const reader = res.body.getReader();
      let received = 0;
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        received += value.byteLength;
      }
      const t1 = performance.now();
      const secDown = Math.max((t1 - t0) / 1000, 0.05);
      const downMbps = (received * 8) / secDown / 1_000_000;

      setSpeed((s) => ({ ...s, down: Math.round(downMbps * 100) / 100, progress: "A medir upload…" }));

      // UPLOAD real: 512 KB
      const upBytes = 512 * 1024;
      const payload = new Uint8Array(upBytes);
      for (let i = 0; i < payload.length; i += 997) payload[i] = i % 251;
      const u0 = performance.now();
      const ures = await fetch("/api/network/speed-payload", {
        method: "POST",
        body: payload as unknown as BodyInit,
        headers: { "Content-Type": "application/octet-stream" },
      });
      const ujson = (await ures.json()) as { mbps?: number; bytesReceived?: number };
      const u1 = performance.now();
      const secUp = Math.max((u1 - u0) / 1000, 0.05);
      const upMbps = ujson.mbps ?? (upBytes * 8) / secUp / 1_000_000;

      setSpeed({
        down: Math.round(downMbps * 100) / 100,
        up: Math.round(upMbps * 100) / 100,
        testing: false,
        progress: "",
      });

      // Contabilizar tráfego real na sessão
      if (session?.active) {
        try {
          await api("/api/session/heartbeat", {
            method: "POST",
            body: JSON.stringify({ id: session.id, bytesUp: upBytes, bytesDown: received }),
          });
          refreshSession();
        } catch {}
      }
      await api("/api/logs", {
        method: "POST",
        body: JSON.stringify({
          level: "success",
          category: "velocidade",
          message: `Teste de velocidade: ↓ ${downMbps.toFixed(2)} Mbps · ↑ ${upMbps.toFixed(2)} Mbps`,
          details: JSON.stringify({ downBytes: received, upBytes, secDown, secUp }),
        }),
      }).catch(() => {});
      notify("Teste de velocidade concluído (medição real)", "ok");
    } catch (e) {
      setSpeed({ down: null, up: null, testing: false, progress: "" });
      notify(e instanceof Error ? e.message : "Falha no teste", "err");
    }
  }, [speed.testing, session, refreshSession, notify]);

  const toggleSession = useCallback(async () => {
    try {
      if (session?.active) {
        await api("/api/session/stop", { method: "POST", body: JSON.stringify({ id: session.id }) });
        notify("Sessão terminada", "info");
      } else {
        const prof = profiles.find((p) => p.id === activeProfile);
        await api("/api/session/start", {
          method: "POST",
          body: JSON.stringify({
            profileId: activeProfile,
            operator,
            serverName: activeServer ? `${activeServer.name} (${activeServer.address}:${activeServer.port})` : (prof ? prof.name : "Monitorização"),
            publicIp: ipInfo.publicIp,
          }),
        });
        notify("Sessão de monitorização iniciada", "ok");
      }
      refreshSession();
    } catch (e) {
      notify(e instanceof Error ? e.message : "Falha na sessão", "err");
    }
  }, [session, activeProfile, operator, activeServer, profiles, ipInfo.publicIp, refreshSession, notify]);

  const connected = !!session?.active;
  const profObj = profiles.find((p) => p.id === activeProfile);

  return (
    <div className="space-y-4">
      {/* Aviso de honestidade */}
      <div className="cv-card p-3 flex gap-3 items-start border-l-4" style={{ borderLeftColor: "#f5c518" }}>
        <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <p className="text-xs leading-relaxed opacity-90">
          <strong className="text-amber-300">Transparência:</strong> nesta versão Web, o botão{" "}
          <strong>LIGAR</strong> inicia uma <strong>sessão de monitorização</strong> (temporizador + medições reais).
          O túnel VPN ao nível do sistema só existe na app Android com <strong>VPNService</strong>. Nenhum número é
          simulado: contadores a zero significam ausência de tráfego medido. Não prometemos internet grátis.
        </p>
      </div>

      <div className="grid lg:grid-cols-5 gap-4">
        {/* Botão principal */}
        <div className="cv-card p-6 lg:col-span-2 flex flex-col items-center text-center relative overflow-hidden">
          <div className="grid-bg absolute inset-0 opacity-60 pointer-events-none" />
          <div className="relative">
            <button
              onClick={toggleSession}
              aria-label={connected ? "Desligar" : "Ligar"}
              className={`power-ring w-44 h-44 rounded-full border-4 flex flex-col items-center justify-center gap-1 cursor-pointer ${
                connected ? "power-on border-emerald-400" : "power-off border-blue-500"
              }`}
              style={{ background: "radial-gradient(circle at 50% 35%, #16225c 0%, #070b28 70%)" }}
            >
              <Power className={`w-14 h-14 ${connected ? "text-emerald-400" : "text-sky-300"}`} />
              <span className={`text-lg font-extrabold tracking-widest ${connected ? "text-emerald-300" : "text-sky-200"}`}>
                {connected ? "LIGADO" : "DESLIGADO"}
              </span>
            </button>
            <p className="mt-3 text-xs opacity-70">Toque para {connected ? "desligar" : "ligar"}</p>
          </div>

          {/* Operadoras */}
          <div className="grid grid-cols-2 gap-2 w-full mt-5">
            <button
              onClick={() => setOperator("UNITEL")}
              className={`rounded-xl p-3 border-2 font-extrabold cursor-pointer transition ${
                operator === "UNITEL" ? "border-orange-400 bg-orange-500/25 text-orange-200" : "border-white/10 bg-white/5 opacity-70 hover:opacity-100"
              }`}
            >
              <span className="block text-sm">◉ UNITEL</span>
              <span className="block text-[10px] font-medium opacity-80">O próximo mais perto</span>
            </button>
            <button
              onClick={() => setOperator("AFRICELL")}
              className={`rounded-xl p-3 border-2 font-extrabold cursor-pointer transition ${
                operator === "AFRICELL" ? "border-purple-400 bg-purple-500/25 text-purple-200" : "border-white/10 bg-white/5 opacity-70 hover:opacity-100"
              }`}
            >
              <span className="block text-sm">◉ AFRICELL</span>
              <span className="block text-[10px] font-medium opacity-80">A internet é para todos</span>
            </button>
          </div>

          <div className={`mt-4 w-full rounded-xl p-3 border flex items-center gap-2 ${connected ? "border-emerald-400/40 bg-emerald-500/10" : "border-white/10 bg-white/5"}`}>
            {connected ? <Wifi className="w-4 h-4 text-emerald-400" /> : <WifiOff className="w-4 h-4 opacity-60" />}
            <div className="text-left">
              <p className="text-xs font-bold">Estado da rede</p>
              <p className={`text-xs ${connected ? "text-emerald-300" : "opacity-70"}`}>
                {connected ? `Sessão activa · ${fmtDuration(elapsed)}` : "Pronto para ligar"}
              </p>
            </div>
          </div>
        </div>

        {/* Estado */}
        <div className="lg:col-span-3 space-y-4">
          <div className="cv-card p-4">
            <div className="flex flex-wrap items-center gap-2 justify-between mb-3">
              <h3 className="font-extrabold flex items-center gap-2 text-sm">
                <Activity className="w-4 h-4 text-cyan-300" /> ESTADO DA CONEXÃO
              </h3>
              <button onClick={() => { loadIp(); refreshSession(); }} className="btn-ghost rounded-lg px-3 py-1.5 text-xs flex items-center gap-1 cursor-pointer">
                <RefreshCw className="w-3.5 h-3.5" /> Actualizar
              </button>
            </div>
            <div className="grid sm:grid-cols-2 gap-2 text-sm">
              <InfoRow icon={<Wifi className="w-4 h-4 text-cyan-300" />} label="Estado" value={connected ? "LIGADO (monitorização)" : "DESLIGADO"} accent={connected} />
              <InfoRow icon={<Globe className="w-4 h-4 text-purple-300" />} label="Operadora" value={operator} />
              <InfoRow icon={<Server className="w-4 h-4 text-amber-300" />} label="Servidor" value={activeServer ? `${activeServer.name} · ${activeServer.address}:${activeServer.port}` : "Nenhum seleccionado"} />
              <InfoRow icon={<Globe className="w-4 h-4 text-emerald-300" />} label="IP público" value={ipInfo.loading ? "A detectar…" : ipInfo.publicIp ?? "Indisponível"} />
              <InfoRow icon={<Timer className="w-4 h-4 text-sky-300" />} label="Tempo de conexão" value={connected ? fmtDuration(elapsed) : "—"} />
              <InfoRow icon={<Zap className="w-4 h-4 text-yellow-300" />} label="Ping (TCP real)" value={ping.loading ? "A medir…" : ping.ms !== null ? `${ping.ms} ms` : "Por medir"} action={<button onClick={measurePing} className="text-[11px] underline opacity-80 hover:opacity-100 cursor-pointer">medir</button>} />
              <InfoRow icon={<ArrowDown className="w-4 h-4 text-emerald-400" />} label="Recebidos (medidos)" value={fmtBytes(session?.bytesDown ?? 0)} />
              <InfoRow icon={<ArrowUp className="w-4 h-4 text-sky-400" />} label="Enviados (medidos)" value={fmtBytes(session?.bytesUp ?? 0)} />
              <InfoRow icon={profObj?.dnsProtection !== false ? <ShieldCheck className="w-4 h-4 text-emerald-400" /> : <ShieldAlert className="w-4 h-4 text-amber-400" />} label="Protecção" value={connected ? (profObj?.dnsProtection !== false ? "DNS protegido (perfil)" : "DNS sem protecção extra") : "Inactiva — sem sessão"} />
              <InfoRow icon={<Gauge className="w-4 h-4 text-purple-300" />} label="Velocidade medida" value={speed.down !== null ? `↓ ${speed.down} · ↑ ${speed.up} Mbps` : "Por medir"} />
            </div>
            {ipInfo.geo && (
              <p className="text-[11px] mt-2 opacity-70">
                Localização aproximada: {String(ipInfo.geo["city"] ?? "—")}, {String(ipInfo.geo["country"] ?? "—")} · ISP: {String(ipInfo.geo["isp"] ?? "—")}
              </p>
            )}
          </div>

          {/* Selecção + velocidade */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="cv-card p-4">
              <h3 className="font-extrabold text-sm mb-2 flex items-center gap-2"><Server className="w-4 h-4 text-amber-300" /> SERVIDOR & PERFIL</h3>
              <label className="text-[11px] opacity-70">Servidor activo</label>
              <select
                className="cv-input mt-1 mb-2"
                value={activeServer?.id ?? ""}
                onChange={(e) => {
                  const s = servers.find((x) => x.id === Number(e.target.value)) ?? null;
                  setActiveServer(s);
                }}
              >
                <option value="">— Seleccionar —</option>
                {servers.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.online ? "🟢" : "🔴"} {s.name} · {s.lastPingMs !== null ? `${s.lastPingMs}ms` : "—"}
                  </option>
                ))}
              </select>
              <label className="text-[11px] opacity-70">Perfil de túnel</label>
              <select
                className="cv-input mt-1"
                value={activeProfile ?? ""}
                onChange={(e) => setActiveProfile(e.target.value ? Number(e.target.value) : null)}
              >
                <option value="">— Sem perfil (só monitorização) —</option>
                {profiles.map((p) => (
                  <option key={p.id} value={p.id}>{p.name} · {p.protocol}</option>
                ))}
              </select>
              {activeServer && (
                <p className="text-[11px] mt-2 opacity-70">
                  Última verificação: {fmtDateTime(activeServer.lastCheck)} · {activeServer.online ? "online" : "offline"}
                </p>
              )}
            </div>
            <div className="cv-card p-4">
              <h3 className="font-extrabold text-sm mb-2 flex items-center gap-2"><Gauge className="w-4 h-4 text-cyan-300" /> VELOCIDADE REAL</h3>
              <div className="grid grid-cols-2 gap-2 text-center">
                <div className="rounded-xl bg-emerald-500/10 border border-emerald-400/30 p-3">
                  <ArrowDown className="w-5 h-5 mx-auto text-emerald-400" />
                  <p className="text-xl font-extrabold mt-1">{speed.down !== null ? speed.down : "—"}</p>
                  <p className="text-[11px] opacity-70">Mbps download</p>
                </div>
                <div className="rounded-xl bg-sky-500/10 border border-sky-400/30 p-3">
                  <ArrowUp className="w-5 h-5 mx-auto text-sky-400" />
                  <p className="text-xl font-extrabold mt-1">{speed.up !== null ? speed.up : "—"}</p>
                  <p className="text-[11px] opacity-70">Mbps upload</p>
                </div>
              </div>
              <button
                onClick={runSpeedTest}
                disabled={speed.testing}
                className="btn-blue w-full mt-3 rounded-xl py-2.5 text-sm disabled:opacity-50 cursor-pointer"
              >
                {speed.testing ? speed.progress || "A testar…" : "Executar teste de velocidade"}
              </button>
              <p className="text-[10px] mt-2 opacity-60">Download 2 MB + upload 512 KB reais. O tráfego medido soma à sessão.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoRow(props: { icon: React.ReactNode; label: string; value: string; accent?: boolean; action?: React.ReactNode }) {
  return (
    <div className={`rounded-xl border px-3 py-2 flex items-center gap-2.5 ${props.accent ? "border-emerald-400/40 bg-emerald-500/10" : "border-white/10 bg-white/[0.03]"}`}>
      <span className="shrink-0">{props.icon}</span>
      <div className="min-w-0 flex-1">
        <p className="text-[10px] uppercase tracking-wider opacity-60 font-bold">{props.label}</p>
        <p className="text-[13px] font-semibold truncate">{props.value}</p>
      </div>
      {props.action}
    </div>
  );
}
