import dns from "node:dns/promises";
import net from "node:net";
import tls from "node:tls";

export type TcpResult = { ok: boolean; ms: number | null; error: string | null };
export type DnsResult = {
  ok: boolean;
  ips: string[];
  ms: number | null;
  error: string | null;
};
export type TlsResult = {
  ok: boolean;
  ms: number | null;
  certValid: boolean;
  issuer: string | null;
  expiry: string | null;
  protocol: string | null;
  error: string | null;
};

export function sanitizeDomain(input: string): string {
  return input
    .trim()
    .toLowerCase()
    .replace(/^https?:\/\//, "")
    .replace(/\/.*$/, "")
    .replace(/:\d+$/, "")
    .trim();
}

export function isValidDomainOrIp(input: string): boolean {
  if (!input || input.length > 253 || input.length < 1) return false;
  if (net.isIP(input)) return true;
  // Domínio: labels alfanuméricos com hífen, pelo menos um ponto ou localhost
  const re =
    /^(?=.{1,253}$)(?!-)[a-z0-9-]{1,63}(?<!-)(\.(?!-)[a-z0-9-]{1,63}(?<!-))*$/;
  if (!re.test(input)) return false;
  return true;
}

export async function resolveDns(
  host: string,
  timeoutMs = 6000
): Promise<DnsResult> {
  const started = Date.now();
  try {
    const ips: string[] = [];
    if (net.isIP(host)) {
      return { ok: true, ips: [host], ms: 0, error: null };
    }
    const timer = setTimeout(() => {}, timeoutMs);
    try {
      const v4 = await Promise.race([
        dns.resolve4(host).catch(() => [] as string[]),
        new Promise<string[]>((_, rej) =>
          setTimeout(() => rej(new Error("timeout IPv4")), timeoutMs)
        ),
      ]).catch(() => [] as string[]);
      ips.push(...v4);
      if (ips.length === 0) {
        const v6 = await dns.resolve6(host).catch(() => [] as string[]);
        ips.push(...v6);
      }
      if (ips.length === 0) {
        // fallback: lookup (usa resolver do SO)
        const looked = await dns.lookup(host, { all: true }).catch(() => []);
        for (const l of looked ?? []) ips.push(l.address);
      }
    } finally {
      clearTimeout(timer);
    }
    const ms = Date.now() - started;
    if (ips.length === 0)
      return { ok: false, ips: [], ms, error: "DNS não resolveu (sem registos)" };
    return { ok: true, ips: [...new Set(ips)].slice(0, 8), ms, error: null };
  } catch (e) {
    const ms = Date.now() - started;
    return {
      ok: false,
      ips: [],
      ms,
      error: e instanceof Error ? e.message : "Falha DNS",
    };
  }
}

export function testTcp(
  host: string,
  port: number,
  timeoutMs = 5000
): Promise<TcpResult> {
  return new Promise((resolve) => {
    const started = Date.now();
    let done = false;
    const finish = (ok: boolean, error: string | null) => {
      if (done) return;
      done = true;
      try {
        socket.destroy();
      } catch {}
      resolve({ ok, ms: ok ? Date.now() - started : null, error });
    };
    const socket = new net.Socket();
    const timer = setTimeout(() => {
      finish(false, `Tempo esgotado após ${timeoutMs}ms (${host}:${port})`);
    }, timeoutMs);
    socket.once("connect", () => {
      clearTimeout(timer);
      finish(true, null);
    });
    socket.once("timeout", () => {
      clearTimeout(timer);
      finish(false, "Timeout de socket");
    });
    socket.once("error", (err) => {
      clearTimeout(timer);
      finish(false, err.message || "Erro TCP");
    });
    try {
      socket.connect(port, host);
    } catch (e) {
      clearTimeout(timer);
      finish(false, e instanceof Error ? e.message : "Falha ao ligar");
    }
  });
}

export function testTls(
  host: string,
  port: number,
  sni: string,
  timeoutMs = 8000
): Promise<TlsResult> {
  return new Promise((resolve) => {
    const started = Date.now();
    let done = false;
    const finish = (r: TlsResult) => {
      if (done) return;
      done = true;
      try {
        (socket as tls.TLSSocket)?.destroy();
      } catch {}
      resolve(r);
    };
    const timer = setTimeout(() => {
      finish({
        ok: false,
        ms: null,
        certValid: false,
        issuer: null,
        expiry: null,
        protocol: null,
        error: `Handshake TLS excedeu ${timeoutMs}ms`,
      });
    }, timeoutMs);
    let socket: tls.TLSSocket;
    try {
      socket = tls.connect(
        {
          host,
          port,
          servername: sni,
          rejectUnauthorized: false,
          timeout: timeoutMs,
        },
        () => {
          clearTimeout(timer);
          const ms = Date.now() - started;
          try {
            const cert = socket.getPeerCertificate(true);
            const protocol = socket.getProtocol() ?? null;
            const authorized = socket.authorized;
            let issuer: string | null = null;
            let expiry: string | null = null;
            if (cert && Object.keys(cert).length > 0) {
              const c = cert as unknown as Record<string, unknown>;
              const iss = c["issuer"] as Record<string, unknown> | undefined;
              issuer =
                (iss?.["O"] as string) ||
                (iss?.["CN"] as string) ||
                (typeof iss === "object" ? JSON.stringify(iss).slice(0, 120) : null);
              expiry = (c["valid_to"] as string) ?? null;
            }
            // Certificado considerado válido apenas se socket.authorized === true
            finish({
              ok: true,
              ms,
              certValid: authorized === true,
              issuer,
              expiry,
              protocol,
              error: authorized
                ? null
                : (socket.authorizationError
                    ? String(socket.authorizationError)
                    : "Certificado não validado"),
            });
          } catch (e) {
            finish({
              ok: true,
              ms,
              certValid: false,
              issuer: null,
              expiry: null,
              protocol: null,
              error: e instanceof Error ? e.message : "TLS ok, cert indeterminado",
            });
          }
        }
      );
      socket.once("error", (err) => {
        clearTimeout(timer);
        finish({
          ok: false,
          ms: null,
          certValid: false,
          issuer: null,
          expiry: null,
          protocol: null,
          error: err.message || "Erro TLS",
        });
      });
      socket.once("timeout", () => {
        clearTimeout(timer);
        finish({
          ok: false,
          ms: null,
          certValid: false,
          issuer: null,
          expiry: null,
          protocol: null,
          error: "Timeout TLS",
        });
      });
    } catch (e) {
      clearTimeout(timer);
      finish({
        ok: false,
        ms: null,
        certValid: false,
        issuer: null,
        expiry: null,
        protocol: null,
        error: e instanceof Error ? e.message : "Falha TLS",
      });
    }
  });
}

export async function measureLatency(
  host: string,
  port: number,
  samples = 3,
  timeoutMs = 4000
): Promise<{
  ok: boolean;
  min: number | null;
  avg: number | null;
  max: number | null;
  loss: number;
  samplesMs: (number | null)[];
}> {
  const samplesMs: (number | null)[] = [];
  for (let i = 0; i < samples; i++) {
    const r = await testTcp(host, port, timeoutMs);
    samplesMs.push(r.ok && r.ms !== null ? r.ms : null);
    if (i < samples - 1) await new Promise((r) => setTimeout(r, 180));
  }
  const valid = samplesMs.filter((v): v is number => v !== null);
  if (valid.length === 0)
    return {
      ok: false,
      min: null,
      avg: null,
      max: null,
      loss: 100,
      samplesMs,
    };
  const min = Math.min(...valid);
  const max = Math.max(...valid);
  const avg = Math.round(valid.reduce((a, b) => a + b, 0) / valid.length);
  const loss = Math.round(
    ((samples - valid.length) / samples) * 100
  );
  return { ok: true, min, avg, max, loss, samplesMs };
}
