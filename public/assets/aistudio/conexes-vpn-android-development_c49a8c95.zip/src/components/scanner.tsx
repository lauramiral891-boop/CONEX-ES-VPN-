"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  Radar, Play, Search, Zap, Eye, Trash2, Save, CheckCircle2, XCircle,
  AlertTriangle, Clock, Globe, RefreshCw, Download, FlaskConical,
} from "lucide-react";
import { api, fmtDateTime, statusBadge } from "@/lib/client";

type SniRow = {
  id: number | null;
  domain: string;
  operator: string;
  mode: string;
  dnsResolved: boolean;
  dnsIps: string;
  portsTested: string;
  portAccessible: boolean;
  accessiblePorts: string;
  tlsOk: boolean;
  certValid: boolean;
  certIssuer: string;
  certExpiry: string;
  tlsProtocol: string;
  latencyMs: number | null;
  status: string;
  errorText: string;
  createdAt?: string;
  elapsedMs?: number;
};

const STEPS = ["Recolha", "DNS", "Portas", "TLS/SNI", "Medição", "Guardar"];

export function ScannerPanel(props: {
  operator: string;
  notify: (m: string, k?: "ok" | "err" | "info") => void;
}) {
  const { operator, notify } = props;
  const [tab, setTab] = useState<"manual" | "auto" | "historico">("manual");
  const [domains, setDomains] = useState("unitel.ao\nwww.google.com");
  const [ports, setPorts] = useState("443, 8443");
  const [scanning, setScanning] = useState(false);
  const [step, setStep] = useState(0);
  const [results, setResults] = useState<SniRow[]>([]);
  const [history, setHistory] = useState<SniRow[]>([]);
  const [filterStatus, setFilterStatus] = useState("TODOS");
  const [candidates, setCandidates] = useState<{ domain: string; source: string; note: string }[]>([]);
  const [selected, setSelected] = useState<string[]>([]);
  const [deepMode, setDeepMode] = useState(false);
  const [live, setLive] = useState(false);
  const liveRef = useRef<NodeJS.Timeout | null>(null);

  const loadHistory = useCallback(async () => {
    try {
      const d = (await api(`/api/sni/history?operator=${operator}&status=${filterStatus}&limit=100`)) as { results: SniRow[] };
      setHistory(d.results);
    } catch {}
  }, [operator, filterStatus]);

  const loadCandidates = useCallback(async () => {
    try {
      const d = (await api(`/api/sni/candidates?operator=${operator}`)) as { candidates: { domain: string; source: string; note: string }[] };
      setCandidates(d.candidates);
      setSelected(d.candidates.slice(0, 6).map((c) => c.domain));
    } catch {}
  }, [operator]);

  useEffect(() => {
    loadHistory();
  }, [loadHistory]);
  useEffect(() => {
    loadCandidates();
  }, [loadCandidates]);

  // Live Monitor
  useEffect(() => {
    if (live && selected.length > 0) {
      const tick = async () => {
        try {
          await api("/api/sni/scan", { method: "POST", body: JSON.stringify({ domains: selected.slice(0, 8), operator, mode: "live" }) });
          loadHistory();
        } catch {}
      };
      tick();
      liveRef.current = setInterval(tick, 45000);
      return () => {
        if (liveRef.current) clearInterval(liveRef.current);
      };
    } else if (liveRef.current) {
      clearInterval(liveRef.current);
    }
  }, [live, selected, operator, loadHistory]);

  const parsePorts = (): number[] => {
    return ports.split(/[,\s]+/).map((p) => Number(p.trim())).filter((p) => Number.isInteger(p) && p > 0 && p <= 65535).slice(0, 8);
  };

  const runManual = async () => {
    const list = domains.split(/[\n,\s]+/).map((d) => d.trim()).filter(Boolean).slice(0, 20);
    if (list.length === 0) {
      notify("Introduza pelo menos um domínio", "err");
      return;
    }
    setScanning(true);
    setStep(0);
    setResults([]);
    const stepTimer = setInterval(() => setStep((s) => Math.min(s + 1, STEPS.length - 1)), 1200);
    try {
      const d = (await api("/api/sni/scan", {
        method: "POST",
        body: JSON.stringify({ domains: list, operator, mode: "manual", ports: parsePorts() }),
      })) as { results: SniRow[]; counts: Record<string, number> };
      setResults(d.results);
      loadHistory();
      notify(`Scan concluído: ${d.counts.COMPATIVEL ?? 0} compatível · ${d.counts.PARCIAL ?? 0} parcial · ${d.counts.FALHOU ?? 0} falhou`, "ok");
    } catch (e) {
      notify(e instanceof Error ? e.message : "Falha no scan", "err");
    } finally {
      clearInterval(stepTimer);
      setScanning(false);
      setStep(STEPS.length - 1);
    }
  };

  const runAuto = async (mode: "auto" | "deep") => {
    if (selected.length === 0) {
      notify("Seleccione pelo menos um candidato", "err");
      return;
    }
    setScanning(true);
    setStep(0);
    setResults([]);
    const stepTimer = setInterval(() => setStep((s) => Math.min(s + 1, STEPS.length - 1)), 1500);
    try {
      const d = (await api("/api/sni/scan", {
        method: "POST",
        body: JSON.stringify({
          domains: selected.slice(0, 15),
          operator,
          mode,
          ports: mode === "deep" ? [443, 8443, 80, 2083, 2087, 9443] : [443, 8443],
        }),
      })) as { results: SniRow[]; counts: Record<string, number> };
      setResults(d.results);
      loadHistory();
      notify(`${mode === "deep" ? "Deep Scan" : "Auto Scan"} concluído: ${d.counts.COMPATIVEL ?? 0} compatível · ${d.counts.PARCIAL ?? 0} parcial · ${d.counts.FALHOU ?? 0} falhou`, "ok");
    } catch (e) {
      notify(e instanceof Error ? e.message : "Falha no scan", "err");
    } finally {
      clearInterval(stepTimer);
      setScanning(false);
      setStep(STEPS.length - 1);
    }
  };

  const clearHistory = async () => {
    if (!confirm("Apagar todo o histórico de SNI?")) return;
    try {
      await api("/api/sni/history", { method: "DELETE" });
      setHistory([]);
      notify("Histórico apagado", "info");
    } catch (e) {
      notify(e instanceof Error ? e.message : "Falha", "err");
    }
  };

  const toggleCandidate = (d: string) => {
    setSelected((s) => (s.includes(d) ? s.filter((x) => x !== d) : [...s, d]));
  };

  return (
    <div className="space-y-4">
      <div className="cv-card p-3 flex gap-3 items-start border-l-4" style={{ borderLeftColor: "#7c3aed" }}>
        <FlaskConical className="w-5 h-5 text-purple-300 shrink-0 mt-0.5" />
        <p className="text-xs leading-relaxed opacity-90">
          <strong className="text-purple-300">SNI Auto Finder:</strong> procura, testa e organiza domínios para{" "}
          <strong>{operator}</strong>. Pipeline real: Recolha → DNS → Portas → TLS/SNI → Medição → Guardar.{" "}
          <strong>Um domínio que responde NÃO é automaticamente um SNI funcional</strong> — só é{" "}
          <strong>COMPATÍVEL</strong> com DNS + TCP + TLS e certificado válido. E compatibilidade técnica{" "}
          <strong>não significa tráfego gratuito</strong>.
        </p>
      </div>

      {/* Classificação */}
      <div className="cv-card p-3">
        <div className="flex flex-wrap gap-2 items-center text-[11px]">
          <span className="font-extrabold opacity-70 mr-1">CLASSIFICAÇÃO:</span>
          <span className={`badge ${statusBadge("COMPATIVEL")}`}>● Compatível — DNS e TLS funcionaram</span>
          <span className={`badge ${statusBadge("PARCIAL")}`}>● Parcial — só alguns testes passaram</span>
          <span className={`badge ${statusBadge("FALHOU")}`}>● Falhou — testes falharam</span>
          <span className={`badge ${statusBadge("PENDENTE")}`}>● Pendente — ainda não verificado</span>
        </div>
      </div>

      {/* Modos */}
      <div className="grid grid-cols-3 gap-2">
        {[
          { k: "manual", label: "Manual", icon: <Search className="w-4 h-4" />, desc: "Domínios próprios" },
          { k: "auto", label: deepMode ? "Deep Scan" : "Auto Scan", icon: <Zap className="w-4 h-4" />, desc: deepMode ? "Testes completos" : "Candidatos auto" },
          { k: "historico", label: "Histórico", icon: <Clock className="w-4 h-4" />, desc: "Resultados guardados" },
        ].map((t) => (
          <button
            key={t.k}
            onClick={() => setTab(t.k as typeof tab)}
            className={`cv-card p-3 text-center cursor-pointer transition border-2 ${tab === t.k ? "tab-active" : "opacity-75 hover:opacity-100"}`}
          >
            <span className="flex justify-center mb-1">{t.icon}</span>
            <span className="block font-extrabold text-sm">{t.label}</span>
            <span className="block text-[10px] opacity-60">{t.desc}</span>
          </button>
        ))}
      </div>

      {/* Progresso */}
      {scanning && (
        <div className="cv-card p-4 text-center relative overflow-hidden">
          <div className="absolute inset-x-0 h-0.5 bg-cyan-400/70" style={{ animation: "scanline 2s linear infinite", position: "absolute" }} />
          <Radar className="w-12 h-12 mx-auto text-cyan-300 scanning-ring" />
          <p className="font-extrabold mt-2">A procurar e testar…</p>
          <div className="flex justify-center gap-1.5 mt-3 flex-wrap">
            {STEPS.map((s, i) => (
              <span key={s} className={`text-[10px] font-bold px-2 py-1 rounded-full border ${i <= step ? "border-cyan-400/60 bg-cyan-500/15 text-cyan-200" : "border-white/10 opacity-50"}`}>
                {i < step ? "✓ " : ""}{s}
              </span>
            ))}
          </div>
          <div className="h-2 rounded-full bg-white/10 mt-3 overflow-hidden">
            <div className="h-full bg-gradient-to-r from-blue-500 via-cyan-400 to-purple-500 transition-all" style={{ width: `${((step + 1) / STEPS.length) * 100}%` }} />
          </div>
        </div>
      )}

      {tab === "manual" && (
        <div className="cv-card p-4">
          <h3 className="font-extrabold text-sm mb-2 flex items-center gap-2"><Search className="w-4 h-4 text-cyan-300" /> TESTE MANUAL — {operator}</h3>
          <div className="grid md:grid-cols-3 gap-3">
            <div className="md:col-span-2">
              <label className="text-[11px] opacity-70">Domínios (um por linha, máx. 20)</label>
              <textarea className="cv-input mt-1 font-mono" rows={5} value={domains} onChange={(e) => setDomains(e.target.value)} placeholder={"exemplo.ao\noutro-dominio.com"} />
            </div>
            <div>
              <label className="text-[11px] opacity-70">Portas autorizadas</label>
              <input className="cv-input mt-1 font-mono" value={ports} onChange={(e) => setPorts(e.target.value)} />
              <p className="text-[10px] mt-1 opacity-60">Sugeridas: 443, 8443. Deep: +80, 2083, 2087, 9443.</p>
              <button onClick={runManual} disabled={scanning} className="btn-blue w-full mt-3 rounded-xl py-2.5 text-sm disabled:opacity-50 cursor-pointer flex items-center justify-center gap-2">
                <Play className="w-4 h-4" /> {scanning ? "A testar…" : "Testar domínios"}
              </button>
            </div>
          </div>
        </div>
      )}

      {tab === "auto" && (
        <div className="space-y-3">
          <div className="cv-card p-4">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
              <h3 className="font-extrabold text-sm flex items-center gap-2"><Zap className="w-4 h-4 text-amber-300" /> SNI AUTO FINDER — {operator}</h3>
              <div className="flex gap-2">
                <label className="text-[11px] font-bold px-2.5 py-1.5 rounded-lg border cursor-pointer flex items-center gap-1.5 border-white/15">
                  <input type="checkbox" checked={deepMode} onChange={(e) => setDeepMode(e.target.checked)} className="accent-purple-500" />
                  Deep Scan
                </label>
                <button onClick={() => setLive(!live)} className={`text-[11px] font-bold px-2.5 py-1.5 rounded-lg border cursor-pointer flex items-center gap-1.5 ${live ? "border-emerald-400/60 bg-emerald-500/15 text-emerald-200" : "border-white/15"}`}>
                  <Eye className="w-3.5 h-3.5" /> Live Monitor {live ? "ON" : "OFF"}
                </button>
              </div>
            </div>
            {live && <p className="text-[11px] mb-2 text-emerald-300">● Live Monitor activo: reverifica os seleccionados a cada 45 segundos.</p>}
            <div className="grid sm:grid-cols-2 gap-2 max-h-64 overflow-y-auto scroll-thin pr-1">
              {candidates.map((c) => (
                <label key={c.domain} className={`rounded-xl border p-2.5 cursor-pointer flex items-start gap-2 text-xs ${selected.includes(c.domain) ? "border-cyan-400/60 bg-cyan-500/10" : "border-white/10 opacity-80"}`}>
                  <input type="checkbox" checked={selected.includes(c.domain)} onChange={() => toggleCandidate(c.domain)} className="mt-0.5 accent-cyan-500" />
                  <span>
                    <span className="font-bold font-mono">{c.domain}</span>
                    <span className="block opacity-60 text-[10px]">{c.note} · {c.source}</span>
                  </span>
                </label>
              ))}
            </div>
            <div className="flex gap-2 mt-3">
              <button onClick={() => runAuto(deepMode ? "deep" : "auto")} disabled={scanning} className="btn-purple flex-1 rounded-xl py-2.5 text-sm disabled:opacity-50 cursor-pointer flex items-center justify-center gap-2">
                <Play className="w-4 h-4" /> {scanning ? "A testar…" : deepMode ? `Deep Scan (${selected.length})` : `Auto Scan (${selected.length})`}
              </button>
              <button onClick={loadCandidates} className="btn-ghost rounded-xl px-4 text-sm cursor-pointer"><RefreshCw className="w-4 h-4" /></button>
            </div>
          </div>
        </div>
      )}

      {/* Últimos resultados */}
      {results.length > 0 && (
        <div className="cv-card p-4">
          <h3 className="font-extrabold text-sm mb-3">RESULTADOS DESTA CORRIDA ({results.length})</h3>
          <div className="space-y-2">
            {results.map((r, i) => (
              <SniCard key={i} r={r} />
            ))}
          </div>
        </div>
      )}

      {(tab === "historico" || history.length > 0) && (
        <div className="cv-card p-4">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
            <h3 className="font-extrabold text-sm flex items-center gap-2"><Save className="w-4 h-4 text-emerald-300" /> HISTÓRICO — {operator} ({history.length})</h3>
            <div className="flex gap-2">
              <select className="cv-input !w-auto !py-1.5 text-xs" value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}>
                <option value="TODOS">Todos</option>
                <option value="COMPATIVEL">Compatível</option>
                <option value="PARCIAL">Parcial</option>
                <option value="FALHOU">Falhou</option>
              </select>
              <button onClick={clearHistory} className="btn-ghost rounded-lg px-3 py-1.5 text-xs text-red-300 cursor-pointer"><Trash2 className="w-3.5 h-3.5" /></button>
            </div>
          </div>
          {history.length === 0 ? (
            <p className="text-xs opacity-60 text-center py-4">Sem resultados guardados. Execute um scan.</p>
          ) : (
            <div className="space-y-2 max-h-[480px] overflow-y-auto scroll-thin pr-1">
              {history.map((r) => (
                <SniCard key={r.id} r={r} showDate />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function SniCard({ r, showDate }: { r: SniRow; showDate?: boolean }) {
  return (
    <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="font-mono font-bold text-sm flex items-center gap-2">
          <Globe className="w-4 h-4 text-cyan-300" /> {r.domain}
        </p>
        <div className="flex gap-1.5 items-center">
          {showDate && r.createdAt && <span className="text-[10px] opacity-60">{fmtDateTime(r.createdAt)}</span>}
          <span className="text-[10px] opacity-60 font-bold uppercase">{r.mode}</span>
          <span className={`badge ${statusBadge(r.status)}`}>
            {r.status === "COMPATIVEL" ? <CheckCircle2 className="w-3 h-3" /> : r.status === "FALHOU" ? <XCircle className="w-3 h-3" /> : <AlertTriangle className="w-3 h-3" />}
            {r.status}
          </span>
        </div>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5 mt-2 text-[11px]">
        <Mini label="DNS" ok={r.dnsResolved} detail={r.dnsResolved ? (r.dnsIps.split(",")[0] ?? "ok") : "falhou"} />
        <Mini label="Porta" ok={r.portAccessible} detail={r.accessiblePorts || "—"} />
        <Mini label="TLS" ok={r.tlsOk} detail={r.tlsProtocol || (r.tlsOk ? "ok" : "falhou")} />
        <Mini label="Cert" ok={r.certValid} detail={r.certValid ? "válido" : "não-validado"} />
        <Mini label="Latência" ok={r.latencyMs !== null} detail={r.latencyMs !== null ? `${r.latencyMs}ms` : "—"} neutral />
      </div>
      {(r.errorText || r.certIssuer) && (
        <p className="text-[11px] mt-1.5 opacity-70 break-words">
          {r.errorText ? `⚠ ${r.errorText}` : ""} {r.certIssuer ? `· Emissor: ${r.certIssuer.slice(0, 80)}` : ""}
        </p>
      )}
    </div>
  );
}

function Mini({ label, ok, detail, neutral }: { label: string; ok: boolean; detail: string; neutral?: boolean }) {
  return (
    <div className={`rounded-lg px-2 py-1.5 border ${neutral ? "border-white/10 bg-white/5" : ok ? "border-emerald-400/30 bg-emerald-500/10" : "border-red-400/30 bg-red-500/10"}`}>
      <p className="font-extrabold text-[9px] uppercase tracking-wider opacity-70">{label}</p>
      <p className="font-semibold truncate" title={detail}>{detail}</p>
    </div>
  );
}

export function exportJson(filename: string, data: unknown) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
}
