import { resolveDns, testTcp, testTls, measureLatency, sanitizeDomain } from "@/lib/network";
import { writeLog, touchDaily, jsonDetails } from "@/lib/server-log";
import { db } from "@/db";
import { networkTests } from "@/db/schema";

export const dynamic = "force-dynamic";

const OPERATOR_TARGETS: Record<string, { portals: string[]; dns: string[]; tcp: { host: string; port: number }[] }> = {
  UNITEL: {
    portals: ["unitel.ao", "www.unitel.ao"],
    dns: ["unitel.ao", "google.com"],
    tcp: [
      { host: "unitel.ao", port: 443 },
      { host: "unitel.ao", port: 80 },
      { host: "8.8.8.8", port: 53 },
    ],
  },
  AFRICELL: {
    portals: ["africell.ao", "www.africell.ao"],
    dns: ["africell.ao", "google.com"],
    tcp: [
      { host: "africell.ao", port: 443 },
      { host: "africell.ao", port: 80 },
      { host: "8.8.8.8", port: 53 },
    ],
  },
};

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { operator?: string; suite?: string[] };
    const operator = (body.operator || "UNITEL").toUpperCase();
    if (!["UNITEL", "AFRICELL"].includes(operator)) {
      return Response.json({ ok: false, error: "Operadora inválida (UNITEL | AFRICELL)" }, { status: 400 });
    }
    const suite = Array.isArray(body.suite) && body.suite.length > 0
      ? body.suite
      : ["dns", "tcp", "tls", "latencia"];
    const targets = OPERATOR_TARGETS[operator];

    await writeLog("operadora", "info", `Diagnóstico ${operator} iniciado (${suite.join(", ")})`);

    const report: Record<string, unknown> = { operator, startedAt: new Date().toISOString() };

    // DNS
    if (suite.includes("dns")) {
      const dnsResults = [];
      for (const d of targets.dns) {
        const r = await resolveDns(sanitizeDomain(d));
        dnsResults.push({ target: d, ...r });
        await db.insert(networkTests).values({
          operator, testType: "dns", target: d, success: r.ok, latencyMs: r.ms,
          details: jsonDetails(r),
        }).catch(() => {});
      }
      report["dns"] = dnsResults;
    }

    // TCP
    if (suite.includes("tcp")) {
      const tcpResults = [];
      for (const t of targets.tcp) {
        const r = await testTcp(t.host, t.port, 5000);
        tcpResults.push({ ...t, ...r });
        await db.insert(networkTests).values({
          operator, testType: "tcp", target: `${t.host}:${t.port}`, success: r.ok, latencyMs: r.ms,
          details: jsonDetails(r),
        }).catch(() => {});
      }
      report["tcp"] = tcpResults;
    }

    // TLS
    if (suite.includes("tls")) {
      const tlsResults = [];
      for (const p of targets.portals) {
        const r = await testTls(p, 443, p, 8000);
        tlsResults.push({ host: p, port: 443, sni: p, ...r });
        await db.insert(networkTests).values({
          operator, testType: "tls", target: `${p}:443`, success: r.ok, latencyMs: r.ms,
          details: jsonDetails(r),
        }).catch(() => {});
      }
      report["tls"] = tlsResults;
    }

    // Latência
    if (suite.includes("latencia")) {
      const latResults = [];
      for (const p of targets.portals) {
        const r = await measureLatency(p, 443, 4, 4000);
        latResults.push({ host: p, port: 443, ...r });
        await db.insert(networkTests).values({
          operator, testType: "latencia", target: `${p}:443`, success: r.ok, latencyMs: r.avg,
          details: jsonDetails(r),
        }).catch(() => {});
      }
      report["latencia"] = latResults;
    }

    // Avaliação de estabilidade baseada apenas nas medições
    const latArr = (report["latencia"] as { ok: boolean; avg: number | null; loss: number }[] | undefined) ?? [];
    const okCount = latArr.filter((l) => l.ok).length;
    const avgLat = latArr.filter((l) => l.avg !== null).map((l) => l.avg as number);
    const mean = avgLat.length > 0 ? Math.round(avgLat.reduce((a, b) => a + b, 0) / avgLat.length) : null;
    const maxLoss = latArr.length > 0 ? Math.max(...latArr.map((l) => l.loss)) : 100;
    let verdict = "SEM_DADOS";
    if (latArr.length > 0) {
      if (okCount === 0) verdict = "INALCANCAVEL";
      else if (maxLoss >= 50) verdict = "INSTAVEL";
      else if (mean !== null && mean <= 150) verdict = "ESTAVEL_RAPIDO";
      else if (mean !== null && mean <= 400) verdict = "ESTAVEL";
      else verdict = "LENTO_MAS_ALCANCAVEL";
    }

    report["verdict"] = verdict;
    report["summary"] = {
      portaisAlcancaveis: okCount,
      latenciaMediaMs: mean,
      perdaMaximaPct: latArr.length > 0 ? maxLoss : null,
    };
    report["finishedAt"] = new Date().toISOString();
    report["honesty"] =
      "Diagnóstico de conectividade (DNS/TCP/TLS/latência) a partir do servidor. Não mede tarifação nem zero-rating da operadora.";

    await touchDaily({ tests: 8 });
    await writeLog(
      "operadora",
      verdict === "INALCANCAVEL" ? "error" : "success",
      `Diagnóstico ${operator} concluído: ${verdict} (média ${mean ?? "—"}ms, perda ${maxLoss}%)`,
      jsonDetails(report["summary"])
    );

    return Response.json({ ok: true, ...report });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}

export async function GET() {
  try {
    const rows = await db.select().from(networkTests).limit(200);
    const byOperator: Record<string, typeof rows> = { UNITEL: [], AFRICELL: [] };
    for (const r of rows) {
      if (r.operator === "UNITEL" || r.operator === "AFRICELL") byOperator[r.operator].push(r);
    }
    return Response.json({ ok: true, recent: rows.slice(-50).reverse(), byOperator });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}
