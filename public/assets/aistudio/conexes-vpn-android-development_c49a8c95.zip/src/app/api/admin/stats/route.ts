import { db } from "@/db";
import { adminUsers, appLogs, sniResults, servers } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";
import { requireAdmin } from "@/lib/admin-auth";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return Response.json({ ok: false, error: auth.error }, { status: 401 });
  try {
    const users = await db.select({ id: adminUsers.id, username: adminUsers.username, role: adminUsers.role, createdAt: adminUsers.createdAt }).from(adminUsers);
    const errors = await db.select().from(appLogs).where(eq(appLogs.level, "error")).orderBy(desc(appLogs.id)).limit(50);
    const [sniByStatus] = await db.select({ c: sql<string>`count(*)` }).from(sniResults);
    const statusBreak = await db.execute(sql`select status, count(*) as total from sni_results group by status`);
    const [srv] = await db.select({ c: sql<number>`count(*)` }).from(servers);
    return Response.json({
      ok: true,
      users,
      errorReports: errors,
      totals: { sniTotal: Number(sniByStatus?.c ?? 0), servers: Number(srv?.c ?? 0), errors: errors.length },
      sniByStatus: (statusBreak as unknown as { rows: { status: string; total: string }[] }).rows ?? [],
    });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}
