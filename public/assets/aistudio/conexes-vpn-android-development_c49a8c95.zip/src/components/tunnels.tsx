"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  KeyRound, ShieldCheck, Download, Upload, Plus, Pencil, Trash2,
  AlertTriangle, CheckCircle2, Server,
} from "lucide-react";
import { api, fmtDateTime } from "@/lib/client";
import type { ServerRow } from "./servers";

export type Profile = {
  id: number; name: string; serverId: number | null; protocol: string;
  host: string; port: number; sni: string | null; method: string;
  payload: string; username: string | null; hasPassword: boolean;
  autoReconnect: boolean; dnsProtection: boolean; dnsChoice: string;
  extraConfig: string | null; createdAt: string; updatedAt: string;
};

const PROTOCOLS = [
  { name: "WireGuard", desc: "UDP moderno, chaves públicas", ports: "51820 (UDP)" },
  { name: "OpenVPN", desc: "TCP/UDP, ficheiros .ovpn", ports: "1194, 443" },
  { name: "SSH Tunnel", desc: "Túnel SSH + utilizador/senha", ports: "22, 2222, 443" },
  { name: "SSL/TLS", desc: "Stunnel / TLS com SNI", ports: "443, 8443" },
  { name: "V2Ray", desc: "VMess/VLESS + transporte", ports: "443, 80, 2083" },
];

const emptyForm = {
  name: "", protocol: "SSL/TLS", host: "", port: 443, sni: "",
  method: "AES-256-GCM", payload: "auto", username: "", password: "",
  serverId: "" as string | number, autoReconnect: true, dnsProtection: true,
  dnsChoice: "1.1.1.1, 8.8.8.8", extraConfig: "",
};

export function TunnelsPanel(props: {
  profiles: Profile[];
  reloadProfiles: () => void;
  servers: ServerRow[];
  activeProfile: number | null;
  setActiveProfile: (id: number | null) => void;
  notify: (m: string, k?: "ok" | "err" | "info") => void;
}) {
  const { profiles, reloadProfiles, servers, activeProfile, setActiveProfile, notify } = props;
  const [proto, setProto] = useState("SSL/TLS");
  const [form, setForm] = useState(emptyForm);
  const [editing, setEditing] = useState<Profile | null>(null);
  const [showForm, setShowForm] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    reloadProfiles();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    setForm((f) => ({ ...f, protocol: proto }));
  }, [proto]);

  const openNew = useCallback(() => {
    setEditing(null);
    setForm({ ...emptyForm, protocol: proto });
    setShowForm(true);
  }, [proto]);

  const openEdit = (p: Profile) => {
    setEditing(p);
    setProto(p.protocol);
    setForm({
      name: p.name, protocol: p.protocol, host: p.host, port: p.port, sni: p.sni ?? "",
      method: p.method, payload: p.payload, username: p.username ?? "", password: "",
      serverId: p.serverId ?? "", autoReconnect: p.autoReconnect, dnsProtection: p.dnsProtection,
      dnsChoice: p.dnsChoice, extraConfig: p.extraConfig ?? "",
    });
    setShowForm(true);
  };

  const save = async () => {
    if (!form.name.trim() || !form.host.trim()) {
      notify("Nome e anfitrião são obrigatórios", "err");
      return;
    }
    try {
      const payload = { ...form, serverId: form.serverId ? Number(form.serverId) : null };
      if (editing) {
        await api(`/api/profiles/${editing.id}`, { method: "PUT", body: JSON.stringify(payload) });
        notify("Perfil actualizado", "ok");
      } else {
        await api("/api/profiles", { method: "POST", body: JSON.stringify(payload) });
        notify("Perfil guardado (palavra-passe cifrada)", "ok");
      }
      setShowForm(false);
      reloadProfiles();
    } catch (e) {
      notify(e instanceof Error ? e.message : "Falha", "err");
    }
  };

  const remove = async (id: number) => {
    if (!confirm("Remover este perfil?")) return;
    try {
      await api(`/api/profiles/${id}`, { method: "DELETE" });
      notify("Perfil removido", "info");
      if (activeProfile === id) setActiveProfile(null);
      reloadProfiles();
    } catch (e) {
      notify(e instanceof Error ? e.message : "Falha", "err");
    }
  };

  const doExport = (id: number) => {
    window.open(`/api/export/profile/${id}`, "_blank");
  };

  const doImport = async (file: File) => {
    try {
      const text = await file.text();
      const json = JSON.parse(text) as { profile?: Record<string, unknown> };
      if (!json.profile) throw new Error("Ficheiro sem perfil válido");
      await api("/api/import/profile", { method: "POST", body: JSON.stringify({ profile: json.profile }) });
      notify("Configuração importada (reintroduza a palavra-passe)", "ok");
      reloadProfiles();
    } catch (e) {
      notify(e instanceof Error ? e.message : "Ficheiro inválido", "err");
    }
  };

  return (
    <div className="space-y-4">
      <div className="cv-card p-3 flex gap-3 items-start border-l-4" style={{ borderLeftColor: "#7c3aed" }}>
        <AlertTriangle className="w-5 h-5 text-purple-300 shrink-0 mt-0.5" />
        <p className="text-xs leading-relaxed opacity-90">
          <strong className="text-purple-300">Protocolos — estado honesto (EM TESTE):</strong> os perfis guardam
          configuração real (servidor, porta, SNI, método, credenciais cifradas) e são exportáveis para a app Android.
          A <strong>ligação efectiva ao túnel</strong> (WireGuard/OpenVPN/SSH/SSL/V2Ray) executa-se na app Android com
          VPNService — <strong>nenhum protocolo é apresentado como ligado sem código e teste reais</strong>.
        </p>
      </div>

      {/* Protocolos */}
      <div className="flex gap-2 overflow-x-auto scroll-thin pb-1">
        {PROTOCOLS.map((p) => (
          <button
            key={p.name}
            onClick={() => setProto(p.name)}
            className={`shrink-0 rounded-xl px-4 py-2.5 border-2 text-left cursor-pointer transition ${proto === p.name ? "tab-active" : "border-white/10 opacity-70 hover:opacity-100"}`}
          >
            <span className="block font-extrabold text-sm">{p.name}</span>
            <span className="block text-[10px] opacity-70">{p.desc} · {p.ports}</span>
          </button>
        ))}
      </div>

      <div className="flex flex-wrap gap-2 justify-between items-center">
        <p className="text-xs opacity-70">Perfil activo: <strong>{profiles.find((p) => p.id === activeProfile)?.name ?? "nenhum"}</strong> · {profiles.length} guardado(s)</p>
        <div className="flex gap-2">
          <input ref={fileRef} type="file" accept=".json" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) doImport(f); e.target.value = ""; }} />
          <button onClick={() => fileRef.current?.click()} className="btn-ghost rounded-xl px-3 py-2 text-xs cursor-pointer flex items-center gap-1.5">
            <Upload className="w-3.5 h-3.5" /> Importar
          </button>
          <button onClick={openNew} className="btn-gold rounded-xl px-3.5 py-2 text-xs cursor-pointer flex items-center gap-1.5">
            <Plus className="w-3.5 h-3.5" /> Novo perfil {proto}
          </button>
        </div>
      </div>

      {showForm && (
        <div className="cv-card p-4">
          <h3 className="font-extrabold text-sm mb-3 flex items-center gap-2">
            <KeyRound className="w-4 h-4 text-amber-300" /> {editing ? `EDITAR #${editing.id}` : "CONFIGURAÇÃO DO TÚNEL"} — {form.protocol}
          </h3>
          <div className="grid sm:grid-cols-2 gap-2">
            <input className="cv-input" placeholder="Nome do perfil *" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            <select className="cv-input" value={form.serverId} onChange={(e) => {
              const sid = e.target.value;
              const srv = servers.find((s) => String(s.id) === sid);
              setForm({ ...form, serverId: sid, host: srv ? srv.address : form.host, port: srv ? srv.port : form.port });
            }}>
              <option value="">— Servidor (opcional) —</option>
              {servers.map((s) => <option key={s.id} value={s.id}>{s.name} · {s.address}:{s.port}</option>)}
            </select>
            <input className="cv-input font-mono" placeholder="Anfitrião (host) *" value={form.host} onChange={(e) => setForm({ ...form, host: e.target.value })} />
            <input className="cv-input" type="number" placeholder="Porta" value={form.port} onChange={(e) => setForm({ ...form, port: Number(e.target.value) })} />
            <input className="cv-input font-mono" placeholder="SNI (opcional)" value={form.sni} onChange={(e) => setForm({ ...form, sni: e.target.value })} />
            <select className="cv-input" value={form.method} onChange={(e) => setForm({ ...form, method: e.target.value })}>
              {["AES-256-GCM", "AES-128-GCM", "ChaCha20-Poly1305", "AES-256-CBC", "auto"].map((m) => <option key={m} value={m}>{m}</option>)}
            </select>
            <input className="cv-input" placeholder="Payload" value={form.payload} onChange={(e) => setForm({ ...form, payload: e.target.value })} />
            <input className="cv-input" placeholder="DNS (ex.: 1.1.1.1, 8.8.8.8)" value={form.dnsChoice} onChange={(e) => setForm({ ...form, dnsChoice: e.target.value })} />
            <input className="cv-input" placeholder="Utilizador" value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} />
            <input className="cv-input" type="password" placeholder={editing ? "Nova palavra-passe (vazio = manter)" : "Palavra-passe (cifrada AES-256)"} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
          </div>
          {form.protocol === "WireGuard" && (
            <textarea className="cv-input mt-2 font-mono text-xs" rows={3} placeholder="Config extra WireGuard (chaves públicas, AllowedIPs, Endpoint…)" value={form.extraConfig} onChange={(e) => setForm({ ...form, extraConfig: e.target.value })} />
          )}
          {form.protocol === "V2Ray" && (
            <textarea className="cv-input mt-2 font-mono text-xs" rows={3} placeholder="Config extra V2Ray (UUID/vless://, transporte ws/tcp, path, host…)" value={form.extraConfig} onChange={(e) => setForm({ ...form, extraConfig: e.target.value })} />
          )}
          {form.protocol === "OpenVPN" && (
            <textarea className="cv-input mt-2 font-mono text-xs" rows={3} placeholder="Directivas extra OpenVPN (remote, proto, cipher, auth…)" value={form.extraConfig} onChange={(e) => setForm({ ...form, extraConfig: e.target.value })} />
          )}
          <div className="flex flex-wrap gap-4 mt-3 text-xs font-bold">
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={form.autoReconnect} onChange={(e) => setForm({ ...form, autoReconnect: e.target.checked })} className="accent-cyan-500 w-4 h-4" />
              Reconexão automática
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={form.dnsProtection} onChange={(e) => setForm({ ...form, dnsProtection: e.target.checked })} className="accent-emerald-500 w-4 h-4" />
              <ShieldCheck className="w-4 h-4 text-emerald-400" /> Protecção contra fugas de DNS
            </label>
          </div>
          <div className="flex gap-2 mt-3">
            <button onClick={save} className="btn-gold flex-1 rounded-xl py-2.5 text-sm cursor-pointer">Guardar perfil</button>
            <button onClick={() => setShowForm(false)} className="btn-ghost rounded-xl px-4 text-sm cursor-pointer">Cancelar</button>
          </div>
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-3">
        {profiles.length === 0 && (
          <div className="cv-card p-6 text-center col-span-2">
            <Server className="w-8 h-8 mx-auto text-cyan-300 mb-2" />
            <p className="font-bold text-sm">Sem perfis guardados</p>
            <p className="text-xs opacity-60 mt-1">Crie o primeiro perfil de túnel para {proto}.</p>
          </div>
        )}
        {profiles.map((p) => (
          <div key={p.id} className={`cv-card p-3.5 ${activeProfile === p.id ? "ring-2 ring-amber-400/70" : ""}`}>
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="font-bold text-sm flex items-center gap-1.5">
                  {activeProfile === p.id && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                  {p.name}
                </p>
                <p className="text-[11px] font-mono opacity-75 mt-0.5">{p.protocol} · {p.host}:{p.port}{p.sni ? ` · SNI ${p.sni}` : ""}</p>
                <div className="flex flex-wrap gap-1 mt-1.5">
                  <span className="badge bg-white/10 border border-white/15">{p.method}</span>
                  {p.dnsProtection && <span className="badge bg-emerald-500/15 text-emerald-300 border border-emerald-400/30">DNS protegido</span>}
                  {p.autoReconnect && <span className="badge bg-sky-500/15 text-sky-300 border border-sky-400/30">auto-reconnect</span>}
                  {p.hasPassword && <span className="badge bg-amber-500/15 text-amber-300 border border-amber-400/30">●●● cifrada</span>}
                </div>
                <p className="text-[10px] opacity-60 mt-1.5">Actualizado: {fmtDateTime(p.updatedAt)}</p>
              </div>
            </div>
            <div className="flex gap-1.5 mt-2.5">
              <button onClick={() => { setActiveProfile(p.id); notify(`Perfil activo: ${p.name}`, "ok"); }} className={`flex-1 rounded-lg py-1.5 text-xs font-bold cursor-pointer ${activeProfile === p.id ? "btn-gold" : "btn-blue"}`}>
                {activeProfile === p.id ? "Activo" : "Activar"}
              </button>
              <button onClick={() => doExport(p.id)} className="btn-ghost rounded-lg px-3 text-xs cursor-pointer" title="Exportar (sem palavra-passe)">
                <Download className="w-3.5 h-3.5" />
              </button>
              <button onClick={() => openEdit(p)} className="btn-ghost rounded-lg px-3 text-xs cursor-pointer">
                <Pencil className="w-3.5 h-3.5" />
              </button>
              <button onClick={() => remove(p.id)} className="btn-ghost rounded-lg px-3 text-xs text-red-300 cursor-pointer">
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
