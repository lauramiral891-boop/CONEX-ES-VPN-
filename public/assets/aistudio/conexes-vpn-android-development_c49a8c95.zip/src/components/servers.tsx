"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Server, Plus, Pencil, Trash2, RefreshCw, Zap, CheckCircle2, XCircle, Power,
} from "lucide-react";
import { api, apiAdmin, fmtDateTime } from "@/lib/client";

export type ServerRow = {
  id: number; name: string; country: string; region: string; address: string;
  port: number; protocol: string; operator: string; kind: string;
  online: boolean; lastPingMs: number | null; lastCheck: string | null;
  loadPercent: number | null; enabled: boolean; notes: string | null;
};

const REGIONS = ["TODOS", "Angola", "Africa", "Europa", "America", "Asia", "Global"];

export function ServersPanel(props: {
  servers: ServerRow[];
  reloadServers: () => void;
  activeServer: ServerRow | null;
  setActiveServer: (s: ServerRow | null) => void;
  notify: (m: string, k?: "ok" | "err" | "info") => void;
}) {
  const { servers, reloadServers, activeServer, setActiveServer, notify } = props;
  const [region, setRegion] = useState("TODOS");
  const [checking, setChecking] = useState<number | null>(null);
  const [checkingAll, setCheckingAll] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<ServerRow | null>(null);
  const [form, setForm] = useState({
    name: "", country: "Angola", region: "Angola", address: "", port: 443,
    protocol: "SSL/TLS", operator: "GERAL", kind: "vpn", notes: "",
  });

  const filtered = region === "TODOS" ? servers : servers.filter((s) => s.region === region);

  const check = useCallback(async (id: number) => {
    setChecking(id);
    try {
      await api("/api/servers/check", { method: "POST", body: JSON.stringify({ id }) });
      reloadServers();
    } catch (e) {
      notify(e instanceof Error ? e.message : "Falha", "err");
    } finally {
      setChecking(null);
    }
  }, [reloadServers, notify]);

  const checkAll = useCallback(async () => {
    setCheckingAll(true);
    try {
      const d = (await api("/api/servers/check-all", { method: "POST" })) as { online: number; checked: number };
      notify(`Verificação global: ${d.online}/${d.checked} online`, "ok");
      reloadServers();
    } catch (e) {
      notify(e instanceof Error ? e.message : "Falha", "err");
    } finally {
      setCheckingAll(false);
    }
  }, [reloadServers, notify]);

  useEffect(() => {
    reloadServers();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const openNew = () => {
    setEditing(null);
    setForm({ name: "", country: "Angola", region: "Angola", address: "", port: 443, protocol: "SSL/TLS", operator: "GERAL", kind: "vpn", notes: "" });
    setShowForm(true);
  };

  const openEdit = (s: ServerRow) => {
    setEditing(s);
    setForm({ name: s.name, country: s.country, region: s.region, address: s.address, port: s.port, protocol: s.protocol, operator: s.operator, kind: s.kind, notes: s.notes ?? "" });
    setShowForm(true);
  };

  const save = async () => {
    if (!form.name.trim() || !form.address.trim()) {
      notify("Nome e endereço real são obrigatórios", "err");
      return;
    }
    try {
      if (editing) {
        await apiAdmin(`/api/servers/${editing.id}`, { method: "PUT", body: JSON.stringify(form) });
        notify("Servidor actualizado", "ok");
      } else {
        await apiAdmin("/api/servers", { method: "POST", body: JSON.stringify(form) });
        notify("Servidor adicionado — verifique a conectividade", "ok");
      }
      setShowForm(false);
      reloadServers();
    } catch (e) {
      notify(e instanceof Error ? e.message : "Falha — requer login admin", "err");
    }
  };

  const remove = async (id: number) => {
    if (!confirm("Remover este servidor?")) return;
    try {
      await apiAdmin(`/api/servers/${id}`, { method: "DELETE" });
      notify("Servidor removido", "info");
      reloadServers();
    } catch (e) {
      notify(e instanceof Error ? e.message : "Falha", "err");
    }
  };

  const onlineCount = servers.filter((s) => s.online).length;

  return (
    <div className="space-y-4">
      <div className="cv-card p-3 flex gap-3 items-start border-l-4" style={{ borderLeftColor: "#22c55e" }}>
        <Server className="w-5 h-5 text-emerald-300 shrink-0 mt-0.5" />
        <p className="text-xs leading-relaxed opacity-90">
          <strong className="text-emerald-300">Servidores reais, ordenados por desempenho medido.</strong> Os endpoints
          iniciais são de <strong>diagnóstico</strong> (portais e DNS públicos). Adicione os seus servidores VPN próprios
          ou autorizados no painel admin. <strong>Nenhum servidor é inventado:</strong> sem verificação, o estado é
          apresentado como desconhecido/offline.
        </p>
      </div>

      <div className="flex flex-wrap gap-2 items-center justify-between">
        <div className="flex flex-wrap gap-1.5">
          {REGIONS.map((r) => (
            <button
              key={r}
              onClick={() => setRegion(r)}
              className={`text-[11px] font-bold px-3 py-1.5 rounded-full border cursor-pointer ${region === r ? "border-cyan-400/60 bg-cyan-500/15" : "border-white/10 opacity-70 hover:opacity-100"}`}
            >
              {r}
            </button>
          ))}
        </div>
        <div className="flex gap-2">
          <button onClick={checkAll} disabled={checkingAll} className="btn-blue rounded-xl px-3.5 py-2 text-xs disabled:opacity-50 cursor-pointer flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5" /> {checkingAll ? "A verificar…" : `Verificar todos (${onlineCount}/${servers.length})`}
          </button>
          <button onClick={openNew} className="btn-gold rounded-xl px-3.5 py-2 text-xs cursor-pointer flex items-center gap-1.5">
            <Plus className="w-3.5 h-3.5" /> Adicionar
          </button>
        </div>
      </div>

      {showForm && (
        <div className="cv-card p-4">
          <h3 className="font-extrabold text-sm mb-3">{editing ? `EDITAR #${editing.id}` : "NOVO SERVIDOR"} <span className="text-[10px] opacity-60 font-medium">(requer admin · endereço real obrigatório)</span></h3>
          <div className="grid sm:grid-cols-2 gap-2">
            <input className="cv-input" placeholder="Nome *" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            <input className="cv-input font-mono" placeholder="Endereço real (domínio/IP) *" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
            <input className="cv-input" placeholder="País" value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} />
            <select className="cv-input" value={form.region} onChange={(e) => setForm({ ...form, region: e.target.value })}>
              {REGIONS.filter((r) => r !== "TODOS").map((r) => <option key={r} value={r}>{r}</option>)}
            </select>
            <input className="cv-input" type="number" placeholder="Porta" value={form.port} onChange={(e) => setForm({ ...form, port: Number(e.target.value) })} />
            <select className="cv-input" value={form.protocol} onChange={(e) => setForm({ ...form, protocol: e.target.value })}>
              {["SSL/TLS", "WireGuard", "OpenVPN", "SSH Tunnel", "V2Ray", "DNS", "HTTP"].map((p) => <option key={p} value={p}>{p}</option>)}
            </select>
            <select className="cv-input" value={form.operator} onChange={(e) => setForm({ ...form, operator: e.target.value })}>
              {["GERAL", "UNITEL", "AFRICELL", "ANGOSAT-2"].map((o) => <option key={o} value={o}>{o}</option>)}
            </select>
            <select className="cv-input" value={form.kind} onChange={(e) => setForm({ ...form, kind: e.target.value })}>
              <option value="vpn">Túnel VPN</option>
              <option value="diagnostico">Diagnóstico</option>
              <option value="portal">Portal</option>
            </select>
          </div>
          <input className="cv-input mt-2" placeholder="Notas" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
          <div className="flex gap-2 mt-3">
            <button onClick={save} className="btn-gold flex-1 rounded-xl py-2 text-sm cursor-pointer">Guardar (admin)</button>
            <button onClick={() => setShowForm(false)} className="btn-ghost rounded-xl px-4 text-sm cursor-pointer">Cancelar</button>
          </div>
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-3">
        {filtered.length === 0 && <p className="text-xs opacity-60 col-span-2 text-center py-6">Sem servidores nesta região.</p>}
        {filtered.map((s) => (
          <div key={s.id} className={`cv-card p-3.5 ${activeServer?.id === s.id ? "ring-2 ring-amber-400/70" : ""}`}>
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <p className="font-bold text-sm flex items-center gap-1.5">
                  {s.online ? <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" /> : <XCircle className="w-4 h-4 text-red-400 shrink-0" />}
                  <span className="truncate">{s.name}</span>
                </p>
                <p className="text-[11px] font-mono opacity-75 mt-0.5">{s.address}:{s.port}</p>
                <div className="flex flex-wrap gap-1 mt-1.5">
                  <span className="badge bg-white/10 border border-white/15">{s.region}</span>
                  <span className="badge bg-white/10 border border-white/15">{s.protocol}</span>
                  <span className="badge bg-white/10 border border-white/15">{s.operator}</span>
                  <span className="badge bg-white/10 border border-white/15">{s.kind}</span>
                </div>
              </div>
              <div className="text-right shrink-0">
                <p className={`text-lg font-extrabold ${s.lastPingMs !== null && s.lastPingMs < 150 ? "text-emerald-300" : s.lastPingMs !== null && s.lastPingMs < 400 ? "text-amber-300" : "text-red-300"}`}>
                  {s.lastPingMs !== null ? `${s.lastPingMs}ms` : "—"}
                </p>
                <p className="text-[10px] opacity-60">{s.online ? "ONLINE" : "OFFLINE"}</p>
                <SignalBars ping={s.lastPingMs} online={s.online} />
              </div>
            </div>
            <p className="text-[10px] opacity-60 mt-1.5">
              {s.country} · Última verificação: {fmtDateTime(s.lastCheck)} {s.loadPercent !== null ? `· Carga: ${s.loadPercent}%` : "· Carga: n/d"}
            </p>
            {s.notes && <p className="text-[11px] opacity-70 italic mt-1">{s.notes}</p>}
            <div className="flex gap-1.5 mt-2.5">
              <button onClick={() => { setActiveServer(s); notify(`Servidor activo: ${s.name}`, "ok"); }} className={`flex-1 rounded-lg py-1.5 text-xs font-bold cursor-pointer flex items-center justify-center gap-1 ${activeServer?.id === s.id ? "btn-gold" : "btn-blue"}`}>
                <Power className="w-3.5 h-3.5" /> {activeServer?.id === s.id ? "Activo" : "Usar"}
              </button>
              <button onClick={() => check(s.id)} disabled={checking === s.id} className="btn-ghost rounded-lg px-3 text-xs disabled:opacity-50 cursor-pointer" title="Verificar agora">
                <RefreshCw className={`w-3.5 h-3.5 ${checking === s.id ? "animate-spin" : ""}`} />
              </button>
              <button onClick={() => openEdit(s)} className="btn-ghost rounded-lg px-3 text-xs cursor-pointer" title="Editar (admin)">
                <Pencil className="w-3.5 h-3.5" />
              </button>
              <button onClick={() => remove(s.id)} className="btn-ghost rounded-lg px-3 text-xs text-red-300 cursor-pointer" title="Remover (admin)">
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function SignalBars({ ping, online }: { ping: number | null; online: boolean }) {
  const level = !online || ping === null ? 0 : ping < 100 ? 4 : ping < 200 ? 3 : ping < 400 ? 2 : 1;
  return (
    <span className="inline-flex items-end gap-0.5 mt-1">
      {[1, 2, 3, 4].map((i) => (
        <span key={i} className={`w-1 rounded-sm ${i <= level ? "bg-emerald-400" : "bg-white/15"}`} style={{ height: `${4 + i * 3}px` }} />
      ))}
    </span>
  );
}
