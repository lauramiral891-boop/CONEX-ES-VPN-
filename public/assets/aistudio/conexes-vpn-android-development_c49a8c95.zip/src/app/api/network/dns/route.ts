import { resolveDns, sanitizeDomain, isValidDomainOrIp } from "@/lib/network";
import { writeLog, touchDaily } from "@/lib/server-log";
import { db } from "@/db";
import { networkTests } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const raw = url.searchParams.get("domain") || "";
  const operator = (url.searchParams.get("operator") || "GERAL").toUpperCase();
  return runDns(raw, operator);
}

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { domain?: string; operator?: string };
    return runDns(body.domain || "", (body.operator || "GERAL").toUpperCase());
  } catch {
    return Response.json({ ok: false, error: "Corpo inválido" }, { status: 400 });
  }
}

async function runDns(raw: string, operator: string) {
  const domain = sanitizeDomain(raw);
  if (!domain || !isValidDomainOrIp(domain)) {
    return Response.json(
      { ok: false, error: "Domínio/IP inválido" },
      { status: 400 }
    );
  }
  await writeLog("dns", "info", `Pesquisa DNS iniciada: ${domain} [${operator}]`);
  const r = await resolveDns(domain);
  try {
    await db.insert(networkTests).values({
      operator,
      testType: "dns",
      target: domain,
      success: r.ok,
      latencyMs: r.ms,
      details: JSON.stringify(r).slice(0, 2000),
    });
  } catch {}
  await touchDaily({ tests: 1 });
  await writeLog(
    "dns",
    r.ok ? "success" : "error",
    r.ok
      ? `DNS resolvido: ${domain} → ${r.ips.join(", ")} (${r.ms}ms)`
      : `DNS falhou: ${domain} — ${r.error}`,
    JSON.stringify(r).slice(0, 2000)
  );
  return Response.json({ ...r, domain, operator, measuredAt: new Date().toISOString() });
}
