import { db } from "@/db";
import { adminUsers, servers, featureStatus, satProfiles } from "@/db/schema";
import { sql } from "drizzle-orm";
import { hashPassword } from "@/lib/crypto";
import { writeLog } from "@/lib/server-log";

export const dynamic = "force-dynamic";

// Inicializa dados base: admin, servidores de diagnóstico REAIS, funcionalidades e exemplo satélite.
// Só executa inserções em falta — seguro chamar várias vezes.
export async function POST() {
  const seeded: string[] = [];
  try {
    const [adminCount] = await db.select({ c: sql<number>`count(*)` }).from(adminUsers);
    if (Number(adminCount?.c ?? 0) === 0) {
      await db.insert(adminUsers).values({
        username: "admin",
        passwordHash: hashPassword("admin123"),
        role: "admin",
      });
      seeded.push("admin (utilizador: admin / palavra-passe: admin123 — altere após entrar)");
    }

    const [srvCount] = await db.select({ c: sql<number>`count(*)` }).from(servers);
    if (Number(srvCount?.c ?? 0) === 0) {
      const base = [
        { name: "Unitel — Portal Oficial", country: "Angola", region: "Angola", address: "unitel.ao", port: 443, protocol: "SSL/TLS", operator: "UNITEL", kind: "portal", notes: "Endpoint real de diagnóstico. Não é um túnel VPN." },
        { name: "Africell — Portal Oficial", country: "Angola", region: "Angola", address: "africell.ao", port: 443, protocol: "SSL/TLS", operator: "AFRICELL", kind: "portal", notes: "Endpoint real de diagnóstico. Não é um túnel VPN." },
        { name: "Gov.ao — Portal do Governo", country: "Angola", region: "Angola", address: "www.gov.ao", port: 443, protocol: "SSL/TLS", operator: "GERAL", kind: "diagnostico", notes: "Referência nacional para latência." },
        { name: "Cloudflare DNS", country: "Global", region: "Global", address: "1.1.1.1", port: 443, protocol: "SSL/TLS", operator: "GERAL", kind: "diagnostico", notes: "DNS público — referência de latência global." },
        { name: "Google DNS", country: "EUA", region: "America", address: "8.8.8.8", port: 53, protocol: "DNS", operator: "GERAL", kind: "diagnostico", notes: "DNS público — referência." },
        { name: "Cloudflare — Europa", country: "Alemanha", region: "Europa", address: "www.cloudflare.com", port: 443, protocol: "SSL/TLS", operator: "GERAL", kind: "diagnostico", notes: "Referência Europa." },
        { name: "Google — América", country: "EUA", region: "America", address: "www.google.com", port: 443, protocol: "SSL/TLS", operator: "GERAL", kind: "diagnostico", notes: "Referência América." },
        { name: "Google — Ásia", country: "Singapura", region: "Asia", address: "www.google.com.sg", port: 443, protocol: "SSL/TLS", operator: "GERAL", kind: "diagnostico", notes: "Referência Ásia." },
        { name: "Ubuntu — África do Sul (CDN)", country: "África do Sul", region: "Africa", address: "za.archive.ubuntu.com", port: 80, protocol: "HTTP", operator: "GERAL", kind: "diagnostico", notes: "Referência África Austral." },
      ];
      for (const s of base) {
        await db.insert(servers).values(s).catch(() => {});
      }
      seeded.push(`${base.length} servidores de diagnóstico reais`);
    }

    const [featCount] = await db.select({ c: sql<number>`count(*)` }).from(featureStatus);
    if (Number(featCount?.c ?? 0) === 0) {
      const feats: { feature: string; status: string; description: string }[] = [
        { feature: "Painel principal + sessão de monitorização", status: "IMPLEMENTADO", description: "Ligar/desligar sessão, temporizador, IP público, ping TCP, consumo medido." },
        { feature: "Diagnóstico Unitel (DNS/TCP/TLS/latência)", status: "IMPLEMENTADO", description: "Testes reais contra portais e DNS públicos." },
        { feature: "Diagnóstico Africell (DNS/TCP/TLS/latência)", status: "IMPLEMENTADO", description: "Testes reais contra portais e DNS públicos." },
        { feature: "SNI Scanner manual", status: "IMPLEMENTADO", description: "DNS → TCP → TLS/SNI → classificação rigorosa." },
        { feature: "SNI Auto Finder (Auto Scan)", status: "IMPLEMENTADO", description: "Candidatos autorizados + pipeline automático." },
        { feature: "SNI Auto Finder (Deep Scan)", status: "IMPLEMENTADO", description: "Portas alargadas e timeouts maiores." },
        { feature: "SNI Auto Finder (Live Monitor)", status: "IMPLEMENTADO", description: "Reverificação periódica no navegador." },
        { feature: "Gestão de servidores + verificação online", status: "IMPLEMENTADO", description: "CRUD admin + medição TCP real + ordenação por ping." },
        { feature: "Perfis VPN (WireGuard/OpenVPN/SSH/SSL/V2Ray)", status: "EM_TESTE", description: "Configurações guardadas e exportáveis. Ligação real ao túnel requer app Android." },
        { feature: "Importar/exportar configurações", status: "IMPLEMENTADO", description: "JSON .cvpn.json sem expor palavras-passe." },
        { feature: "Estatísticas reais", status: "IMPLEMENTADO", description: "Sessões, tráfego medido, testes, histórico diário." },
        { feature: "Teste de velocidade", status: "IMPLEMENTADO", description: "Download/upload medidos com payload real." },
        { feature: "Logs completos", status: "IMPLEMENTADO", description: "Todos os eventos com data/hora, filtros e exportação." },
        { feature: "Administração", status: "IMPLEMENTADO", description: "Login com hash, gestão de servidores, relatórios de erro." },
        { feature: "Perfil ANGOSAT-2", status: "EM_TESTE", description: "Configuração de terminal/gateway + teste. Requer equipamento e serviço autorizado." },
        { feature: "Túnel VPN no sistema (Web)", status: "INDISPONIVEL", description: "Navegadores não permitem VPNService. Disponível apenas na app Android nativa." },
        { feature: "App Android (Kotlin + VPNService + APK)", status: "INDISPONIVEL", description: "Fora do âmbito desta plataforma Web. Backend e API prontos para integrar." },
        { feature: "Zero-rating / 'internet grátis'", status: "INDISPONIVEL", description: "Nunca prometido. Exigiria acordo e teste autorizado da operadora." },
      ];
      for (const f of feats) {
        await db.insert(featureStatus).values(f).catch(() => {});
      }
      seeded.push(`${feats.length} estados de funcionalidade`);
    }

    const [satCount] = await db.select({ c: sql<number>`count(*)` }).from(satProfiles);
    if (Number(satCount?.c ?? 0) === 0) {
      await db.insert(satProfiles).values({
        name: "Terminal ANGOSAT-2 (exemplo — configurar)",
        endpointIp: "192.0.2.1",
        gateway: "192.0.2.254",
        dnsPrimary: "1.1.1.1",
        dnsSecondary: "8.8.8.8",
        notes: "EXEMPLO: substitua pelo IP real do terminal/modem fornecido pelo operador. 192.0.2.1 é documentação (RFC 5737) e ficará INALCANCAVEL até configurar.",
        lastStatus: "NUNCA_TESTADO",
      }).catch(() => {});
      seeded.push("perfil satélite de exemplo (por configurar)");
    }

    await writeLog("admin", "success", `Seed executado: ${seeded.length > 0 ? seeded.join(" · ") : "nada em falta"}`);
    return Response.json({ ok: true, seeded });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}

export async function GET() {
  const [a] = await db.select({ c: sql<number>`count(*)` }).from(adminUsers);
  const [s] = await db.select({ c: sql<number>`count(*)` }).from(servers);
  const [f] = await db.select({ c: sql<number>`count(*)` }).from(featureStatus);
  return Response.json({
    ok: true,
    needsSeed: Number(a?.c ?? 0) === 0 || Number(s?.c ?? 0) === 0 || Number(f?.c ?? 0) === 0,
    counts: { admins: Number(a?.c ?? 0), servers: Number(s?.c ?? 0), features: Number(f?.c ?? 0) },
  });
}
