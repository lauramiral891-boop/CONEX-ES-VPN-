import { db } from "@/db";
import { adminUsers } from "@/db/schema";
import { eq } from "drizzle-orm";
import { verifyPassword } from "@/lib/crypto";
import { writeLog } from "@/lib/server-log";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { username?: string; password?: string };
    const username = String(body.username || "").trim();
    const password = String(body.password || "");
    if (!username || !password) {
      return Response.json({ ok: false, error: "Credenciais obrigatórias" }, { status: 400 });
    }
    const rows = await db.select().from(adminUsers).where(eq(adminUsers.username, username)).limit(1);
    if (rows.length === 0) {
      await writeLog("admin", "warn", `Tentativa de login falhada: ${username} (utilizador inexistente)`);
      return Response.json({ ok: false, error: "Credenciais inválidas" }, { status: 401 });
    }
    const valid = verifyPassword(password, rows[0].passwordHash);
    if (!valid) {
      await writeLog("admin", "warn", `Tentativa de login falhada: ${username} (palavra-passe errada)`);
      return Response.json({ ok: false, error: "Credenciais inválidas" }, { status: 401 });
    }
    const token = Buffer.from(`${username}:${password}`).toString("base64");
    await writeLog("admin", "success", `Login administrativo: ${username}`);
    return Response.json({ ok: true, username, role: rows[0].role, token });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}
