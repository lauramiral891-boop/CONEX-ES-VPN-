import { db } from "@/db";
import { sniResults } from "@/db/schema";
import { desc, eq, and } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const operator = url.searchParams.get("operator")?.toUpperCase() || "";
  const status = url.searchParams.get("status")?.toUpperCase() || "";
  const limit = Math.min(Number(url.searchParams.get("limit") || 100), 300);
  try {
    const conds = [];
    if (operator && operator !== "TODOS") conds.push(eq(sniResults.operator, operator));
    if (status && status !== "TODOS") conds.push(eq(sniResults.status, status));
    const rows =
      conds.length > 0
        ? await db.select().from(sniResults).where(and(...conds)).orderBy(desc(sniResults.createdAt)).limit(limit)
        : await db.select().from(sniResults).orderBy(desc(sniResults.createdAt)).limit(limit);
    return Response.json({ ok: true, total: rows.length, results: rows });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  const url = new URL(req.url);
  const before = url.searchParams.get("before"); // ISO date — limpa anteriores
  try {
    if (before) {
      const cutoff = new Date(before);
      if (isNaN(cutoff.getTime())) {
        return Response.json({ ok: false, error: "Data inválida" }, { status: 400 });
      }
      const { lt } = await import("drizzle-orm");
      const deleted = await db.delete(sniResults).where(lt(sniResults.createdAt, cutoff)).returning({ id: sniResults.id });
      return Response.json({ ok: true, deleted: deleted.length });
    }
    const deleted = await db.delete(sniResults).returning({ id: sniResults.id });
    return Response.json({ ok: true, deleted: deleted.length });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}
