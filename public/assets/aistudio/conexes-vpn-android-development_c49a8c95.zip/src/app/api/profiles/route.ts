import { db } from "@/db";
import { vpnProfiles } from "@/db/schema";
import { desc } from "drizzle-orm";
import { encryptSecret } from "@/lib/crypto";
import { writeLog } from "@/lib/server-log";
import { sanitizeDomain, isValidDomainOrIp } from "@/lib/network";

export const dynamic = "force-dynamic";

const PROTOCOLS = ["WireGuard", "OpenVPN", "SSH Tunnel", "SSL/TLS", "V2Ray"];

export async function GET() {
  try {
    const rows = await db.select().from(vpnProfiles).orderBy(desc(vpnProfiles.updatedAt));
    // Nunca devolver palavra-passe: apenas indicar se existe
    const safe = rows.map((r) => ({ ...r, passwordEnc: undefined, hasPassword: !!r.passwordEnc }));
    return Response.json({ ok: true, profiles: safe, protocols: PROTOCOLS });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as Record<string, unknown>;
    const name = String(body["name"] || "").trim();
    const host = sanitizeDomain(String(body["host"] || ""));
    const port = Number(body["port"]) || 443;
    const protocol = String(body["protocol"] || "SSL/TLS");
    if (!name) return Response.json({ ok: false, error: "Nome do perfil é obrigatório" }, { status: 400 });
    if (!host || !isValidDomainOrIp(host)) return Response.json({ ok: false, error: "Anfitrião inválido" }, { status: 400 });
    if (!PROTOCOLS.includes(protocol)) return Response.json({ ok: false, error: "Protocolo inválido" }, { status: 400 });
    if (!Number.isInteger(port) || port <= 0 || port > 65535) return Response.json({ ok: false, error: "Porta inválida" }, { status: 400 });

    const inserted = await db.insert(vpnProfiles).values({
      name: name.slice(0, 120),
      serverId: body["serverId"] ? Number(body["serverId"]) : null,
      protocol,
      host,
      port,
      sni: body["sni"] ? sanitizeDomain(String(body["sni"])).slice(0, 253) : null,
      method: String(body["method"] || "AES-256-GCM").slice(0, 60),
      payload: String(body["payload"] || "auto").slice(0, 200),
      username: body["username"] ? String(body["username"]).slice(0, 200) : null,
      passwordEnc: body["password"] ? encryptSecret(String(body["password"]).slice(0, 500)) : null,
      autoReconnect: body["autoReconnect"] !== false,
      dnsProtection: body["dnsProtection"] !== false,
      dnsChoice: String(body["dnsChoice"] || "1.1.1.1, 8.8.8.8").slice(0, 200),
      extraConfig: body["extraConfig"] ? String(body["extraConfig"]).slice(0, 8000) : null,
    }).returning({ id: vpnProfiles.id });

    await writeLog("perfil", "success", `Perfil VPN guardado: ${name} (${protocol} ${host}:${port})`);
    return Response.json({ ok: true, id: inserted[0].id });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}
