import { writeLog } from "@/lib/server-log";

export const dynamic = "force-dynamic";

async function fetchWithTimeout(url: string, ms: number): Promise<Response> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  try {
    return await fetch(url, { signal: ctrl.signal, cache: "no-store" });
  } finally {
    clearTimeout(t);
  }
}

export async function GET(req: Request) {
  const fwd = req.headers.get("x-forwarded-for") || "";
  const real = req.headers.get("x-real-ip") || "";
  const clientIp =
    fwd.split(",")[0].trim() || real.trim() || "indisponível";

  let publicIp: string | null = null;
  let geo: Record<string, unknown> | null = null;
  const errors: string[] = [];

  // 1) ipify — IP público visto pelo servidor
  try {
    const r = await fetchWithTimeout("https://api.ipify.org?format=json", 7000);
    if (r.ok) {
      const j = (await r.json()) as { ip?: string };
      if (j.ip) publicIp = j.ip;
    } else {
      errors.push(`ipify HTTP ${r.status}`);
    }
  } catch (e) {
    errors.push(`ipify: ${e instanceof Error ? e.message : "falha"}`);
  }

  // 2) geolocalização aproximada (ip-api, sem chave)
  const lookupIp = publicIp && publicIp !== "indisponível" ? publicIp : "";
  if (lookupIp) {
    try {
      const r = await fetchWithTimeout(
        `http://ip-api.com/json/${encodeURIComponent(
          lookupIp
        )}?fields=status,country,city,isp,org,as,query,lat,lon`,
        7000
      );
      if (r.ok) {
        const j = (await r.json()) as Record<string, unknown>;
        if (j["status"] === "success") geo = j;
        else errors.push("geo: lookup sem sucesso");
      } else {
        errors.push(`geo HTTP ${r.status}`);
      }
    } catch (e) {
      errors.push(`geo: ${e instanceof Error ? e.message : "falha"}`);
    }
  }

  await writeLog(
    "rede",
    publicIp ? "success" : "warn",
    publicIp
      ? `IP público detectado: ${publicIp}`
      : "IP público indisponível",
    JSON.stringify({ clientIp, publicIp, geo, errors }).slice(0, 2000)
  );

  return Response.json({
    ok: !!publicIp,
    clientIp,
    publicIp,
    geo,
    errors,
    measuredAt: new Date().toISOString(),
    note: "IP obtido por consulta real externa (ipify/ip-api). Sem simulação.",
  });
}
