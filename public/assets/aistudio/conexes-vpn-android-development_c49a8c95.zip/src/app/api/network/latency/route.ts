import { measureLatency, sanitizeDomain, isValidDomainOrIp } from "@/lib/network";
import { writeLog, touchDaily } from "@/lib/server-log";
import { db } from "@/db";
import { networkTests } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as {
      host?: string;
      port?: number;
      samples?: number;
      operator?: string;
    };
    const host = sanitizeDomain(body.host || "");
    const port = Number(body.port) || 443;
    const samples = Math.min(Math.max(Number(body.samples) || 4, 1), 10);
    const operator = (body.operator || "GERAL").toUpperCase();
    if (!host || !isValidDomainOrIp(host)) {
      return Response.json({ ok: false, error: "Anfitrião inválido" }, { status: 400 });
    }
    await writeLog("latencia", "info", `Medição de latência: ${host}:${port} x${samples} [${operator}]`);
    const r = await measureLatency(host, port, samples, 4000);
    try {
      await db.insert(networkTests).values({
        operator,
        testType: "latencia",
        target: `${host}:${port}`,
        success: r.ok,
        latencyMs: r.avg,
        details: JSON.stringify(r).slice(0, 2000),
      });
    } catch {}
    await touchDaily({ tests: 1 });
    await writeLog(
      "latencia",
      r.ok ? "success" : "error",
      r.ok
        ? `Latência ${host}:${port} — média ${r.avg}ms (min ${r.min}, max ${r.max}, perda ${r.loss}%)`
        : `Latência ${host}:${port} — sem resposta`,
      JSON.stringify(r).slice(0, 2000)
    );
    return Response.json({
      ...r,
      host,
      port,
      operator,
      method: "TCP connect (ICMP indisponível em ambiente Web — medição TCP real, sem simulação).",
      measuredAt: new Date().toISOString(),
    });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}
