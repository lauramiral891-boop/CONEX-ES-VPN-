import { db } from "@/db";
import { connectionSessions, sniResults, servers, networkTests, appLogs, dailyStats } from "@/db/schema";
import { sql, desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const [sessCount] = await db.select({ c: sql<number>`count(*)` }).from(connectionSessions);
    const [sniCount] = await db.select({ c: sql<number>`count(*)` }).from(sniResults);
    const [srvCount] = await db.select({ c: sql<number>`count(*)` }).from(servers);
    const [srvOnline] = await db.select({ c: sql<number>`count(*)` }).from(servers).where(eq(servers.online, true));
    const [testCount] = await db.select({ c: sql<number>`count(*)` }).from(networkTests);
    const [errCount] = await db.select({ c: sql<number>`count(*)` }).from(appLogs).where(eq(appLogs.level, "error"));
    const traffic = await db.select({
      up: sql<number>`coalesce(sum(bytes_up),0)`,
      down: sql<number>`coalesce(sum(bytes_down),0)`,
      dur: sql<number>`coalesce(sum(duration_sec),0)`,
    }).from(connectionSessions);
    const days = await db.select().from(dailyStats).orderBy(desc(dailyStats.day)).limit(31);
    const recentSessions = await db.select().from(connectionSessions).orderBy(desc(connectionSessions.startedAt)).limit(10);

    return Response.json({
      ok: true,
      totals: {
        sessions: Number(sessCount?.c ?? 0),
        sniTests: Number(sniCount?.c ?? 0),
        servers: Number(srvCount?.c ?? 0),
        serversOnline: Number(srvOnline?.c ?? 0),
        networkTests: Number(testCount?.c ?? 0),
        errors: Number(errCount?.c ?? 0),
        bytesUp: Number(traffic[0]?.up ?? 0),
        bytesDown: Number(traffic[0]?.down ?? 0),
        durationSec: Number(traffic[0]?.dur ?? 0),
      },
      daily: days.reverse(),
      recentSessions,
      note: "Todos os valores derivam de medições e sessões reais. Contadores a zero significam sem actividade — nunca simulamos.",
    });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}
