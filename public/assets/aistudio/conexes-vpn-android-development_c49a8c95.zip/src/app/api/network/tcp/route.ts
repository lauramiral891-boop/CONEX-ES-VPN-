import { testTcp, sanitizeDomain, isValidDomainOrIp } from "@/lib/network";
import { writeLog, touchDaily } from "@/lib/server-log";
import { db } from "@/db";
import { networkTests } from "@/db/schema";

export const dynamic = "force-dynamic";

const ALLOWED_PORTS = [22, 53, 80, 443, 465, 587, 993, 995, 1194, 1723, 2083, 2087, 2222, 3306, 3389, 5432, 5900, 6379, 8000, 8080, 8443, 9000, 9443, 1197, 51820];

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as {
      host?: string;
      ports?: number[];
      operator?: string;
    };
    const host = sanitizeDomain(body.host || "");
    const operator = (body.operator || "GERAL").toUpperCase();
    let ports = Array.isArray(body.ports) ? body.ports : [443];
    ports = [...new Set(ports.map((p) => Number(p)).filter((p) => Number.isInteger(p) && p > 0 && p <= 65535))].slice(0, 12);
    if (!host || !isValidDomainOrIp(host)) {
      return Response.json({ ok: false, error: "Anfitrião inválido" }, { status: 400 });
    }
    if (ports.length === 0) {
      return Response.json({ ok: false, error: "Sem portas válidas" }, { status: 400 });
    }
    const notAllowed = ports.filter((p) => !ALLOWED_PORTS.includes(p));
    await writeLog("tcp", "info", `Teste TCP: ${host} portas [${ports.join(", ")}] [${operator}]`);

    const results: Record<string, { ok: boolean; ms: number | null; error: string | null; allowed: boolean }> = {};
    for (const port of ports) {
      const r = await testTcp(host, port, 5000);
      results[String(port)] = { ...r, allowed: ALLOWED_PORTS.includes(port) };
      try {
        await db.insert(networkTests).values({
          operator,
          testType: "tcp",
          target: `${host}:${port}`,
          success: r.ok,
          latencyMs: r.ms,
          details: JSON.stringify(r).slice(0, 1000),
        });
      } catch {}
    }
    await touchDaily({ tests: ports.length });
    const accessible = Object.entries(results).filter(([, v]) => v.ok).map(([k]) => k);
    await writeLog(
      "tcp",
      accessible.length > 0 ? "success" : "error",
      accessible.length > 0
        ? `TCP ${host}: acessível em ${accessible.join(", ")}`
        : `TCP ${host}: nenhuma porta acessível (${ports.join(", ")})`,
      JSON.stringify(results).slice(0, 2000)
    );
    return Response.json({
      ok: true,
      host,
      operator,
      results,
      accessiblePorts: accessible,
      allowedPorts: ALLOWED_PORTS,
      notAllowedRequested: notAllowed,
      measuredAt: new Date().toISOString(),
      note: "Apenas portas da lista autorizada são recomendadas. Outras são testadas mas sinalizadas.",
    });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}
