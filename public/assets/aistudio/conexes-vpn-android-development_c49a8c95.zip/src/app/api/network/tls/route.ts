import { testTls, sanitizeDomain, isValidDomainOrIp } from "@/lib/network";
import { writeLog, touchDaily } from "@/lib/server-log";
import { db } from "@/db";
import { networkTests } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as {
      host?: string;
      port?: number;
      sni?: string;
      operator?: string;
    };
    const host = sanitizeDomain(body.host || "");
    const sni = sanitizeDomain(body.sni || body.host || "");
    const port = Number(body.port) || 443;
    const operator = (body.operator || "GERAL").toUpperCase();
    if (!host || !isValidDomainOrIp(host) || !sni || !isValidDomainOrIp(sni)) {
      return Response.json({ ok: false, error: "Anfitrião/SNI inválido" }, { status: 400 });
    }
    if (!Number.isInteger(port) || port <= 0 || port > 65535) {
      return Response.json({ ok: false, error: "Porta inválida" }, { status: 400 });
    }
    await writeLog("tls", "info", `Negociação TLS: ${host}:${port} SNI=${sni} [${operator}]`);
    const r = await testTls(host, port, sni, 8000);
    try {
      await db.insert(networkTests).values({
        operator,
        testType: "tls",
        target: `${host}:${port} sni=${sni}`,
        success: r.ok,
        latencyMs: r.ms,
        details: JSON.stringify(r).slice(0, 2000),
      });
    } catch {}
    await touchDaily({ tests: 1 });
    await writeLog(
      "tls",
      r.ok ? "success" : "error",
      r.ok
        ? `TLS concluído: ${sni} (${r.protocol ?? "proto?"}, ${r.ms}ms, cert ${r.certValid ? "válido" : "não-validado"})`
        : `TLS falhou: ${sni} — ${r.error}`,
      JSON.stringify(r).slice(0, 2000)
    );
    return Response.json({
      ...r,
      host,
      port,
      sni,
      operator,
      measuredAt: new Date().toISOString(),
      honesty: "TLS concluído + cert válido NÃO significa SNI funcional para a operadora nem tráfego gratuito.",
    });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}
