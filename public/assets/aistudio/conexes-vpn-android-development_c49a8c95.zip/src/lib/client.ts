"use client";

export function adminHeaders(): Record<string, string> {
  try {
    const token = localStorage.getItem("cvpn_admin_token");
    if (token) return { Authorization: `Basic ${token}` };
  } catch {}
  return {};
}

export async function api<T = unknown>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(path, {
    ...init,
    headers: { "Content-Type": "application/json", ...(init?.headers || {}) },
    cache: "no-store",
  });
  const data = (await res.json().catch(() => ({}))) as T & { ok?: boolean; error?: string };
  if (!res.ok) {
    throw new Error((data as { error?: string }).error || `HTTP ${res.status}`);
  }
  return data;
}

export async function apiAdmin<T = unknown>(path: string, init?: RequestInit): Promise<T> {
  return api<T>(path, {
    ...init,
    headers: { ...adminHeaders(), ...((init?.headers as Record<string, string>) || {}) },
  });
}

export function fmtBytes(n: number | null | undefined): string {
  if (n === null || n === undefined || isNaN(n)) return "—";
  if (n === 0) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB"];
  let v = n;
  let u = 0;
  while (v >= 1024 && u < units.length - 1) {
    v /= 1024;
    u++;
  }
  return `${v >= 100 ? Math.round(v) : Math.round(v * 10) / 10} ${units[u]}`;
}

export function fmtDuration(sec: number | null | undefined): string {
  if (sec === null || sec === undefined) return "—";
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  const p = (x: number) => String(x).padStart(2, "0");
  return `${p(h)}:${p(m)}:${p(s)}`;
}

export function fmtDateTime(iso: string | Date | null | undefined): string {
  if (!iso) return "—";
  try {
    const d = new Date(iso);
    return d.toLocaleString("pt-AO", {
      day: "2-digit",
      month: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
  } catch {
    return String(iso);
  }
}

export function statusBadge(status: string): string {
  switch (status) {
    case "COMPATIVEL":
      return "bg-emerald-500/20 text-emerald-300 border border-emerald-400/40";
    case "PARCIAL":
      return "bg-amber-500/20 text-amber-300 border border-amber-400/40";
    case "FALHOU":
      return "bg-red-500/20 text-red-300 border border-red-400/40";
    case "IMPLEMENTADO":
      return "bg-emerald-500/20 text-emerald-300 border border-emerald-400/40";
    case "EM_TESTE":
      return "bg-amber-500/20 text-amber-300 border border-amber-400/40";
    case "INDISPONIVEL":
      return "bg-slate-500/20 text-slate-300 border border-slate-400/40";
    default:
      return "bg-sky-500/20 text-sky-300 border border-sky-400/40";
  }
}
