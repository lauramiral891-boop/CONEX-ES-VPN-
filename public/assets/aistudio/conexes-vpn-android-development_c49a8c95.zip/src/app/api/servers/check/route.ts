import { db } from "@/db";
import { servers } from "@/db/schema";
import { eq } from "drizzle-orm";
import { measureLatency } from "@/lib/network";
import { writeLog, touchDaily, jsonDetails } from "@/lib/server-log";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { id?: number };
    const id = Number(body.id);
    if (!Number.isInteger(id)) return Response.json({ ok: false, error: "ID inválido" }, { status: 400 });
    const rows = await db.select().from(servers).where(eq(servers.id, id)).limit(1);
    if (rows.length === 0) return Response.json({ ok: false, error: "Servidor não encontrado" }, { status: 404 });
    const srv = rows[0];
    await writeLog("servidor", "info", `Verificação: ${srv.name} (${srv.address}:${srv.port})`);
    const r = await measureLatency(srv.address, srv.port, 4, 4000);
    const online = r.ok && (r.avg ?? 99999) < 10000;
    const updated = await db
      .update(servers)
      .set({ online, lastPingMs: r.avg, lastCheck: new Date(), updatedAt: new Date() })
      .where(eq(servers.id, id))
      .returning();
    await touchDaily({ tests: 1 });
    await writeLog(
      "servidor",
      online ? "success" : "error",
      online
        ? `${srv.name}: ONLINE — ${r.avg}ms (perda ${r.loss}%)`
        : `${srv.name}: OFFLINE — sem resposta TCP`,
      jsonDetails(r)
    );
    return Response.json({ ok: true, server: updated[0], measurement: r, measuredAt: new Date().toISOString() });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}
