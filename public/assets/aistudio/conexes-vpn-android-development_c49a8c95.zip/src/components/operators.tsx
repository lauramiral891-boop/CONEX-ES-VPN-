"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Building2, Dna, Plug, Lock, Gauge, Play, Satellite, Trash2, Plus,
  AlertTriangle, CheckCircle2, XCircle, Clock, Save, RefreshCw,
} from "lucide-react";
import { api, apiAdmin, fmtDateTime } from "@/lib/client";

type DiagReport = {
  operator: string;
  dns?: { target: string; ok: boolean; ips: string[]; ms: number | null; error: string | null }[];
  tcp?: { host: string; port: number; ok: boolean; ms: number | null; error: string | null }[];
  tls?: { host: string; port: number; sni: string; ok: boolean; ms: number | null; certValid: boolean; protocol: string | null; error: string | null }[];
  latencia?: { host: string; port: number; ok: boolean; min: number | null; avg: number | null; max: number | null; loss: number }[];
  verdict?: string;
  summary?: { portaisAlcancaveis: number; latenciaMediaMs: number | null; perdaMaximaPct: number | null };
};

type SatProfile = {
  id: number; name: string; endpointIp: string; gateway: string | null;
  dnsPrimary: string; dnsSecondary: string; username: string | null;
  hasPassword: boolean; notes: string | null; lastStatus: string;
  lastLatencyMs: number | null; lastCheck: string | null;
};

export function OperatorsPanel(props: { notify: (m: string, k?: "ok" | "err" | "info") => void }) {
  const { notify } = props;
  const [reports, setReports] = useState<Record<string, DiagReport | null>>({ UNITEL: null, AFRICELL: null });
  const [loading, setLoading] = useState<Record<string, boolean>>({ UNITEL: false, AFRICELL: false });
  const [suites, setSuites] = useState<Record<string, string[]>>({
    UNITEL: ["dns", "tcp", "tls", "latencia"],
    AFRICELL: ["dns", "tcp", "tls", "latencia"],
  });

  const runDiag = useCallback(async (op: string) => {
    setLoading((s) => ({ ...s, [op]: true }));
    try {
      const d = (await api("/api/operators/test", {
        method: "POST",
        body: JSON.stringify({ operator: op, suite: suites[op] }),
      })) as DiagReport;
      setReports((r) => ({ ...r, [op]: d }));
      notify(`Diagnóstico ${op} concluído: ${d.verdict}`, d.verdict === "INALCANCAVEL" ? "err" : "ok");
    } catch (e) {
      notify(e instanceof Error ? e.message : "Falha", "err");
    } finally {
      setLoading((s) => ({ ...s, [op]: false }));
    }
  }, [suites, notify]);

  const toggleSuite = (op: string, item: string) => {
    setSuites((s) => {
      const cur = s[op];
      return { ...s, [op]: cur.includes(item) ? cur.filter((x) => x !== item) : [...cur, item] };
    });
  };

  return (
    <div className="space-y-4">
      <div className="cv-card p-3 flex gap-3 items-start border-l-4" style={{ borderLeftColor: "#00c2ff" }}>
        <Building2 className="w-5 h-5 text-cyan-300 shrink-0 mt-0.5" />
        <p className="text-xs leading-relaxed opacity-90">
          Cada operadora tem <strong>painel independente</strong> com testes reais: DNS, portas TCP autorizadas,
          negociação TLS e latência. Os resultados são guardados e comparados abaixo. Isto <strong>não</strong> testa
          tarifação nem zero-rating.
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        {(["UNITEL", "AFRICELL"] as const).map((op) => {
          const accent = op === "UNITEL" ? "orange" : "purple";
          const rep = reports[op];
          return (
            <div key={op} className="cv-card p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className={`font-extrabold flex items-center gap-2 ${accent === "orange" ? "text-orange-300" : "text-purple-300"}`}>
                  <Building2 className="w-5 h-5" /> {op}
                </h3>
                {rep?.verdict && (
                  <span className={`badge ${rep.verdict === "INALCANCAVEL" ? "bg-red-500/20 text-red-300 border border-red-400/40" : rep.verdict.includes("ESTAVEL") ? "bg-emerald-500/20 text-emerald-300 border border-emerald-400/40" : "bg-amber-500/20 text-amber-300 border border-amber-400/40"}`}>
                    {rep.verdict.replaceAll("_", " ")}
                  </span>
                )}
              </div>

              <div className="flex flex-wrap gap-2 mb-3">
                {[
                  { k: "dns", label: "DNS", icon: <Dna className="w-3 h-3" /> },
                  { k: "tcp", label: "Portas TCP", icon: <Plug className="w-3 h-3" /> },
                  { k: "tls", label: "TLS", icon: <Lock className="w-3 h-3" /> },
                  { k: "latencia", label: "Latência", icon: <Gauge className="w-3 h-3" /> },
                ].map((t) => (
                  <label key={t.k} className={`text-[11px] font-bold px-2.5 py-1.5 rounded-lg border cursor-pointer flex items-center gap-1.5 ${suites[op].includes(t.k) ? "border-cyan-400/60 bg-cyan-500/15" : "border-white/10 opacity-60"}`}>
                    <input type="checkbox" className="hidden" checked={suites[op].includes(t.k)} onChange={() => toggleSuite(op, t.k)} />
                    {t.icon} {t.label}
                  </label>
                ))}
              </div>

              <button
                onClick={() => runDiag(op)}
                disabled={loading[op] || suites[op].length === 0}
                className={`w-full rounded-xl py-2.5 text-sm font-bold cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2 ${accent === "orange" ? "btn-gold" : "btn-purple"}`}
              >
                <Play className="w-4 h-4" /> {loading[op] ? "A diagnosticar…" : `Diagnosticar ${op}`}
              </button>

              {rep && (
                <div className="mt-3 space-y-2 text-xs max-h-72 overflow-y-auto scroll-thin pr-1">
                  {rep.dns?.map((d, i) => (
                    <TestLine key={`d${i}`} ok={d.ok} title={`DNS ${d.target}`} detail={d.ok ? `${d.ips.slice(0, 3).join(", ")} · ${d.ms}ms` : d.error ?? "falhou"} />
                  ))}
                  {rep.tcp?.map((t, i) => (
                    <TestLine key={`t${i}`} ok={t.ok} title={`TCP ${t.host}:${t.port}`} detail={t.ok ? `${t.ms}ms` : t.error ?? "falhou"} />
                  ))}
                  {rep.tls?.map((t, i) => (
                    <TestLine key={`l${i}`} ok={t.ok} title={`TLS ${t.sni}`} detail={t.ok ? `${t.protocol ?? "?"} · ${t.ms}ms · cert ${t.certValid ? "válido" : "não-validado"}` : t.error ?? "falhou"} />
                  ))}
                  {rep.latencia?.map((l, i) => (
                    <TestLine key={`p${i}`} ok={l.ok} title={`Latência ${l.host}`} detail={l.ok ? `média ${l.avg}ms · perda ${l.loss}%` : "sem resposta"} />
                  ))}
                  {rep.summary && (
                    <div className="rounded-lg bg-white/5 border border-white/10 p-2.5 font-semibold">
                      Portais alcançáveis: {rep.summary.portaisAlcancaveis} · Média: {rep.summary.latenciaMediaMs ?? "—"}ms · Perda máx: {rep.summary.perdaMaximaPct ?? "—"}%
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Comparação */}
      {reports.UNITEL && reports.AFRICELL && (
        <div className="cv-card p-4">
          <h3 className="font-extrabold text-sm mb-3">COMPARAÇÃO DE ESTABILIDADE E LATÊNCIA (MEDIÇÕES REAIS)</h3>
          <div className="grid sm:grid-cols-2 gap-3">
            <CompareCard name="UNITEL" rep={reports.UNITEL} color="text-orange-300" />
            <CompareCard name="AFRICELL" rep={reports.AFRICELL} color="text-purple-300" />
          </div>
          <p className="text-[11px] mt-2 opacity-70">
            Vencedor por latência: {winnerByLatency(reports.UNITEL, reports.AFRICELL)}. Comparação válida apenas para
            esta corrida de testes — volte a diagnosticar para confirmar.
          </p>
        </div>
      )}
    </div>
  );
}

function winnerByLatency(a: DiagReport, b: DiagReport): string {
  const ma = a.summary?.latenciaMediaMs ?? 999999;
  const mb = b.summary?.latenciaMediaMs ?? 999999;
  if (ma === 999999 && mb === 999999) return "nenhum (sem dados)";
  if (ma === mb) return "empate";
  return ma < mb ? `UNITEL (${ma}ms)` : `AFRICELL (${mb}ms)`;
}

function CompareCard({ name, rep, color }: { name: string; rep: DiagReport; color: string }) {
  const avg = rep.summary?.latenciaMediaMs;
  const bar = avg !== null && avg !== undefined ? Math.min(100, (avg / 600) * 100) : 0;
  return (
    <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
      <p className={`font-extrabold text-sm ${color}`}>{name}</p>
      <div className="h-2.5 rounded-full bg-white/10 mt-2 overflow-hidden">
        <div className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-purple-500" style={{ width: `${Math.max(bar, 4)}%` }} />
      </div>
      <p className="text-xs mt-1.5 opacity-80">
        Média {avg ?? "—"}ms · Perda {rep.summary?.perdaMaximaPct ?? "—"}% · {rep.verdict?.replaceAll("_", " ")}
      </p>
    </div>
  );
}

function TestLine({ ok, title, detail }: { ok: boolean; title: string; detail: string }) {
  return (
    <div className={`rounded-lg border px-2.5 py-2 flex items-start gap-2 ${ok ? "border-emerald-400/25 bg-emerald-500/5" : "border-red-400/25 bg-red-500/5"}`}>
      {ok ? <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" /> : <XCircle className="w-4 h-4 text-red-400 shrink-0" />}
      <div className="min-w-0">
        <p className="font-bold">{title}</p>
        <p className="opacity-75 break-words">{detail}</p>
      </div>
    </div>
  );
}

// ---------------- SATÉLITE ----------------

export function SatellitePanel(props: { notify: (m: string, k?: "ok" | "err" | "info") => void }) {
  const { notify } = props;
  const [list, setList] = useState<SatProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [testing, setTesting] = useState<number | null>(null);
  const [testResult, setTestResult] = useState<Record<string, unknown> | null>(null);
  const [form, setForm] = useState({ name: "", endpointIp: "", gateway: "", dnsPrimary: "1.1.1.1", dnsSecondary: "8.8.8.8", username: "", password: "", notes: "" });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const d = (await api("/api/satellite")) as { profiles: SatProfile[] };
      setList(d.profiles);
    } catch {
      setList([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const save = async () => {
    if (!form.name.trim() || !form.endpointIp.trim()) {
      notify("Nome e IP do terminal são obrigatórios", "err");
      return;
    }
    try {
      await apiAdmin("/api/satellite", { method: "POST", body: JSON.stringify(form) });
      notify("Perfil ANGOSAT-2 guardado (requer login admin)", "ok");
      setForm({ name: "", endpointIp: "", gateway: "", dnsPrimary: "1.1.1.1", dnsSecondary: "8.8.8.8", username: "", password: "", notes: "" });
      load();
    } catch (e) {
      notify(e instanceof Error ? e.message : "Falha — faça login como admin", "err");
    }
  };

  const remove = async (id: number) => {
    if (!confirm("Remover este perfil de satélite?")) return;
    try {
      await apiAdmin(`/api/satellite/${id}`, { method: "DELETE" });
      notify("Perfil removido", "info");
      load();
    } catch (e) {
      notify(e instanceof Error ? e.message : "Falha", "err");
    }
  };

  const test = async (id: number) => {
    setTesting(id);
    setTestResult(null);
    try {
      const d = (await api("/api/satellite/test", { method: "POST", body: JSON.stringify({ id }) })) as unknown as Record<string, unknown>;
      setTestResult(d);
      notify(`Teste concluído: ${String((d as { status?: string }).status)}`, (d as { status?: string }).status === "ALCANCAVEL" ? "ok" : "err");
      load();
    } catch (e) {
      notify(e instanceof Error ? e.message : "Falha", "err");
    } finally {
      setTesting(null);
    }
  };

  return (
    <div className="space-y-4">
      <div className="cv-card p-4 border-l-4" style={{ borderLeftColor: "#f5c518" }}>
        <div className="flex gap-3 items-start">
          <Satellite className="w-6 h-6 text-amber-300 shrink-0" />
          <div className="text-xs leading-relaxed space-y-1.5 opacity-90">
            <p><strong className="text-amber-300">ANGOSAT-2 — integração honesta:</strong> este perfil configura o acesso ao seu <strong>terminal, modem ou gateway</strong> compatível (IP, gateway, DNS e credenciais do operador).</p>
            <p><strong>Não simulamos acesso ao satélite.</strong> Sem equipamento, serviço contratado e autorização, o estado será <strong>INALCANCAVEL</strong> — e é assim que deve ser apresentado.</p>
            <p>O encaminhamento VPN através desta ligação só é possível quando o teste indicar <strong>ALCANCAVEL</strong>.</p>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <div className="cv-card p-4">
          <h3 className="font-extrabold text-sm mb-3 flex items-center gap-2"><Plus className="w-4 h-4 text-amber-300" /> NOVO PERFIL DE SATÉLITE <span className="text-[10px] opacity-60 font-medium">(requer admin)</span></h3>
          <div className="space-y-2">
            <input className="cv-input" placeholder="Nome (ex.: Terminal Luanda — Teleporto)" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            <div className="grid grid-cols-2 gap-2">
              <input className="cv-input" placeholder="IP do terminal *" value={form.endpointIp} onChange={(e) => setForm({ ...form, endpointIp: e.target.value })} />
              <input className="cv-input" placeholder="Gateway" value={form.gateway} onChange={(e) => setForm({ ...form, gateway: e.target.value })} />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <input className="cv-input" placeholder="DNS primário" value={form.dnsPrimary} onChange={(e) => setForm({ ...form, dnsPrimary: e.target.value })} />
              <input className="cv-input" placeholder="DNS secundário" value={form.dnsSecondary} onChange={(e) => setForm({ ...form, dnsSecondary: e.target.value })} />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <input className="cv-input" placeholder="Utilizador (operador)" value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} />
              <input className="cv-input" type="password" placeholder="Palavra-passe (cifrada)" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
            </div>
            <textarea className="cv-input" rows={2} placeholder="Notas (modelo do terminal, plano contratado, contacto do operador…)" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
            <button onClick={save} className="btn-gold w-full rounded-xl py-2.5 text-sm flex items-center justify-center gap-2 cursor-pointer">
              <Save className="w-4 h-4" /> Guardar perfil
            </button>
          </div>
        </div>

        <div className="cv-card p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-extrabold text-sm flex items-center gap-2"><Satellite className="w-4 h-4 text-cyan-300" /> TERMINAIS CONFIGURADOS</h3>
            <button onClick={load} className="btn-ghost rounded-lg px-2.5 py-1.5 text-xs cursor-pointer"><RefreshCw className="w-3.5 h-3.5" /></button>
          </div>
          {loading ? (
            <p className="text-xs opacity-60">A carregar…</p>
          ) : list.length === 0 ? (
            <div className="rounded-xl border border-dashed border-white/15 p-4 text-center">
              <AlertTriangle className="w-6 h-6 mx-auto text-amber-300 mb-1" />
              <p className="text-xs font-bold">Nenhum terminal configurado</p>
              <p className="text-[11px] opacity-60 mt-1">Estado: INDISPONÍVEL até existir equipamento + serviço autorizado.</p>
            </div>
          ) : (
            <div className="space-y-2 max-h-96 overflow-y-auto scroll-thin pr-1">
              {list.map((p) => (
                <div key={p.id} className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="font-bold text-sm">{p.name}</p>
                      <p className="text-[11px] opacity-70">Terminal: {p.endpointIp} · GW: {p.gateway ?? "—"} · DNS: {p.dnsPrimary}</p>
                      <p className="text-[11px] opacity-70 flex items-center gap-1 mt-0.5">
                        <Clock className="w-3 h-3" /> {p.lastStatus} {p.lastLatencyMs !== null ? `· ${p.lastLatencyMs}ms` : ""} {p.lastCheck ? `· ${fmtDateTime(p.lastCheck)}` : ""}
                      </p>
                    </div>
                    <span className={`badge shrink-0 ${p.lastStatus === "ALCANCAVEL" ? "bg-emerald-500/20 text-emerald-300 border border-emerald-400/40" : p.lastStatus === "NUNCA_TESTADO" ? "bg-slate-500/20 text-slate-300 border border-slate-400/40" : "bg-red-500/20 text-red-300 border border-red-400/40"}`}>
                      {p.lastStatus.replaceAll("_", " ")}
                    </span>
                  </div>
                  {p.notes && <p className="text-[11px] mt-1.5 opacity-70 italic">{p.notes}</p>}
                  <div className="flex gap-2 mt-2">
                    <button onClick={() => test(p.id)} disabled={testing === p.id} className="btn-blue flex-1 rounded-lg py-1.5 text-xs disabled:opacity-50 cursor-pointer">
                      {testing === p.id ? "A testar…" : "Verificar disponibilidade"}
                    </button>
                    <button onClick={() => remove(p.id)} className="btn-ghost rounded-lg px-3 py-1.5 text-xs text-red-300 cursor-pointer">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {testResult && (
        <div className="cv-card p-4">
          <h3 className="font-extrabold text-sm mb-2">RESULTADO DO TESTE</h3>
          <pre className="log-line whitespace-pre-wrap break-words opacity-80 bg-black/30 rounded-xl p-3 border border-white/10">
            {JSON.stringify(testResult, null, 2)}
          </pre>
        </div>
      )}
    </div>
  );
}
