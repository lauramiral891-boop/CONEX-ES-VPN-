import { db } from "@/db";
import { satProfiles } from "@/db/schema";
import { desc } from "drizzle-orm";
import { requireAdmin } from "@/lib/admin-auth";
import { encryptSecret } from "@/lib/crypto";
import { writeLog } from "@/lib/server-log";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db.select().from(satProfiles).orderBy(desc(satProfiles.createdAt));
    // Nunca expor credenciais: devolver apenas metadados + estado
    const safe = rows.map((r) => ({
      id: r.id,
      name: r.name,
      endpointIp: r.endpointIp,
      gateway: r.gateway,
      dnsPrimary: r.dnsPrimary,
      dnsSecondary: r.dnsSecondary,
      username: r.username,
      hasPassword: !!r.passwordEnc,
      notes: r.notes,
      lastStatus: r.lastStatus,
      lastLatencyMs: r.lastLatencyMs,
      lastCheck: r.lastCheck,
      createdAt: r.createdAt,
    }));
    return Response.json({ ok: true, profiles: safe });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const auth = await requireAdmin(req);
  if (!auth.ok) return Response.json({ ok: false, error: auth.error }, { status: 401 });
  try {
    const body = (await req.json()) as Record<string, string>;
    const name = String(body["name"] || "").trim();
    const endpointIp = String(body["endpointIp"] || "").trim();
    if (!name || !endpointIp) {
      return Response.json({ ok: false, error: "Nome e IP do terminal/gateway são obrigatórios" }, { status: 400 });
    }
    const inserted = await db
      .insert(satProfiles)
      .values({
        name: name.slice(0, 120),
        endpointIp: endpointIp.slice(0, 120),
        gateway: String(body["gateway"] || "").slice(0, 120) || null,
        dnsPrimary: String(body["dnsPrimary"] || "1.1.1.1").slice(0, 60),
        dnsSecondary: String(body["dnsSecondary"] || "8.8.8.8").slice(0, 60),
        username: String(body["username"] || "").slice(0, 120) || null,
        passwordEnc: body["password"] ? encryptSecret(String(body["password"]).slice(0, 500)) : null,
        notes: String(body["notes"] || "").slice(0, 1000) || null,
      })
      .returning({ id: satProfiles.id });
    await writeLog("admin", "success", `Perfil ANGOSAT-2 criado por ${auth.username}: ${name} (${endpointIp})`);
    return Response.json({ ok: true, id: inserted[0].id });
  } catch (e) {
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "Falha" }, { status: 500 });
  }
}
