import { db } from "@/db";
import { appLogs, dailyStats } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export async function writeLog(
  category: string,
  level: "info" | "success" | "warn" | "error",
  message: string,
  details?: string
) {
  try {
    await db.insert(appLogs).values({
      category: category.slice(0, 60),
      level,
      message: message.slice(0, 500),
      details: details ? details.slice(0, 4000) : null,
    });
  } catch {
    // logging nunca deve quebrar o pedido
  }
}

export async function touchDaily(patch: {
  bytesUp?: number;
  bytesDown?: number;
  sessions?: number;
  durationSec?: number;
  tests?: number;
}) {
  try {
    const day = new Date().toISOString().slice(0, 10);
    const existing = await db
      .select()
      .from(dailyStats)
      .where(eq(dailyStats.day, day))
      .limit(1);
    if (existing.length === 0) {
      await db.insert(dailyStats).values({
        day,
        bytesUp: patch.bytesUp ?? 0,
        bytesDown: patch.bytesDown ?? 0,
        sessions: patch.sessions ?? 0,
        totalDurationSec: patch.durationSec ?? 0,
        testsRun: patch.tests ?? 0,
      });
    } else {
      await db
        .update(dailyStats)
        .set({
          bytesUp: sql`${dailyStats.bytesUp} + ${patch.bytesUp ?? 0}`,
          bytesDown: sql`${dailyStats.bytesDown} + ${patch.bytesDown ?? 0}`,
          sessions: sql`${dailyStats.sessions} + ${patch.sessions ?? 0}`,
          totalDurationSec: sql`${dailyStats.totalDurationSec} + ${
            patch.durationSec ?? 0
          }`,
          testsRun: sql`${dailyStats.testsRun} + ${patch.tests ?? 0}`,
          updatedAt: new Date(),
        })
        .where(eq(dailyStats.day, day));
    }
  } catch {}
}

export function jsonDetails(obj: unknown): string {
  try {
    return JSON.stringify(obj).slice(0, 4000);
  } catch {
    return String(obj).slice(0, 4000);
  }
}
